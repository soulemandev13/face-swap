# Optional models (nothing here is required)
The built-in engine needs **no files**. Place files in this folder only if you want better quality.

| File | Purpose | Notes |
|---|---|---|
| `inswapper_128.onnx` | InsightFace neural identity engine | Obtain it yourself from a source you trust. **Licence is research/non-commercial.** With `pip install -r backend/requirements-neural.txt`, the `buffalo_l` detector/recogniser pack is fetched by InsightFace into `models/insightface/` on first use (needs internet once; copy the folder to run fully offline). |
| `face_parsing.onnx` | Hair/glasses/hat occlusion (High quality) | Any 19-class CelebAMask-HQ BiSeNet export, input 512×512 NCHW, ImageNet normalisation. Check its licence. |

`python scripts/check_env.py` and the UI pill show which engines are active. If the file is missing the app silently stays on mesh_warp.
