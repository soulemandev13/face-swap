import { api, upload } from "./api.js";

const $ = (id) => document.getElementById(id);
function h(tag, attrs = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") e.className = v; else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) e.setAttribute(k, v);
  }
  for (const k of kids.flat()) e.append(k instanceof Node ? k : document.createTextNode(String(k)));
  return e;
}
const fmtT = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

const st = { video: null, analysis: null, boxes: null, sel: new Set(), refs: [], refSel: new Set(), job: null, logAfter: 0, system: null, timer: null, viewMode: "orig" };

// ---------------------------------------------------------------- boot ------------------
async function boot() {
  try {
    st.system = await api.system();
    $("consentText").textContent = st.system.consent_text;
    const ok = st.system.ffmpeg.ffmpeg && st.system.ffmpeg.ffprobe;
    $("sysPill").textContent = ok ? `ready · ${st.system.gpu || "CPU"}` : "FFmpeg missing!";
    $("sysPill").className = "pill " + (ok ? "ok" : "bad");
    const n = st.system.engines;
    $("engineNote").textContent = `Mesh warp: built in. InsightFace: ${n.insightface.available ? "available" : "not installed – " + n.insightface.detail}.`;
    $("s_label_ai_visible").checked = st.system.default_label_ai;
  } catch (e) { $("sysPill").textContent = "backend unreachable"; $("sysPill").className = "pill bad"; }
  bindSettings(); await refreshLibrary(); await refreshRefs(); await refreshHistory(); updateButtons();
}

function bindSettings() {
  document.querySelectorAll("input[type=range]").forEach((r) => {
    const o = r.parentElement.querySelector("output"); const f = () => (o.textContent = Number(r.value).toFixed(2)); r.addEventListener("input", f); f();
  });
  $("consent").addEventListener("change", updateButtons);
}
function settings() {
  const g = (id) => $("s_" + id);
  const num = (id) => (g(id).value === "" ? null : Number(g(id).value));
  return {
    engine: g("engine").value, replacement_mode: g("replacement_mode").value, quality: g("quality").value,
    mask_strength: +g("mask_strength").value, mask_expand: +g("mask_expand").value, color_match: +g("color_match").value,
    temporal_smoothing: +g("temporal_smoothing").value, hair_transfer: +g("hair_transfer").value,
    preserve_inner_mouth: g("preserve_inner_mouth").checked, preserve_closed_eyes: g("preserve_closed_eyes").checked,
    min_confidence: +g("min_confidence").value, overlap_policy: g("overlap_policy").value,
    replace_start_s: num("replace_start_s"), replace_end_s: num("replace_end_s"),
    output_resolution: g("output_resolution").value, output_name: g("output_name").value || null,
    keep_audio: g("keep_audio").checked, label_ai_visible: g("label_ai_visible").checked, comparison: g("comparison").checked,
  };
}
function updateButtons() {
  const c = $("consent").checked, v = !!st.video;
  $("videoFile").disabled = !c; $("refFile").disabled = !c;
  $("analyzeBtn").disabled = !(c && v) || (st.analysis && st.analysis.status === "running");
  const ready = c && st.analysis?.status === "completed" && st.sel.size && st.refSel.size && !(st.job && ["queued", "running", "paused"].includes(st.job.status));
  $("previewBtn").disabled = !ready; $("renderBtn").disabled = !ready;
}

// ---------------------------------------------------------------- video ------------------
async function refreshLibrary() {
  const vs = await api.videos(); const sel = $("videoLib"); sel.replaceChildren(h("option", { value: "" }, "— previous videos —"));
  vs.forEach((v) => sel.append(h("option", { value: v.id }, `${v.name} (${fmtT(v.info.duration)})`)));
}
$("videoLib").addEventListener("change", async (e) => { if (e.target.value) await openVideo(await api.video(e.target.value)); });

$("videoFile").addEventListener("change", async (e) => {
  const f = e.target.files[0]; if (!f) return;
  $("uploadBar").hidden = false; $("videoMeta").textContent = "Uploading…";
  try {
    const v = await upload("/api/videos/upload", f, {}, (p) => ($("uploadBar").firstElementChild.style.width = p * 100 + "%"));
    await openVideo(v); await refreshLibrary();
  } catch (err) { $("videoMeta").textContent = "✗ " + err.message; }
  $("uploadBar").hidden = true;
});

async function openVideo(v) {
  st.video = v; st.sel.clear(); st.analysis = null; st.boxes = null; $("people").replaceChildren();
  const i = v.info;
  $("videoMeta").replaceChildren(`${v.name} — ${i.width}×${i.height}, ${i.fps}fps, ${i.duration}s, ${i.codec}${i.has_audio ? ", audio" : ", no audio"}`,
    ...(v.warnings || []).map((w) => h("div", { class: "warnings" }, h("div", { class: "w" }, w))));
  setPlayer(`/api/videos/${v.id}/media?ts=${Date.now()}`);
  const a = await api.analysis(v.id);
  if (a.status === "completed") { st.analysis = a; await showPeople(); } else if (a.status === "running" || a.status === "queued") pollAnalysis();
  updateButtons();
  if (v.proxy_status !== "ready") setTimeout(async () => { const nv = await api.video(v.id); if (nv.proxy_status === "ready" && st.video?.id === v.id && st.viewMode === "orig" && $("player").paused) setPlayer(`/api/videos/${v.id}/media?ts=${Date.now()}`); }, 6000);
}
function setPlayer(src) { const p = $("player"); const t = p.currentTime || 0; p.src = src; p.addEventListener("loadedmetadata", () => { try { p.currentTime = t; } catch {} }, { once: true }); }

$("analyzeBtn").addEventListener("click", async () => {
  try { await api.analyze(st.video.id); pollAnalysis(); } catch (e) { $("analysisMsg").textContent = "✗ " + e.message; }
});
async function pollAnalysis() {
  $("analysisBar").hidden = false; updateButtons();
  for (;;) {
    const a = await api.analysis(st.video.id); st.analysis = a;
    const p = a.progress || {};
    $("analysisBar").firstElementChild.style.width = (p.percent || 0) + "%";
    $("analysisMsg").textContent = a.status === "running" || a.status === "queued" ? `Analysing… ${p.percent || 0}%${p.eta_s != null ? ` · ~${Math.round(p.eta_s)}s left` : ""}` : "";
    if (a.status === "completed") { await showPeople(); break; }
    if (a.status === "failed" || a.status === "cancelled") { $("analysisMsg").textContent = "✗ " + (a.error || a.status); break; }
    await new Promise((r) => setTimeout(r, 700));
  }
  $("analysisBar").hidden = true; updateButtons();
}
async function showPeople() {
  const s = st.analysis.summary; const box = $("people"); box.replaceChildren();
  if (!s.tracks.length) box.append(h("div", { class: "small muted" }, "No faces found."));
  s.tracks.forEach((t) => {
    const card = h("div", { class: "person" + (st.sel.has(t.id) ? " sel" : ""), onclick: () => { st.sel.has(t.id) ? st.sel.delete(t.id) : st.sel.add(t.id); card.classList.toggle("sel"); drawOverlay(); updateButtons(); } },
      t.has_thumb ? h("img", { src: `/api/analysis/${st.video.id}/thumb/${t.id}`, alt: `person ${t.id}` }) : "",
      h("b", {}, `Person ${t.id}`), h("div", { class: "muted" }, `${fmtT(t.time_start)}–${fmtT(t.time_end)} · ${(t.coverage * 100).toFixed(0)}% · conf ${t.mean_conf}`));
    box.append(card);
  });
  $("analysisMsg").replaceChildren(...s.warnings.map((w) => h("div", { class: "warnings" }, h("div", { class: "w" }, w))));
  st.boxes = await api.boxes(st.video.id); drawOverlay(); updateButtons();
}

// ---------------------------------------------------------------- overlay ------------------
const player = $("player"), cv = $("overlay");
function drawOverlay() {
  const w = player.clientWidth, hh = player.clientHeight; cv.width = w; cv.height = hh; cv.style.width = w + "px"; cv.style.height = hh + "px";
  const ctx = cv.getContext("2d"); ctx.clearRect(0, 0, w, hh);
  if (!st.boxes || !$("showBoxes").checked || st.viewMode !== "orig") return;
  const fr = Math.round(player.currentTime * st.boxes.fps), sx = w / st.boxes.width, sy = hh / st.boxes.height;
  ctx.lineWidth = 2; ctx.font = "12px system-ui";
  for (const t of st.boxes.tracks) {
    let lo = 0, hi = t.frames.length - 1, k = -1;
    while (lo <= hi) { const m = (lo + hi) >> 1; if (t.frames[m] === fr) { k = m; break; } t.frames[m] < fr ? (lo = m + 1) : (hi = m - 1); }
    if (k < 0) continue;
    const [x1, y1, x2, y2] = t.boxes[k], sel = st.sel.has(t.id);
    ctx.strokeStyle = sel ? "#6aa9ff" : "#9aa3b5"; ctx.fillStyle = ctx.strokeStyle;
    ctx.strokeRect(x1 * sx, y1 * sy, (x2 - x1) * sx, (y2 - y1) * sy);
    ctx.fillText(`${sel ? "● " : ""}Person ${t.id}`, x1 * sx + 3, Math.max(12, y1 * sy - 4));
  }
}
["timeupdate", "seeked", "loadedmetadata", "play", "pause"].forEach((ev) => player.addEventListener(ev, drawOverlay));
player.addEventListener("play", function loop() { drawOverlay(); if (!player.paused) requestAnimationFrame(loop); });
window.addEventListener("resize", drawOverlay); $("showBoxes").addEventListener("change", drawOverlay);

// ---------------------------------------------------------------- references ------------------
$("refFile").addEventListener("change", async (e) => {
  const f = e.target.files[0]; if (!f) return;
  try { const r = await upload("/api/reference/upload", f, { consent_ack: "true" }); st.refSel.add(r.id); await refreshRefs(); r.quality.warnings?.forEach((w) => addWarning(w)); }
  catch (err) { addWarning("Reference rejected: " + err.message, true); }
  e.target.value = "";
});
async function refreshRefs() {
  st.refs = await api.refs(); const box = $("refs"); box.replaceChildren();
  st.refs.forEach((r) => box.append(h("div", { class: "ref" + (st.refSel.has(r.id) ? " sel" : ""), onclick: () => { st.refSel.has(r.id) ? st.refSel.delete(r.id) : st.refSel.add(r.id); refreshRefs(); updateButtons(); } },
    h("span", { class: "x", title: "Delete", onclick: async (ev) => { ev.stopPropagation(); await api.delRef(r.id); st.refSel.delete(r.id); refreshRefs(); updateButtons(); } }, "✕"),
    h("img", { src: `/api/reference/${r.id}/image`, alt: "reference" }), `${r.quality.face_px ?? "?"}px · yaw ${r.quality.yaw ?? "?"}°`)));
  updateButtons();
}

// ---------------------------------------------------------------- jobs ------------------
function body() { return { video_id: st.video.id, reference_ids: [...st.refSel], target_track_ids: [...st.sel], consent_ack: $("consent").checked, settings: settings() }; }
async function start(kind) {
  $("warnings").replaceChildren(); $("logs").textContent = ""; st.logAfter = 0; $("result").textContent = "Working…"; $("samples").replaceChildren();
  try {
    const b = body();
    if (kind === "preview") {
      const t = st.analysis.summary.tracks.filter((x) => st.sel.has(x.id)); const cur = player.currentTime;
      const inside = t.some((x) => cur >= x.time_start && cur <= x.time_end);
      b.settings.preview_start_s = inside ? cur : Math.min(...t.map((x) => x.time_start)); b.settings.preview_duration_s = 3;
    }
    st.job = await (kind === "preview" ? api.preview(b) : api.render(b)); st.viewMode = "orig"; pollJob();
  } catch (e) { addWarning(e.message, true); }
  updateButtons();
}
$("previewBtn").addEventListener("click", () => start("preview")); $("renderBtn").addEventListener("click", () => start("render"));
for (const a of ["pause", "resume", "cancel"]) $(a + "Btn").addEventListener("click", () => st.job && api.control(st.job.id, a).catch((e) => addWarning(e.message, true)));

function addWarning(t, err) { $("warnings").append(h("div", { class: "w" + (err ? " e" : "") }, t)); }
async function pollJob() {
  clearTimeout(st.timer);
  const id = st.job.id; let j;
  try { j = await api.job(id); } catch { st.timer = setTimeout(pollJob, 1500); return; }
  st.job = j;
  const L = await api.logs(id, st.logAfter);
  if (L.length) { st.logAfter = L[L.length - 1].id; const pre = $("logs"); pre.textContent += L.map((l) => `${new Date(l.ts * 1000).toLocaleTimeString()} ${l.level.padEnd(7)} ${l.message}`).join("\n") + "\n"; pre.scrollTop = pre.scrollHeight; }
  const p = j.progress || {}, active = ["queued", "running", "paused"].includes(j.status);
  $("jobStatus").textContent = j.status + (p.paused ? " (paused)" : ""); $("jobStatus").className = "pill " + (j.status === "completed" ? "ok" : j.status === "failed" ? "bad" : active ? "run" : "");
  $("jobBar").firstElementChild.style.width = (p.percent || 0) + "%";
  $("jobMsg").textContent = active ? `${j.kind} · ${p.percent ?? 0}% · frame ${p.frame ?? 0}/${p.total_frames ?? "?"} · ${p.fps ?? 0} fps${p.eta_s != null ? ` · ~${Math.round(p.eta_s)}s left` : ""}` : (j.error ? "✗ " + j.error : "");
  $("pauseBtn").hidden = !(j.status === "running"); $("resumeBtn").hidden = !(j.status === "paused"); $("cancelBtn").hidden = !active;
  if (active) { st.timer = setTimeout(pollJob, 700); updateButtons(); return; }
  updateButtons(); refreshHistory();
  if (j.status === "completed") await showResult(j);
  else if (j.status === "failed") $("result").textContent = "Failed: " + j.error; else $("result").textContent = "Cancelled.";
}
function outUrl(j, variant) { return `/api/jobs/${j.id}/${j.kind === "preview" ? "preview" : "result"}${variant ? "?variant=" + variant : ""}`; }
async function showResult(j) {
  const m = j.metrics || {}; setView("out", j);
  (m.warnings || []).forEach((w) => addWarning(w));
  const rows = [["Engine", `${m.engine} (${m.engine_note})`], ["Mode / quality", `${m.mode} / ${m.quality}`], ["Frames", `${m.frames_with_replacement} replaced of ${m.frames_written}`],
    ["Speed", `${m.processing_fps} fps · ${m.processing_time_s}s`], ["Resolution", m.output_resolution],
    ["Neighbours modified", m.quality_checks.neighbour_max_mean_abs_diff === 0 ? "no (verified)" : "CHECK: " + m.quality_checks.neighbour_max_mean_abs_diff],
    ["Flicker vs source", m.quality_checks.flicker_ratio ?? "n/a"], ["Skipped", `low-conf ${m.skips.low_confidence}, overlap ${m.skips.overlap_skipped}, outside range ${m.skips.outside_range}`],
    ["Audio kept", m.verify.has_audio ? "yes" : "no"], ["AI label", "metadata" + (m.ai_label.visible_badge ? " + visible badge" : "")]];
  const dl = h("a", { class: "btn", href: outUrl(j) + (outUrl(j).includes("?") ? "&" : "?") + "download=1" }, "Download MP4");
  $("result").replaceChildren(h("div", { class: "row" }, dl, j.kind === "preview" ? h("span", { class: "muted" }, "Preview – happy? Run the full render.") : ""),
    h("table", { class: "m" }, rows.map(([a, b]) => h("tr", {}, h("td", {}, a), h("td", {}, String(b))))));
  $("viewCmp").hidden = !j.has_comparison; if (j.has_comparison) $("viewCmp").href = outUrl(j, "compare");
  if (j.has_samples) { const names = await api.samples(j.id); $("samples").replaceChildren(...names.map((n) => h("img", { src: `/api/jobs/${j.id}/samples/${n}`, alt: "before / after" }))); }
}
function setView(mode, j = st.job) {
  const t = player.currentTime; st.viewMode = mode; $("cmpWrap").hidden = false;
  const src = mode === "out" && j?.output_ready ? outUrl(j) + (outUrl(j).includes("?") ? "&" : "?") + "ts=" + Date.now() : `/api/videos/${st.video.id}/media`;
  player.src = src; player.addEventListener("loadedmetadata", () => { try { player.currentTime = j.kind === "render" || mode === "orig" ? t : 0; } catch {} }, { once: true }); drawOverlay();
}
$("viewOrig").addEventListener("click", () => setView("orig")); $("viewOut").addEventListener("click", () => setView("out"));

async function refreshHistory() {
  const js = await api.jobs(); const box = $("history"); box.replaceChildren();
  js.forEach((j) => box.append(h("div", { class: "item" }, h("span", { class: "pill" }, j.status), `${j.kind} · ${new Date(j.created_at * 1000).toLocaleString()}`, h("span", { class: "spacer" }),
    j.output_ready ? h("button", { class: "ghost", onclick: async () => { st.job = j; if (st.video?.id !== j.video_id) await openVideo(await api.video(j.video_id)); await showResult(j); } }, "Open") : "",
    h("button", { class: "ghost danger", onclick: async () => { try { await api.delJob(j.id); refreshHistory(); } catch (e) { addWarning(e.message, true); } } }, "Delete"))));
}
boot();
