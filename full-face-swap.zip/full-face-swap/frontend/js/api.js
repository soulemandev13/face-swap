async function j(method, url, body) {
  const r = await fetch(url, { method, headers: body ? { "Content-Type": "application/json" } : {}, body: body ? JSON.stringify(body) : undefined });
  const t = await r.text();
  let d; try { d = t ? JSON.parse(t) : null; } catch { d = { detail: t }; }
  if (!r.ok) throw new Error((d && d.detail && (typeof d.detail === "string" ? d.detail : JSON.stringify(d.detail))) || r.statusText);
  return d;
}
export const api = {
  system: () => j("GET", "/api/system"),
  videos: () => j("GET", "/api/videos"),
  video: (id) => j("GET", `/api/videos/${id}`),
  analyze: (id) => j("POST", "/api/analyze", { video_id: id }),
  analysis: (id) => j("GET", `/api/analysis/${id}`),
  boxes: (id) => j("GET", `/api/analysis/${id}/boxes`),
  refs: () => j("GET", "/api/reference"),
  delRef: (id) => j("DELETE", `/api/reference/${id}`),
  delVideo: (id) => j("DELETE", `/api/videos/${id}`),
  preview: (b) => j("POST", "/api/jobs/preview", b),
  render: (b) => j("POST", "/api/jobs/render", b),
  job: (id) => j("GET", `/api/jobs/${id}`),
  jobs: () => j("GET", "/api/jobs?limit=20"),
  logs: (id, after) => j("GET", `/api/jobs/${id}/logs?after=${after}`),
  control: (id, a) => j("POST", `/api/jobs/${id}/${a}`),
  delJob: (id) => j("DELETE", `/api/jobs/${id}`),
  samples: (id) => j("GET", `/api/jobs/${id}/samples`),
};
export function upload(url, file, fields, onProgress) {
  return new Promise((resolve, reject) => {
    const fd = new FormData(); fd.append("file", file);
    for (const [k, v] of Object.entries(fields || {})) fd.append(k, v);
    const x = new XMLHttpRequest();
    x.open("POST", url);
    x.upload.onprogress = (e) => e.lengthComputable && onProgress && onProgress(e.loaded / e.total);
    x.onload = () => { let d; try { d = JSON.parse(x.responseText); } catch { d = {}; }
      x.status < 300 ? resolve(d) : reject(new Error(d.detail || `Upload failed (${x.status})`)); };
    x.onerror = () => reject(new Error("Network error during upload"));
    x.send(fd);
  });
}
