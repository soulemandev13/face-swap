# Sample evaluation (authoring sandbox — SYNTHETIC)
Clip: 1024×512, 25 fps, 2.4–3 s, two faces (one real photo + its mirror), zoom/rotate/pan, AAC tone. CPU, 1 core, no GPU.
Reference: same photo, recoloured. **This validates mechanics, not identity realism or speech/blink behaviour.**

| Case | Result |
|---|---|
| Mode face_only / face_head / full_head_hair (Balanced) | 60/60 frames replaced; 12–16 fps |
| High quality + hair mode (3 s) | 75/75 frames; ~10 fps |
| Neighbour protection | mean abs diff **0.0**, changed-pixel fraction **0.0** (pre-encode) |
| Flicker ratio (output/source temporal diff) | **0.98** |
| Audio / duration | AAC preserved; duration within tolerance; AI metadata present |
| Hair mode clothing check | After skin/silhouette gating, collar no longer tinted (regression found & fixed during testing) |
| Tracking | Two people → two stable tracks; a false-positive "face" on a rocket in the backdrop was found and filtered by the skin-colour rule |
