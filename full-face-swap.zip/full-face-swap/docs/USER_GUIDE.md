# User guide

**Choosing footage.** Best: 720p+, one or few people, faces ≥ 120 px wide, mostly frontal, even lighting, little motion blur.
**Reference photo.** One person, sharp, frontal, eyes open, mouth relaxed, ≥ 256 px face. Upload 2–3 angles (frontal + slight left/right): the pose-closest one is used per frame.

| Setting | Effect |
|---|---|
| Face only | Replaces inner face; keeps target's hair, ears, neck. Safest. |
| Face + head | Adds jaw, temples, ears, skin-tone harmonisation. |
| Full head / hair-aware | Also transfers reference hair crown + neck skin inside the target's silhouette (never clothing/background). Hair transfer slider cross-fades. Mixed-hair look is possible when styles differ a lot. |
| Edge softness / mask size | Wider feather hides seams; larger mask covers more but may bleed. |
| Colour match | How strongly lighting/skin tone adapts to the scene. |
| Temporal smoothing | Higher = steadier, slightly less snappy expressions. |
| Overlap policy | *Leave unchanged* (default) skips frames where the target touches another face instead of guessing. |
| Quality | Draft (fast, no sharpness/occlusion), Balanced, High (Laplacian blend + parser if present). |

**Tips.** Always run a 3 s preview first at the moment the person is visible. If a person leaves and returns as a second track, tick both.
If flicker is reported, raise smoothing. If the face looks pasted-on, raise edge softness and colour match. Close-ups with large head turns
or hands crossing the face are the weakest cases (see limitations).

**Outputs** live in `data/outputs/<job>/`: `output.mp4` (or `preview.mp4`), optional `comparison.mp4`, `report.json`, `samples/`.
Each file carries `comment=AI-edited / synthetic media…` metadata; a visible badge is on by default.
