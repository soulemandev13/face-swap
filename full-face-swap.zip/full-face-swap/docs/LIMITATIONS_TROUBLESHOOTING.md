# Honest limitations
* **Built-in engine is texture-level.** It transfers the reference's skin/hair appearance onto the *target's* face geometry; it cannot reshape bone structure the way neural swappers do. Use the InsightFace engine for stronger identity.
* **Hair:** without a face-parsing model the hair/neck gating uses colour + person-silhouette heuristics. Very different hairstyles, hats, long hair over shoulders, or colour-matched backgrounds can leave seams or remnants.
* **Occluders** (hands, glasses, microphones) are only handled for forehead-colour outliers (heuristic) or via the optional parser. Glasses are not specially handled.
* **Pose:** beyond ~45° yaw/pitch the mesh warp degrades (triangles fold); profile views are not supported — those frames lose confidence and are skipped.
* **Tracking:** identity after long occlusion uses a colour histogram, which can fail for similarly dressed people → tick both tracks or restrict the time range.
* **Detection:** MediaPipe FaceMesh gives no native score (confidence is a documented heuristic); strong backlight, tiny (<40 px) or heavily blurred faces are unreliable. A skin-colour sanity filter handles background false positives but is skipped for greyscale footage.
* **Speed:** CPU only ≈ 6–15 fps on one core at ~1024×512 (Balanced/High). Analysis time ≈ source duration × 0.5–2. Everything is sequential, one job at a time.
* **Not tested here:** the InsightFace/parsing-model paths, GPU providers, Windows/macOS, Docker image build, real speech/blink footage and cross-identity realism (the sandbox had one face photo and no GPU). Run `docs/TEST_PLAN.md` on your hardware.
* Browser playback uses an H.264 proxy (≤960 px); the **render** always uses the original frames.

# Troubleshooting
| Symptom | Fix |
|---|---|
| "FFmpeg missing" pill | Install FFmpeg, ensure `ffmpeg`/`ffprobe` on PATH (or `FFS_FFMPEG_BIN`). |
| Upload rejected: duration/resolution | Trim/downscale, or raise `FFS_MAX_DURATION_S` / `FFS_MAX_WIDTH`. |
| "No faces detected" | Larger/brighter/frontal faces; check the video isn't rotated or very dark. |
| Person missing from list | Tiny or turned away; try a clip crop. Faces <40 px are not reliable. |
| Result flickers | Raise temporal smoothing; use Balanced/High; reduce mask size. |
| Visible seam | Raise edge softness; use *Face+head*; ensure colour match ≥0.8. |
| Frames unchanged | See job warnings: low confidence or overlap skip; lower min. confidence or set overlap policy to *proceed*. |
| Job fails "disk" | Free ≥300 MB; delete old jobs; `POST /api/maintenance/cleanup`. |
| ONNX/CUDA error | `FFS_USE_GPU=false`, or use `mesh_warp`. |
| Port busy | `FFS_PORT=8001`. |
