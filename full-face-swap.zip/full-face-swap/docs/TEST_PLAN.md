# Test plan & evaluation matrix
Automated: `pip install -r backend/requirements-dev.txt && pytest backend/tests`.
Manual/quality matrix — run with `scripts/run_matrix.py` (manifest of clips) then inspect `samples/` and the video; record pass/fail.

| ID | Case | Pass criteria |
|---|---|---|
| A | Single frontal speaker, good light | Mouth follows speech; no mask pulsing; flicker ratio ≤ 1.3 |
| B | Moderate head turns (≤35°) | No folded-triangle artefacts; reference closest-pose selection works |
| C | Two people, replace one | `neighbour_max_mean_abs_diff` = 0; other person pixel-identical pre-encode |
| D | Crowd / small faces (60–100 px) | All faces listed; warnings shown for small faces |
| E | Overlap / crossing faces | Overlap frames skipped (default) with warning; no bleed onto neighbour |
| F | Person leaves & re-enters | Re-id or two tracks; ticking both swaps both |
| G | Fast motion / blur | Low-confidence frames skipped, fades not pops |
| H | Dim / mixed lighting | Colour match adapts; no tone jump between frames |
| I | Glasses / fringe / hat | Document behaviour; forehead occlusion heuristic engaged (parser improves) |
| J | Hair-aware mode, similar vs. different hairstyle | Silhouette preserved; no clothing/background tint |
| K | Audio / duration / resolution / fps / rotated phone video | Duration ±1 frame, audio present, orientation correct, VFR clip stays in sync |
| L | Failure paths: corrupt file, huge file, no-face reference, disk full, cancel mid-render, restart mid-job | Friendly message, no partial outputs, logs kept, job marked failed/cancelled |
| M | Neural engine (if installed) | Engine pill shows insightface; compare identity vs. mesh_warp |
| N | Privacy | No outbound traffic (e.g. `strace`/firewall), localhost bind, delete removes files |

Record per run: engine, mode, quality, fps, `report.json`, subjective identity/realism score (1–5), notes.
