# Architecture

```
frontend/ (vanilla ES modules, no build)  ──HTTP/JSON──►  backend/app (FastAPI)
                                                          ├─ api/routes.py        endpoints, uploads, Range streaming
                                                          ├─ services/jobs.py     1 worker thread, cancel/pause/resume, SQLite status+logs
                                                          ├─ services/analysis.py detect → track → tracks.npz + thumbnails + overlaps
                                                          ├─ services/render.py   per-frame pipeline, metrics, report, samples
                                                          ├─ media/ffmpeg.py      probe/validate, piped reader/writer, audio mux, AI metadata
                                                          └─ vision/              analyzer · tracker · temporal · masks · compositor · engines · reference · segmentation
data/{uploads,references,analysis,outputs,temp,logs}   (sources and generated files are separate)
```

## Pipeline
1. **Upload** → stream to disk with size cap → `ffprobe` → limits (duration, resolution, codec) → browser proxy (H.264) built in background.
2. **Analyse** (once): frames streamed from FFmpeg as constant-frame-rate BGR. Discovery scans (full frame + overlapping tiles, NMS)
   every 8 frames find people (MediaPipe's detector misses small faces in wide frames, hence tiling); between scans each known track
   is refined in an ROI. Hungarian tracker (predicted-box IoU + centre distance), gap tolerance, histogram re-identification after
   occlusion. Per-track 478-pt landmarks, confidence, pose, EAR/MAR stored in `tracks.npz`. Short non-skin-coloured tracks are dropped as false positives.
3. **Select**: operator ticks track(s) (several ticks = same person re-entering).
4. **Render**: landmark series → outlier rejection, short-gap interpolation, Gaussian smoothing (rigid points smoothed more than lips/eyes
   so speech/blinks stay sharp), activity gating (time range, confidence, overlap policy) and fade ramps. Per frame, in a head ROI:
   source layer (engine) → zones (face / head / hair) → colour+lighting transfer (EMA-stabilised; hair keeps its own chroma) → sharpness match →
   expression handling (keep target's inner mouth + closed eyelids) → occlusion (parser if available, else colour heuristic) →
   neighbour protection → feathered or Laplacian-pyramid blend. Frames stream straight into libx264 with the original audio.
5. **Verify**: re-probe output, duration/audio checks, neighbour-diff, flicker ratio, AI metadata; optional side-by-side; before/after sample frames; `report.json`.

## API (all under `/api`, docs at `/api/docs`)
`GET /system` · `POST /videos/upload` · `GET /videos[/{id}[/media|/frame]]` · `DELETE /videos/{id}` · `POST /reference/upload` (consent required) ·
`GET /reference[/{id}/image]` · `DELETE /reference/{id}` · `POST /analyze` · `GET /analysis/{video}` `[/boxes|/thumb/{track}]` ·
`POST /jobs/preview` · `POST /jobs/render` · `GET /jobs[/{id}[/logs|/report|/samples]]` · `POST /jobs/{id}/cancel|pause|resume` ·
`GET /jobs/{id}/preview` · `GET /jobs/{id}/result[?download=1][&variant=compare]` · `DELETE /jobs/{id}` · `POST /maintenance/cleanup`.

## Security / privacy
Localhost bind (LAN only via `FFS_ALLOW_LAN`), Trusted-Host check (DNS rebinding), CSP + nosniff + frame-deny, ids regex-validated,
user filenames never used as paths, extension allow-lists, upload caps, no outbound network calls at runtime, no telemetry,
consent enforced server-side, user data deletable per item (`DELETE`) or `POST /maintenance/cleanup`.

## Extending
Add an engine: implement `prepare(ref)` and `face_layer(roi, lm_roi, ref) -> (bgr, valid)`; register in `vision/engines.get_engine`.
Better hair/occlusion: drop a 19-class BiSeNet face-parsing ONNX at `models/face_parsing.onnx` (used in *High* quality).
