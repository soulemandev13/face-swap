# Full Face-Swap Studio

A **local, consent-gated** web app that replaces a selected person's face (optionally jaw/ears/hairline, or the whole
head/hair region) in a video with an identity from a reference photo — while keeping the original audio, protecting
every other person in the frame, and labelling the result as AI-edited.

Implements `Full_Face_Swap_Web_Project_Requirements_Report.docx` (upload → analyse → pick person → reference →
preview → render → review → download).

## Quick start

Requirements: **Python 3.9–3.12** and **FFmpeg** (with `ffprobe`) on PATH. No GPU and no model downloads are needed for the built-in engine.

```bash
# Linux / macOS                     # Windows
./scripts/run.sh                    scripts\run.bat
```
This creates `.venv`, installs `backend/requirements.txt`, starts the server on **http://127.0.0.1:8000** and opens the browser.
`python scripts/check_env.py` diagnoses problems. Docker: `docker compose -f docker/docker-compose.yml up --build`.

### Workflow in the UI
1. Tick the **consent** box (required for uploads and processing; also enforced by the API).
2. Upload a video → **Analyze people** → tick the person(s) to replace (neighbours are protected automatically).
3. Upload one or more **reference photos** (clear, frontal, one person; several angles help).
4. Pick scope (face only / face+head / full head+hair), quality, blending options.
5. **Preview 3 s** → inspect → **Render full video** → compare original/result, read the quality report, download.

### Headless
```bash
python scripts/cli.py --video in.mp4 --ref face.jpg --track left --out out/ --i-have-consent --quality high
python scripts/run_matrix.py manifest.json out/        # evaluation matrix → evaluation_report.md
```

## Engines
| Engine | Needs | What it does |
|---|---|---|
| `mesh_warp` (built-in, default) | nothing (MediaPipe weights ship in the wheel) | Warps the reference's face+head mesh onto the target's per-frame 478-point landmarks (incl. iris) → follows speech, blinks, gaze; colour/sharpness matched. Texture-level identity only. |
| `insightface` (optional) | `pip install -r backend/requirements-neural.txt` + model files, see `models/README.md` | Neural identity transfer (inswapper_128) as the face layer on top of the mesh head layer. Stronger identity. **Written against the public API but not executed in the authoring sandbox — verify on your machine.** |

## What is verified (automated, `pytest backend/tests` → 17 tests)
Path-traversal/ID/extension hardening · DNS-rebinding guard · corrupt/oversized uploads rejected · consent enforced server-side ·
multi-face detection incl. small faces in wide frames · tracker ID stability · temporal smoothing/outlier/gap logic · fade gains ·
mesh-warp identity round-trip · closed-eye / open-mouth preservation · neighbour protection (pixel-exact in the loop) ·
full API flow (upload → analyse → select → preview → render → Range streaming → download → AI metadata → cancel/pause → delete) ·
audio carried over · output re-probed after encode.

## Responsible use
Use only with media you own or are authorised to edit, and only with the consent of every person whose likeness is used
or depicted. Do not use for impersonation, fraud, harassment, or deception. The app: requires an explicit consent
acknowledgement (UI + API + CLI flag), is localhost-only by default, never uploads anything, always writes an
"AI-edited / synthetic media" metadata tag, and burns a visible badge unless you turn it off (removing labels when
publishing may be unlawful or violate platform rules in your jurisdiction).

## Docs
`docs/ARCHITECTURE.md` · `docs/USER_GUIDE.md` · `docs/LIMITATIONS_TROUBLESHOOTING.md` · `docs/TEST_PLAN.md` · `docs/SAMPLE_EVALUATION.md` · `models/README.md`

License: MIT for this code; third-party model weights have their own (often non-commercial) licences.
