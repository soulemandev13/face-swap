#!/usr/bin/env python3
"""Generate a SYNTHETIC two-person demo clip + reference using scikit-image's public-domain astronaut photo.
Only for smoke-testing the pipeline mechanics (it has no speech/blinks).  pip install scikit-image"""
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np
from skimage import data

out = Path(sys.argv[1] if len(sys.argv) > 1 else "demo"); out.mkdir(parents=True, exist_ok=True)
img = cv2.cvtColor(data.astronaut(), cv2.COLOR_RGB2BGR)
two = np.hstack([img, cv2.flip(img, 1)])
p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", "1024x512", "-r", "25", "-i", "-",
                      "-f", "lavfi", "-i", "sine=frequency=440:duration=3", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(out / "demo.mp4")], stdin=subprocess.PIPE)
for i in range(75):
    t = i / 74
    M = cv2.getRotationMatrix2D((512, 256), 2 * np.sin(t * 6.28), 1 + 0.06 * np.sin(t * 3.14)); M[0, 2] += 12 * np.sin(t * 6.28)
    p.stdin.write(cv2.warpAffine(two, M, (1024, 512), borderMode=cv2.BORDER_REFLECT).tobytes())
p.stdin.close(); p.wait()
r = img.astype(np.float32); r[..., 0] *= 1.15; r[..., 2] *= 0.85
cv2.imwrite(str(out / "reference.png"), np.clip(r * 0.9, 0, 255).astype(np.uint8))
print("wrote", out / "demo.mp4", out / "reference.png")
