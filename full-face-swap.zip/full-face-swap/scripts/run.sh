#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[ -d .venv ] || { python3 -m venv .venv; .venv/bin/pip install -U pip; .venv/bin/pip install -r backend/requirements.txt; }
exec .venv/bin/python scripts/run.py "$@"
