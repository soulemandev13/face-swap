#!/usr/bin/env python3
"""Start the app:  python scripts/run.py   (opens http://127.0.0.1:8000)"""
import sys
import threading
import time
import webbrowser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))


def main() -> None:
    import uvicorn
    from app.core.config import get_settings
    from app.media.ffmpeg import ffmpeg_available
    s = get_settings()
    s.check_network_policy()
    ff = ffmpeg_available()
    if not (ff["ffmpeg"] and ff["ffprobe"]):
        sys.exit("FFmpeg/FFprobe not found on PATH. Install FFmpeg (https://ffmpeg.org/download.html) and retry.")
    url = f"http://{s.host}:{s.port}"
    if "--no-browser" not in sys.argv:
        threading.Thread(target=lambda: (time.sleep(1.5), webbrowser.open(url)), daemon=True).start()
    print(f"Full Face-Swap Studio → {url}   (Ctrl+C to stop)")
    uvicorn.run("app.main:app", host=s.host, port=s.port, log_level=s.log_level.lower())


if __name__ == "__main__":
    main()
