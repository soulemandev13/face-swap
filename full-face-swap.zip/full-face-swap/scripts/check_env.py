#!/usr/bin/env python3
"""Environment doctor: prints what works and how to fix what doesn't."""
import importlib
import platform
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
ok = True


def row(name, good, detail=""):
    global ok
    ok &= bool(good)
    print(f"[{'OK' if good else '!!'}] {name:<22} {detail}")


row("Python >= 3.9", sys.version_info >= (3, 9), platform.python_version())
for mod in ("fastapi", "uvicorn", "cv2", "numpy", "scipy", "mediapipe", "pydantic_settings", "multipart"):
    try:
        m = importlib.import_module(mod)
        row(mod, True, getattr(m, "__version__", ""))
    except Exception as e:
        row(mod, False, f"missing -> pip install -r backend/requirements.txt ({e})")
from app.media.ffmpeg import ffmpeg_available
f = ffmpeg_available()
row("ffmpeg", f["ffmpeg"], f["ffmpeg"] or "install FFmpeg and add to PATH")
row("ffprobe", f["ffprobe"], f["ffprobe"] or "ships with FFmpeg")
from app.vision.engines import engine_report
for k, v in engine_report().items():
    print(f"[{'OK' if v['available'] else '--'}] engine {k:<15} {v['detail']}")
try:
    from app.vision.analyzer import MediaPipeAnalyzer
    import numpy as np
    MediaPipeAnalyzer().detect(np.zeros((240, 320, 3), np.uint8))
    row("face mesh runtime", True, "bundled weights load")
except Exception as e:
    row("face mesh runtime", False, str(e))
print("\nAll required checks passed." if ok else "\nFix the [!!] items above, then re-run.")
sys.exit(0 if ok else 1)
