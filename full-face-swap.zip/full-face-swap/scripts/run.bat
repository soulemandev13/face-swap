@echo off
cd /d "%~dp0\.."
if not exist .venv (python -m venv .venv && .venv\Scripts\pip install -U pip && .venv\Scripts\pip install -r backend\requirements.txt)
.venv\Scripts\python scripts\run.py %*
