#!/usr/bin/env python3
"""Headless processing (no server/DB):

  python scripts/cli.py --video in.mp4 --ref face.jpg --track largest --out out_dir --i-have-consent \
         [--mode face_head] [--quality balanced] [--preview 3] [--engine auto]

--track: largest | left | right | <id>[,<id>…]
Also used by scripts/run_matrix.py for the evaluation matrix."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))


def process(video: Path, refs: list[Path], track: str, out_dir: Path, settings: dict, preview: float | None = None, log=print) -> dict:
    from app.core.config import get_settings
    from app.media import ffmpeg as ff
    from app.models.schemas import ProcessingSettings
    from app.services import analysis as an, render as rd
    from app.workers.control import JobControl
    cfg = get_settings()
    info = ff.probe(video)
    for w in ff.validate(info):
        log("WARN", w)
    vid = "vid_" + hashlib.sha1(f"{video.resolve()}:{video.stat().st_mtime_ns}".encode()).hexdigest()[:12]
    ctl = JobControl(on_log=lambda l, m: log(l, m), on_progress=lambda p: print(f"\r  {p['stage']} {p['percent']:5.1f}%  {p['fps']} fps", end="", flush=True))
    summary = an.load_summary(vid) or an.run_analysis(vid, video, info, ctl)
    print()
    tracks = summary["tracks"]
    if not tracks:
        raise SystemExit("No faces detected.")
    if track == "largest":
        ids = [max(tracks, key=lambda t: t["mean_face_px"] * t["n_frames"])["id"]]
    elif track in ("left", "right"):
        ids = [(min if track == "left" else max)(tracks, key=lambda t: t["x_center"])["id"]]
    else:
        ids = [int(x) for x in track.split(",")]
    log("INFO", f"people: {[(t['id'], t['x_center'], t['n_frames']) for t in tracks]} → replacing {ids}")
    S = ProcessingSettings(**settings)
    if preview:
        S.preview_start_s = min(t["time_start"] for t in tracks if t["id"] in ids)
        S.preview_duration_s = preview
    res = rd.run_render(job_id="job_" + vid[4:], kind="preview" if preview else "render", video_path=video, info=info, video_id=vid,
                        ref_paths=[(f"ref_{hashlib.sha1(str(r).encode()).hexdigest()[:12]}", r) for r in refs], target_ids=ids, S=S, out_dir=out_dir, ctl=ctl)
    print()
    return res


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--video", required=True, type=Path)
    ap.add_argument("--ref", required=True, type=Path, nargs="+")
    ap.add_argument("--track", default="largest")
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--mode", default="face_head", choices=["face_only", "face_head", "full_head_hair"])
    ap.add_argument("--quality", default="balanced", choices=["draft", "balanced", "high"])
    ap.add_argument("--engine", default="auto")
    ap.add_argument("--preview", type=float, help="render only N seconds starting where the person first appears")
    ap.add_argument("--no-badge", action="store_true", help="omit the visible AI-edited badge (metadata label is still written)")
    ap.add_argument("--i-have-consent", action="store_true", help="REQUIRED: you own/are authorised to use the video and reference, and everyone depicted consented")
    a = ap.parse_args()
    if not a.i_have_consent:
        sys.exit("Refusing to run without --i-have-consent (see README → Responsible use).")
    r = process(a.video, a.ref, a.track, a.out, dict(replacement_mode=a.mode, quality=a.quality, engine=a.engine, label_ai_visible=not a.no_badge), a.preview)
    print(json.dumps({"output": r["output_path"], **{k: r["metrics"][k] for k in ("processing_fps", "frames_with_replacement", "warnings")}}, indent=2))


if __name__ == "__main__":
    main()
