#!/usr/bin/env python3
"""Run an evaluation matrix and write evaluation_report.md.

manifest.json:  [{"name":"A single frontal","video":"clips/a.mp4","ref":["refs/p1.jpg"],"track":"largest",
                  "mode":"face_head","quality":"balanced","preview":5}, ...]
Objective numbers come from the pipeline (neighbour protection, flicker, skips, speed). Identity/realism still
need a human look at the sample frames (see docs/TEST_PLAN.md)."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from cli import process  # noqa: E402


def main() -> None:
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    manifest, out = Path(sys.argv[1]), Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=True)
    base = manifest.parent
    lines = ["# Evaluation report", "", "| # | case | status | fps | replaced/total | neighbour Δ | flicker | warnings |", "|---|---|---|---|---|---|---|---|"]
    details = []
    for i, c in enumerate(json.loads(manifest.read_text()), 1):
        name = c.get("name", f"case{i}")
        try:
            r = process(base / c["video"], [base / x for x in c["ref"]], c.get("track", "largest"), out / f"{i:02d}", 
                        dict(replacement_mode=c.get("mode", "face_head"), quality=c.get("quality", "balanced")), c.get("preview"), log=lambda *_: None)
            m = r["metrics"]; q = m["quality_checks"]
            lines.append(f"| {i} | {name} | ok | {m['processing_fps']} | {m['frames_with_replacement']}/{m['frames_written']} | {q['neighbour_max_mean_abs_diff']} | {q['flicker_ratio']} | {len(m['warnings'])} |")
            details.append(f"### {i}. {name}\n" + "\n".join(f"- {w}" for w in m["warnings"]) + f"\n- samples: `{out / f'{i:02d}' / 'samples'}`\n")
        except BaseException as e:  # noqa: BLE001
            lines.append(f"| {i} | {name} | FAILED: {str(e)[:80]} | | | | | |")
    (out / "evaluation_report.md").write_text("\n".join(lines + ["", *details]))
    print("\n".join(lines))


if __name__ == "__main__":
    main()
