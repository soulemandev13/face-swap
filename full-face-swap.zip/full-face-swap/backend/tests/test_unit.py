import numpy as np
import pytest
from fastapi import HTTPException

from app.core import security
from app.vision import landmarks as L
from app.vision.analyzer import MediaPipeAnalyzer
from app.vision.engines import warp_mesh
from app.vision.temporal import TargetFace, apply_fade_gains, build_target_series
from app.vision.tracker import FaceTracker


def test_path_traversal_blocked(tmp_path):
    with pytest.raises(HTTPException):
        security.resolve_within(tmp_path, "../etc/passwd")
    assert security.resolve_within(tmp_path, "a.mp4").parent == tmp_path.resolve()


def test_ids_and_names():
    with pytest.raises(HTTPException):
        security.check_id("../../x", "vid")
    assert security.display_name("../../evil name!.mp4") == "evil name_.mp4"
    with pytest.raises(HTTPException):
        security.safe_ext("x.exe", security.ALLOWED_VIDEO_EXT)


def test_detect_pose_symmetry(face_img):
    import cv2
    a = MediaPipeAnalyzer()
    d = a.detect(face_img)[0]
    f = a.detect(cv2.flip(face_img, 1))[0]
    assert abs(d.pose[0] + f.pose[0]) < 6          # mirrored image -> opposite yaw
    assert 0.2 < d.ear[0] < 0.45 and d.mar >= 0


def test_multi_face_tiled_detection(face_img):
    import cv2
    a = MediaPipeAnalyzer()
    three = np.hstack([face_img, cv2.flip(face_img, 1), face_img])
    assert len(a.detect(three)) == 3


def test_tracker_keeps_ids_and_reassociates(face_img):
    import cv2
    a = MediaPipeAnalyzer()
    two = np.hstack([face_img, cv2.flip(face_img, 1)])
    tr = FaceTracker()
    for i in range(6):
        tr.update(i, a.detect(two), two)
    ids = tr.finalize()
    assert len(ids) == 2 and all(len(t.dets) == 6 for t in ids)


def test_identity_warp_is_near_lossless(face_img):
    a = MediaPipeAnalyzer()
    d = a.detect(face_img)[0]
    ctrl = L.mesh_control_points(d.lm)
    from scipy.spatial import Delaunay
    tris = Delaunay(ctrl).simplices.astype(np.int32)
    out, cov = warp_mesh(face_img, ctrl, ctrl, tris, face_img.shape[:2])
    m = cov > 0
    assert m.sum() > 5000
    assert np.abs(out[m].astype(int) - face_img[m].astype(int)).mean() < 2.0


def _fake_track(n=30, jump_at=None):
    rng = np.random.default_rng(0)
    base = rng.normal(size=(478, 3)).astype(np.float32) * 20 + 200
    lm = np.stack([base + rng.normal(scale=0.8, size=base.shape) for _ in range(n)]).astype(np.float32)
    if jump_at is not None:
        lm[jump_at] += 300
    fr = np.arange(n)
    return {"frames": fr, "lm": lm, "conf": np.ones(n, np.float32)}


def test_smoothing_reduces_jitter_and_rejects_outliers():
    raw = _fake_track()
    ser = build_target_series(raw, 1, 0.8)
    a = np.stack([ser[f].lm for f in sorted(ser)])
    assert np.diff(a, axis=0).std() < np.diff(raw["lm"], axis=0).std()
    j = _fake_track(jump_at=10)
    s2 = build_target_series(j, 1, 0.5)
    assert 10 in s2 and s2[10].interpolated      # outlier dropped then interpolated


def test_gap_interpolation_limit():
    t = _fake_track(20)
    keep = [i for i in range(20) if i not in (5, 6, 12, 13, 14, 15, 16, 17, 18)]
    d = {k: v[keep] for k, v in t.items()}
    s = build_target_series(d, 1, 0.3, max_interp=3)
    assert 5 in s and 6 in s and 14 not in s


def test_fade_gain_ramps():
    faces = {f: TargetFace(f, 1, np.zeros((478, 3), np.float32), 1, (0, 0, 0), (.3, .3), 0) for f in range(10, 30)}
    active = {f: not (18 <= f <= 20) for f in faces}
    apply_fade_gains(faces, active, 100)
    assert faces[19].gain == 0 and 0 < faces[17].gain < 1 and faces[14].gain == 1
