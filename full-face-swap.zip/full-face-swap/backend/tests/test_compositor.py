import numpy as np
import pytest

from app.models.schemas import ProcessingSettings
from app.vision import landmarks as L
from app.vision import masks as M
from app.vision.analyzer import MediaPipeAnalyzer
from app.vision.compositor import Compositor
from app.vision.reference import prepare_reference
from app.vision.temporal import TargetFace


@pytest.fixture(scope="module")
def setup(face_img, ref_png):
    a = MediaPipeAnalyzer()
    det = a.detect(face_img)[0]
    ref = prepare_reference(ref_png, "ref_000000000001", a)
    return face_img, det, ref


def _tf(det, **kw):
    d = dict(frame=0, track_id=1, lm=det.lm, conf=0.9, pose=det.pose, ear=det.ear, mar=det.mar)
    d.update(kw)
    return TargetFace(**d)


def _run(setup, S, **kw):
    img, det, ref = setup
    c = Compositor(S); c.prepare_refs([ref])
    out, info = c.process(img.copy(), _tf(det, **kw), [ref], [], {})
    return img, out, info, det


def test_only_roi_changes_and_modes_scale(setup):
    img, o1, i1, det = _run(setup, ProcessingSettings(replacement_mode="face_only", quality="balanced"))
    _, o2, _, _ = _run(setup, ProcessingSettings(replacement_mode="face_head", quality="balanced"))
    ch1 = (np.abs(o1.astype(int) - img.astype(int)).max(2) > 2)
    ch2 = (np.abs(o2.astype(int) - img.astype(int)).max(2) > 2)
    assert ch1.sum() > 2000 and ch2.sum() >= ch1.sum() * 0.9
    x1, y1, x2, y2 = i1["roi"]
    assert not ch1[:y1].any() and not ch1[y2:].any() and not ch1[:, :x1].any() and not ch1[:, x2:].any()


def test_closed_eye_and_open_mouth_are_preserved(setup):
    img, det = setup[0], setup[1]
    S = ProcessingSettings(quality="balanced")
    _, open_eyes, _, _ = _run(setup, S, ear=(0.30, 0.30))
    _, shut, _, _ = _run(setup, S, ear=(0.08, 0.08))
    ea, _ = M.eye_zones(img.shape[:2], det.lm, 1.0)
    sel = ea > 0.5
    d_open = np.abs(open_eyes.astype(int) - img.astype(int))[sel].mean()
    d_shut = np.abs(shut.astype(int) - img.astype(int))[sel].mean()
    assert d_shut < d_open                      # closed-eye region stays closer to the target's own pixels
    mm = M.inner_mouth(img.shape[:2], det.lm) > 0.9
    if mm.sum() > 20:                           # smiling-with-teeth photo: inner mouth kept
        keep = np.abs(open_eyes.astype(int) - img.astype(int))[mm].mean()
        outer = np.abs(open_eyes.astype(int) - img.astype(int))[M.skin_core(img.shape[:2], det.lm) > 0.9].mean()
        assert keep < outer


def test_neighbour_is_protected(setup):
    img, det, ref = setup
    S = ProcessingSettings()
    c = Compositor(S); c.prepare_refs([ref])
    nb = det.lm.copy(); nb[:, 0] += 25               # a heavily overlapping second face
    out, _ = c.process(img.copy(), _tf(det), [ref], [nb], {})
    prot = M.fill_poly(img.shape[:2], M.scale_poly(nb[L.FACE_OVAL, :2], 1.0)) > 0.99
    inner = np.abs(out.astype(int) - img.astype(int)).max(2)[prot]
    assert inner.mean() < 1.0


def test_zero_gain_is_identity(setup):
    img, out, _, _ = _run(setup, ProcessingSettings(), gain=0.0)
    assert np.array_equal(img, out)
