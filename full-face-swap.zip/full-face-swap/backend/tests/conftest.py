import os
import subprocess
import sys
import tempfile
from pathlib import Path

import cv2
import numpy as np
import pytest

_tmp = tempfile.mkdtemp(prefix="ffs_test_")
os.environ["FFS_DATA_DIR"] = _tmp
os.environ["FFS_MODELS_DIR"] = str(Path(_tmp) / "models")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def _face_image():
    from skimage import data
    return cv2.cvtColor(data.astronaut(), cv2.COLOR_RGB2BGR)


@pytest.fixture(scope="session")
def face_img():
    return _face_image()


@pytest.fixture(scope="session")
def two_person_clip(tmp_path_factory):
    """1024x512, 2.0 s, audio tone: left = original face, right = mirrored face (a second 'person')."""
    img = _face_image()
    two = np.hstack([img, cv2.flip(img, 1)])
    out = tmp_path_factory.mktemp("clips") / "two.mp4"
    cmd = ["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", "1024x512", "-r", "25", "-i", "-",
           "-f", "lavfi", "-i", "sine=frequency=440:duration=2", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(out)]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for i in range(50):
        M = cv2.getRotationMatrix2D((512, 256), 1.5 * np.sin(i / 8), 1.0 + 0.02 * np.sin(i / 10))
        p.stdin.write(cv2.warpAffine(two, M, (1024, 512), borderMode=cv2.BORDER_REFLECT).tobytes())
    p.stdin.close(); p.wait()
    return out


@pytest.fixture(scope="session")
def ref_png(tmp_path_factory, face_img):
    p = tmp_path_factory.mktemp("refs") / "ref.png"
    r = face_img.astype(np.float32); r[..., 0] *= 1.15; r[..., 2] *= 0.85
    cv2.imwrite(str(p), np.clip(r * 0.9, 0, 255).astype(np.uint8))
    return p


@pytest.fixture(scope="session")
def client():
    from fastapi.testclient import TestClient
    from app.main import app
    with TestClient(app) as c:
        yield c
