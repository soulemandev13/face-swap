import time
from pathlib import Path


def wait(client, url, key="status", done=("completed", "failed", "cancelled"), timeout=120):
    t = time.time()
    while time.time() - t < timeout:
        j = client.get(url).json()
        if j.get(key) in done:
            return j
        time.sleep(0.4)
    raise TimeoutError(url)


def upload(client, clip):
    with open(clip, "rb") as f:
        r = client.post("/api/videos/upload", files={"file": ("my clip.mp4", f, "video/mp4")})
    assert r.status_code == 200, r.text
    return r.json()


def test_system_and_security(client):
    s = client.get("/api/system").json()
    assert s["engines"]["mesh_warp"]["available"] and s["ffmpeg"]["ffmpeg"]
    assert "consent" in s["consent_text"].lower()
    assert client.get("/api/videos/vid_../etc").status_code in (400, 404)
    assert client.get("/", headers={"host": "evil.example"}).status_code == 400    # DNS-rebinding guard


def test_bad_uploads_are_rejected(client, tmp_path):
    r = client.post("/api/videos/upload", files={"file": ("a.exe", b"MZ", "application/octet-stream")})
    assert r.status_code == 415
    r = client.post("/api/videos/upload", files={"file": ("a.mp4", b"not a video", "video/mp4")})
    assert r.status_code == 422 and "corrupt" in r.json()["detail"].lower()


def test_reference_requires_consent_and_face(client, ref_png, tmp_path):
    with open(ref_png, "rb") as f:
        assert client.post("/api/reference/upload", files={"file": ("r.png", f, "image/png")}, data={"consent_ack": "false"}).status_code == 400
    import cv2, numpy as np
    blank = tmp_path / "blank.png"; cv2.imwrite(str(blank), np.full((300, 300, 3), 120, np.uint8))
    with open(blank, "rb") as f:
        r = client.post("/api/reference/upload", files={"file": ("b.png", f, "image/png")}, data={"consent_ack": "true"})
    assert r.status_code == 422 and "no face" in r.json()["detail"].lower()


def test_full_flow_multi_face_preview_render_cancel_delete(client, two_person_clip, ref_png):
    v = upload(client, two_person_clip)
    vid = v["id"]
    assert v["info"]["has_audio"] and v["name"] == "my clip.mp4"
    with open(ref_png, "rb") as f:
        ref = client.post("/api/reference/upload", files={"file": ("r.png", f, "image/png")}, data={"consent_ack": "true"}).json()
    assert ref["consent_ack"]

    # cannot render before analysis
    body = {"video_id": vid, "reference_ids": [ref["id"]], "target_track_ids": [1], "consent_ack": True}
    assert client.post("/api/jobs/render", json=body).status_code == 409

    assert client.post("/api/analyze", json={"video_id": vid}).status_code == 200
    a = wait(client, f"/api/analysis/{vid}")
    assert a["status"] == "completed", a
    tracks = a["summary"]["tracks"]
    assert len(tracks) == 2                                              # both people found, separate ids
    assert client.get(f"/api/analysis/{vid}/boxes").json()["tracks"]
    assert client.get(f"/api/analysis/{vid}/thumb/{tracks[0]['id']}").status_code == 200
    left = min(tracks, key=lambda t: t["x_center"])["id"]

    # consent is enforced server-side
    assert client.post("/api/jobs/preview", json={**body, "target_track_ids": [left], "consent_ack": False}).status_code == 400
    assert client.post("/api/jobs/preview", json={**body, "target_track_ids": [99]}).status_code == 422

    body["target_track_ids"] = [left]
    body["settings"] = {"quality": "draft", "comparison": True}
    j = client.post("/api/jobs/preview", json=body).json()
    j = wait(client, f"/api/jobs/{j['id']}")
    assert j["status"] == "completed", j
    m = j["metrics"]
    assert m["quality_checks"]["neighbour_max_mean_abs_diff"] == 0.0      # other person untouched
    assert m["verify"]["readable"] and m["verify"]["has_audio"]
    r = client.get(f"/api/jobs/{j['id']}/preview", headers={"Range": "bytes=0-99"})
    assert r.status_code == 206 and len(r.content) == 100
    assert client.get(f"/api/jobs/{j['id']}/result").status_code == 404   # preview job has no 'result'
    assert client.get(f"/api/jobs/{j['id']}/preview?variant=compare").status_code == 200
    assert client.get(f"/api/jobs/{j['id']}/logs").json()

    # full render, then cancel path
    body["settings"] = {"quality": "balanced", "output_name": "my result", "label_ai_visible": True}
    j2 = client.post("/api/jobs/render", json=body).json()
    j2 = wait(client, f"/api/jobs/{j2['id']}")
    assert j2["status"] == "completed" and j2["output_ready"]
    d = client.get(f"/api/jobs/{j2['id']}/result?download=1")
    assert d.status_code == 200 and "my result.mp4" in d.headers["content-disposition"]
    import subprocess, json
    p = Path(j2["metrics"]["verify"] and client.app.state.__dict__.get("x", "")) if False else None
    tags = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format_tags=comment", "-of", "json", "-"], input=d.content, capture_output=True).stdout
    assert b"AI-edited" in tags                                             # AI label metadata present

    j3 = client.post("/api/jobs/render", json=body).json()
    client.post(f"/api/jobs/{j3['id']}/pause"); client.post(f"/api/jobs/{j3['id']}/resume")
    client.post(f"/api/jobs/{j3['id']}/cancel")
    assert wait(client, f"/api/jobs/{j3['id']}")["status"] in ("cancelled", "completed")

    # delete controls
    assert client.delete(f"/api/jobs/{j2['id']}").status_code == 200
    assert not (Path(__import__("app.core.config", fromlist=["x"]).get_settings().outputs_dir) / j2["id"]).exists()
    assert client.delete(f"/api/videos/{vid}").status_code == 200
    assert client.get(f"/api/videos/{vid}").status_code == 404
