"""Render pipeline: analysis data + references + settings -> processed MP4 (+ report, samples)."""
from __future__ import annotations

import json
import logging
import shutil
import time
from pathlib import Path

import cv2
import numpy as np

from ..core.config import get_settings
from ..media import ffmpeg as ff
from ..models.schemas import RES_MAX_SIDE, ProcessingSettings
from ..vision import landmarks as L
from ..vision.analyzer import MediaPipeAnalyzer
from ..vision.compositor import Compositor
from ..vision.engines import get_engine
from ..vision.reference import ReferenceError, RefBundle, prepare_reference
from ..vision.temporal import TargetFace, apply_fade_gains, build_target_series
from ..workers.control import Cancelled, JobControl
from . import analysis as an

log = logging.getLogger("render")


class RenderError(Exception):
    """Human-readable failure (shown to the operator as-is)."""


def draw_badge(frame: np.ndarray, text: str = "AI-edited") -> None:
    h, w = frame.shape[:2]
    sc = max(0.4, min(w, h * 1.6) / 1400.0 * 0.7)
    th = max(1, int(round(sc * 1.6)))
    (tw, tht), bl = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, sc, th)
    pad = int(8 * sc + 4)
    x, y = pad, h - pad
    ov = frame[y - tht - pad: y + bl + pad // 2, x - pad // 2: x + tw + pad].copy()
    if ov.size == 0:
        return
    frame[y - tht - pad: y + bl + pad // 2, x - pad // 2: x + tw + pad] = (ov * 0.4).astype(np.uint8)
    cv2.putText(frame, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, sc, (255, 255, 255), th, cv2.LINE_AA)


class QualityMeter:
    """Cheap in-loop checks: neighbour protection and flicker."""

    def __init__(self):
        self.prot_max = 0.0
        self.prot_changed = 0
        self.prot_pixels = 0
        self.flick_in: list[float] = []
        self.flick_out: list[float] = []
        self._prev: tuple[np.ndarray, np.ndarray, int] | None = None

    def protection(self, before: np.ndarray, after: np.ndarray, boxes: list[np.ndarray]) -> None:
        H, W = before.shape[:2]
        for b in boxes:
            x1, y1, x2, y2 = int(max(0, b[0])), int(max(0, b[1])), int(min(W, b[2])), int(min(H, b[3]))
            if x2 <= x1 or y2 <= y1:
                continue
            d = np.abs(before[y1:y2, x1:x2].astype(np.int16) - after[y1:y2, x1:x2].astype(np.int16)).max(2)
            self.prot_max = max(self.prot_max, float(d.mean()))
            self.prot_changed += int((d > 0).sum())
            self.prot_pixels += d.size

    def flicker(self, idx: int, before: np.ndarray, after: np.ndarray, bbox: np.ndarray) -> None:
        H, W = before.shape[:2]
        x1, y1, x2, y2 = int(max(0, bbox[0])), int(max(0, bbox[1])), int(min(W, bbox[2])), int(min(H, bbox[3]))
        if x2 - x1 < 8 or y2 - y1 < 8:
            self._prev = None
            return
        g = lambda im: cv2.resize(cv2.cvtColor(im[y1:y2, x1:x2], cv2.COLOR_BGR2GRAY), (48, 48), interpolation=cv2.INTER_AREA).astype(np.float32)
        gi, go = g(before), g(after)
        if self._prev is not None and self._prev[2] == idx - 1:
            pi_, po_ = self._prev[0], self._prev[1]
            self.flick_in.append(float(np.abs(gi - pi_).mean()))
            self.flick_out.append(float(np.abs(go - po_).mean()))
        self._prev = (gi, go, idx)  # note: bbox may move; both sequences use the same crop each frame

    def summary(self) -> dict:
        fi = float(np.mean(self.flick_in)) if self.flick_in else 0.0
        fo = float(np.mean(self.flick_out)) if self.flick_out else 0.0
        return {
            "neighbour_max_mean_abs_diff": round(self.prot_max, 4),
            "neighbour_changed_pixel_fraction": round(self.prot_changed / self.prot_pixels, 6) if self.prot_pixels else 0.0,
            "temporal_diff_input": round(fi, 3), "temporal_diff_output": round(fo, 3),
            "flicker_ratio": round(fo / fi, 3) if fi > 0.2 else None,
        }


def run_render(*, job_id: str, kind: str, video_path: Path, info: ff.VideoInfo, video_id: str,
               ref_paths: list[tuple[str, Path]], target_ids: list[int], S: ProcessingSettings,
               out_dir: Path, ctl: JobControl) -> dict:
    cfg = get_settings()
    t_start = time.time()
    out_dir.mkdir(parents=True, exist_ok=True)
    warnings: list[str] = []

    # ---- engine -------------------------------------------------------------------------------
    eng_name, neural, note = get_engine(S.engine if S.engine != "auto" else cfg.default_engine)
    ctl.info(f"Engine: {eng_name} — {note}")

    # ---- analysis data ------------------------------------------------------------------------
    tracks = an.load_tracks(video_id)
    if not tracks:
        raise RenderError("This video has not been analysed yet (or no faces were found). Run Analyze first.")
    missing = [t for t in target_ids if t not in tracks]
    if missing:
        raise RenderError(f"Selected track(s) {missing} do not exist. Re-run analysis or pick from the detected people list.")

    # ---- references ---------------------------------------------------------------------------
    analyzer = MediaPipeAnalyzer(max_faces=4)
    refs: list[RefBundle] = []
    try:
        for rid, p in ref_paths:
            try:
                rb = prepare_reference(p, rid, analyzer)
            except ReferenceError as e:
                raise RenderError(f"Reference {rid}: {e}")
            for w in rb.quality.get("warnings", []):
                ctl.warn(f"Reference {rid}: {w}")
            refs.append(rb)
    finally:
        analyzer.close()
    comp = Compositor(S, neural)
    try:
        comp.prepare_refs(refs)
    except Exception as e:
        raise RenderError(f"The identity engine could not prepare the reference: {e}")

    # ---- time window ----------------------------------------------------------------------------
    dur = info.duration
    if kind == "preview":
        start = min(S.preview_start_s, max(0.0, dur - 0.5))
        seg_dur = min(S.preview_duration_s, dur - start)
    else:
        start, seg_dur = 0.0, dur
    r0 = S.replace_start_s if S.replace_start_s is not None else 0.0
    r1 = S.replace_end_s if S.replace_end_s is not None else dur
    out_fps = S.output_fps or info.fps
    if kind == "preview":
        max_side = S.preview_max_side
    else:
        max_side = RES_MAX_SIDE.get(S.output_resolution)
    out_w, out_h = ff.scaled_size(info.width, info.height, max_side)
    sx, sy = out_w / info.width, out_h / info.height
    ctl.info(f"{kind}: {start:.2f}s +{seg_dur:.2f}s → {out_w}x{out_h} @ {out_fps:g}fps, quality={S.quality}, mode={S.replacement_mode}")

    # ---- target series (smoothed) + neighbours ---------------------------------------------------
    series: dict[int, dict[int, TargetFace]] = {t: build_target_series(tracks[t], t, S.temporal_smoothing) for t in target_ids}
    others_raw: dict[int, list[tuple[int, np.ndarray, np.ndarray]]] = {}
    for tid, d in tracks.items():
        if tid in target_ids:
            continue
        for k, f in enumerate(d["frames"]):
            others_raw.setdefault(int(f), []).append((tid, d["lm"][k], d["bbox"][k]))
    n_frames_src = int(round(info.duration * info.fps))
    fps_ratio = info.fps / out_fps
    f_lo = int(round(start * info.fps)); f_hi = int(round((start + seg_dur) * info.fps))
    stats = {"low_confidence": 0, "overlap_skipped": 0, "outside_range": 0, "interpolated": 0}
    for tid, faces in series.items():
        active: dict[int, bool] = {}
        for f, tf in faces.items():
            t_s = f / info.fps
            if t_s < r0 or t_s > r1:
                tf.skip_reason = "range"; active[f] = False
                if f_lo <= f <= f_hi:
                    stats["outside_range"] += 1
                continue
            if tf.conf < S.min_confidence:
                tf.skip_reason = "low_confidence"; active[f] = False
                if f_lo <= f <= f_hi:
                    stats["low_confidence"] += 1
                continue
            amb = False
            if S.overlap_policy == "skip":
                bb = L.bbox_of(tf.lm)
                amb = any(L.iou(bb, o[2]) > S.overlap_iou for o in others_raw.get(f, []))
            if amb:
                tf.skip_reason = "overlap"; active[f] = False
                if f_lo <= f <= f_hi:
                    stats["overlap_skipped"] += 1
                continue
            active[f] = True
            if tf.interpolated and f_lo <= f <= f_hi:
                stats["interpolated"] += 1
        apply_fade_gains(faces, active, n_frames_src)
    if stats["overlap_skipped"]:
        warnings.append(f"{stats['overlap_skipped']} frame(s) were left unchanged because the target overlapped another person (safer than guessing). Review these or set overlap policy to 'proceed'.")
    if stats["low_confidence"]:
        warnings.append(f"{stats['low_confidence']} frame(s) were left unchanged because detection confidence was below {S.min_confidence:.2f}.")

    in_window = {f for faces in series.values() for f, tf in faces.items() if f_lo <= f <= f_hi and tf.skip_reason is None}
    if not in_window:
        raise RenderError("The selected person is not (reliably) present in the processed time window. "
                          "For previews, move the preview start to when the person is visible; also check overlap/confidence settings.")

    # ---- IO ----------------------------------------------------------------------------------------
    out_path = out_dir / ("preview.mp4" if kind == "preview" else "output.mp4")
    reader = ff.FrameReader(video_path, info, start_s=start, duration_s=seg_dur, out_size=(out_w, out_h), fps=out_fps)
    meta = ff.ai_metadata(f"engine={eng_name} mode={S.replacement_mode} job={job_id}")
    writer = ff.FrameWriter(out_path, (out_w, out_h), out_fps,
                            audio_src=video_path if (S.keep_audio and info.has_audio) else None,
                            start_s=start, duration_s=seg_dur, quality=S.quality, metadata=meta)
    total = int(round(seg_dur * out_fps))
    qm = QualityMeter()
    states: dict[int, dict] = {t: {} for t in target_ids}
    sample_at = set(np.linspace(0, max(total - 1, 1), 6).astype(int).tolist()) if S.save_samples else set()
    sample_dir = out_dir / "samples"
    n_proc = n_written = 0
    try:
        for ridx, frame in reader:
            ctl.checkpoint()
            src_idx = int(round(ridx * fps_ratio))
            before = frame
            work = frame.copy() if (src_idx in in_window or src_idx in others_raw) else frame
            did = False
            for tid, faces in series.items():
                tf = faces.get(src_idx)
                if tf is None or tf.skip_reason is not None or tf.gain <= 0:
                    continue
                scaled = TargetFace(frame=tf.frame, track_id=tid, lm=tf.lm * np.array([sx, sy, sx], np.float32), conf=tf.conf,
                                    pose=tf.pose, ear=tf.ear, mar=tf.mar, interpolated=tf.interpolated, gain=tf.gain)
                oth = [o[1] * np.array([sx, sy, sx], np.float32) for o in others_raw.get(src_idx, [])]
                work, res = comp.process(work, scaled, refs, oth, states[tid])
                did = did or "skipped" not in res
                if did and len(series) == 1:
                    qm.flicker(ridx, before, work, L.bbox_of(scaled.lm))
            if did:
                n_proc += 1
                if src_idx in others_raw:
                    qm.protection(before, work, [o[2] * np.array([sx, sy, sx, sy], np.float32) for o in others_raw[src_idx]])
            if S.label_ai_visible:
                draw_badge(work)
            writer.write(work)
            n_written += 1
            if (ridx - reader.start_frame) in sample_at and did:
                sample_dir.mkdir(exist_ok=True)
                pair = np.hstack([before, work])
                k = 640.0 / max(pair.shape[1], 1)
                cv2.imwrite(str(sample_dir / f"frame_{ridx:06d}.jpg"), cv2.resize(pair, None, fx=min(1.0, k * 1.0) if k < 1 else 1.0, fy=min(1.0, k) if k < 1 else 1.0), [cv2.IMWRITE_JPEG_QUALITY, 85])
            ctl.progress(kind, n_written, total, processed=n_proc)
        writer.close()
    except Cancelled:
        writer.close(abort=True)
        out_path.unlink(missing_ok=True)
        raise
    except Exception:
        writer.close(abort=True)
        raise
    finally:
        reader.close()
    ctl.progress(kind, total, total, force=True, processed=n_proc)
    if n_written == 0:
        raise RenderError("No frames could be decoded from the video. " + reader.error_text())

    # ---- verification, comparison, report ------------------------------------------------------
    verify = ff.verify_output(out_path, seg_dur, n_written, S.keep_audio and info.has_audio)
    if not verify.get("readable"):
        raise RenderError("The output file could not be opened after encoding: " + verify.get("error", "unknown"))
    if not verify.get("duration_ok"):
        warnings.append(f"Output duration {verify['duration']:.2f}s differs from expected {seg_dur:.2f}s.")
    if S.keep_audio and info.has_audio and not verify.get("has_audio"):
        warnings.append("Audio could not be carried over to the output.")
    comp_path = None
    if S.comparison:
        try:
            comp_path = out_dir / ("preview_compare.mp4" if kind == "preview" else "comparison.mp4")
            ff.hstack_compare(video_path, out_path, comp_path, start_s=start, dur_s=seg_dur, fps=out_fps)
        except ff.MediaError as e:
            warnings.append(str(e)); comp_path = None
    qsum = qm.summary()
    if qsum["neighbour_max_mean_abs_diff"] > 0.5:
        warnings.append("Neighbouring faces were modified — please review; this should not happen.")
    if qsum["flicker_ratio"] and qsum["flicker_ratio"] > 1.8:
        warnings.append(f"Output flickers more than the source (ratio {qsum['flicker_ratio']}). Increase temporal smoothing.")
    elapsed = time.time() - t_start
    metrics = {
        "engine": eng_name, "engine_note": note, "mode": S.replacement_mode, "quality": S.quality, "kind": kind,
        "frames_written": n_written, "frames_with_replacement": n_proc, "output_resolution": f"{out_w}x{out_h}",
        "duration_s": round(seg_dur, 2), "processing_time_s": round(elapsed, 1),
        "processing_fps": round(n_written / max(elapsed, 1e-6), 2), "skips": stats, "quality_checks": qsum,
        "verify": verify, "warnings": warnings,
        "references": [{"id": r.id, **{k: v for k, v in r.quality.items() if k != "warnings"}} for r in refs],
        "ai_label": {"metadata": True, "visible_badge": S.label_ai_visible},
        "comparison_path": str(comp_path) if comp_path else None,
    }
    (out_dir / "report.json").write_text(json.dumps(metrics, indent=2))
    if not cfg.retain_temp:
        shutil.rmtree(cfg.temp_dir / job_id, ignore_errors=True)
    return {"output_path": str(out_path), "metrics": metrics}
