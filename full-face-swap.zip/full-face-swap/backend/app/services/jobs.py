"""Job manager: one background worker (GPU-friendly), cancel / pause / resume, persisted
status + logs in SQLite, progress held in memory for snappy polling."""
from __future__ import annotations

import errno
import logging
import shutil
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .. import db
from ..core.config import get_settings
from ..core.security import new_id
from ..media import ffmpeg as ff
from ..models.schemas import JobRequest, ProcessingSettings
from ..vision.reference import ReferenceError
from ..workers.control import Cancelled, JobControl
from . import analysis as an
from . import render as rd

log = logging.getLogger("jobs")

CONSENT_TEXT = (
    "I confirm that I own, or have permission to use, the video and the reference image, and that every person "
    "whose likeness appears or is used has consented to this edit. I will not use the result to impersonate, "
    "defraud, harass or mislead anyone, and I understand the output is labelled as AI-edited."
)


class JobManager:
    def __init__(self):
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="worker")
        self.proxy_pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="proxy")
        self.controls: dict[str, JobControl] = {}
        self.progress: dict[str, dict] = {}
        self.analysis_progress: dict[str, dict] = {}
        self._lock = threading.Lock()

    # ---- lifecycle -------------------------------------------------------------------
    def recover(self) -> None:
        """Anything left 'running/queued' by a previous process was interrupted."""
        db.execute("UPDATE jobs SET status='failed', error='Interrupted by an application restart.', finished_at=? "
                   "WHERE status IN ('queued','running','paused')", (db.now(),))
        db.execute("UPDATE analyses SET status='failed', error='Interrupted by an application restart.' "
                   "WHERE status IN ('queued','running')")
        db.execute("UPDATE videos SET proxy_status='failed' WHERE proxy_status IN ('queued','running')")

    # ---- logging ---------------------------------------------------------------------
    def _logger(self, job_id: str):
        path = get_settings().logs_dir / f"{job_id}.log"

        def on_log(level: str, msg: str) -> None:
            ts = db.now()
            db.execute("INSERT INTO job_logs(job_id, ts, level, message) VALUES(?,?,?,?)", (job_id, ts, level, msg))
            try:
                with open(path, "a", encoding="utf-8") as f:
                    f.write(f"{time.strftime('%H:%M:%S', time.localtime(ts))} {level:<7} {msg}\n")
            except OSError:
                pass
            getattr(log, "warning" if level == "WARNING" else "error" if level == "ERROR" else "info")("[%s] %s", job_id, msg)
        return on_log

    # ---- proxy -----------------------------------------------------------------------
    def submit_proxy(self, video_id: str) -> None:
        db.execute("UPDATE videos SET proxy_status='queued' WHERE id=?", (video_id,))

        def work():
            v = db.one("SELECT * FROM videos WHERE id=?", (video_id,))
            if not v:
                return
            db.execute("UPDATE videos SET proxy_status='running' WHERE id=?", (video_id,))
            try:
                info = ff.VideoInfo.from_dict(db.jload(v["info"]))
                dst = get_settings().analysis_dir / video_id / "proxy.mp4"
                dst.parent.mkdir(parents=True, exist_ok=True)
                ff.make_proxy(Path(v["path"]), dst, info)
                db.execute("UPDATE videos SET proxy_path=?, proxy_status='ready' WHERE id=?", (str(dst), video_id))
            except Exception as e:
                log.warning("proxy failed for %s: %s", video_id, e)
                db.execute("UPDATE videos SET proxy_status='failed' WHERE id=?", (video_id,))
        self.proxy_pool.submit(work)

    # ---- analysis ----------------------------------------------------------------------
    def submit_analysis(self, video_id: str) -> None:
        key = "an_" + video_id
        db.execute("INSERT OR REPLACE INTO analyses(video_id,status,progress,created_at,summary,error) VALUES(?,?,?,?,?,?)",
                   (video_id, "queued", 0.0, db.now(), None, None))
        ctl = JobControl(on_log=self._logger(key), on_progress=lambda p: self.analysis_progress.__setitem__(video_id, p))
        self.controls[key] = ctl
        self.pool.submit(self._run_analysis, video_id, ctl)

    def _run_analysis(self, video_id: str, ctl: JobControl) -> None:
        key = "an_" + video_id
        v = db.one("SELECT * FROM videos WHERE id=?", (video_id,))
        if not v:
            return
        db.execute("UPDATE analyses SET status='running' WHERE video_id=?", (video_id,))
        try:
            info = ff.VideoInfo.from_dict(db.jload(v["info"]))
            summary = an.run_analysis(video_id, Path(v["path"]), info, ctl)
            db.execute("UPDATE analyses SET status='completed', progress=100, finished_at=?, summary=? WHERE video_id=?",
                       (db.now(), db.jdump(summary), video_id))
        except Cancelled:
            db.execute("UPDATE analyses SET status='cancelled', finished_at=? WHERE video_id=?", (db.now(), video_id))
        except Exception as e:
            log.exception("analysis failed")
            msg = self._friendly(e)
            ctl.error(msg)
            db.execute("UPDATE analyses SET status='failed', error=?, finished_at=? WHERE video_id=?", (msg, db.now(), video_id))
        finally:
            self.controls.pop(key, None)

    # ---- render jobs -----------------------------------------------------------------
    def submit_job(self, kind: str, req: JobRequest) -> str:
        job_id = new_id("job")
        db.execute("INSERT INTO jobs(id,kind,status,created_at,video_id,reference_ids,target_track_ids,settings,progress,output_name) "
                   "VALUES(?,?,?,?,?,?,?,?,?,?)",
                   (job_id, kind, "queued", db.now(), req.video_id, db.jdump(req.reference_ids), db.jdump(req.target_track_ids),
                    req.settings.model_dump_json(), db.jdump({"stage": "queued", "percent": 0}), req.settings.output_name))
        ctl = JobControl(on_log=self._logger(job_id), on_progress=lambda p, j=job_id: self._on_progress(j, p))
        self.controls[job_id] = ctl
        ctl.info(f"{kind} job queued")
        self.pool.submit(self._run_job, job_id, ctl)
        return job_id

    def _on_progress(self, job_id: str, p: dict) -> None:
        p = {**p, "paused": bool(self.controls.get(job_id) and self.controls[job_id].paused)}
        self.progress[job_id] = p

    def _run_job(self, job_id: str, ctl: JobControl) -> None:
        cfg = get_settings()
        row = db.one("SELECT * FROM jobs WHERE id=?", (job_id,))
        if not row:
            return
        if ctl.cancelled:
            db.execute("UPDATE jobs SET status='cancelled', finished_at=? WHERE id=?", (db.now(), job_id))
            return
        db.execute("UPDATE jobs SET status='running', started_at=? WHERE id=?", (db.now(), job_id))
        out_dir = cfg.outputs_dir / job_id
        try:
            free = shutil.disk_usage(cfg.outputs_dir).free
            if free < 300 * 1024 * 1024:
                raise rd.RenderError(f"Only {free // (1024 * 1024)} MB of disk space is free; at least 300 MB is required. Free some space or delete old jobs.")
            v = db.one("SELECT * FROM videos WHERE id=?", (row["video_id"],))
            if not v:
                raise rd.RenderError("The source video no longer exists.")
            info = ff.VideoInfo.from_dict(db.jload(v["info"]))
            refs = []
            for rid in db.jload(row["reference_ids"], []):
                r = db.one("SELECT * FROM refs WHERE id=?", (rid,))
                if not r:
                    raise rd.RenderError(f"Reference {rid} no longer exists.")
                refs.append((rid, Path(r["path"])))
            S = ProcessingSettings.model_validate_json(row["settings"])
            result = rd.run_render(job_id=job_id, kind=row["kind"], video_path=Path(v["path"]), info=info, video_id=row["video_id"],
                                   ref_paths=refs, target_ids=db.jload(row["target_track_ids"], []), S=S, out_dir=out_dir, ctl=ctl)
            for w in result["metrics"]["warnings"]:
                ctl.warn(w)
            ctl.info(f"Finished in {result['metrics']['processing_time_s']}s ({result['metrics']['processing_fps']} fps)")
            db.execute("UPDATE jobs SET status='completed', finished_at=?, output_path=?, metrics=? WHERE id=?",
                       (db.now(), result["output_path"], db.jdump(result["metrics"]), job_id))
            self.progress[job_id] = {**self.progress.get(job_id, {}), "stage": "done", "percent": 100.0}
        except Cancelled:
            ctl.info("Cancelled by operator; partial output removed")
            shutil.rmtree(out_dir, ignore_errors=True)
            db.execute("UPDATE jobs SET status='cancelled', finished_at=? WHERE id=?", (db.now(), job_id))
        except Exception as e:
            msg = self._friendly(e)
            if not isinstance(e, (rd.RenderError, ff.MediaError, ReferenceError)):
                log.exception("job %s crashed", job_id)
            ctl.error(msg)
            if not cfg.retain_temp:
                shutil.rmtree(out_dir, ignore_errors=True)
            db.execute("UPDATE jobs SET status='failed', finished_at=?, error=? WHERE id=?", (db.now(), msg, job_id))
        finally:
            self.controls.pop(job_id, None)
            if not cfg.retain_temp:
                shutil.rmtree(cfg.temp_dir / job_id, ignore_errors=True)

    @staticmethod
    def _friendly(e: Exception) -> str:
        if isinstance(e, (rd.RenderError, ff.MediaError, ReferenceError)):
            return str(e)
        if isinstance(e, OSError) and e.errno == errno.ENOSPC:
            return "The disk is full. The job was stopped safely and logs were preserved. Free disk space and retry."
        if isinstance(e, MemoryError):
            return "Out of memory. Use a lower output resolution / Draft quality, or process a shorter clip."
        txt = str(e)
        if "CUDA" in txt or "onnxruntime" in txt.lower():
            return f"GPU/model runtime error: {txt[:300]}. Set FFS_USE_GPU=false to run on CPU, or choose the mesh_warp engine."
        return f"Unexpected error ({type(e).__name__}): {txt[:300]}. See the job log for details."

    # ---- controls ----------------------------------------------------------------------
    def _ctl(self, job_id: str) -> JobControl | None:
        return self.controls.get(job_id)

    def cancel(self, job_id: str) -> bool:
        c = self._ctl(job_id)
        if not c:
            return False
        c.cancel()
        return True

    def pause(self, job_id: str) -> bool:
        c = self._ctl(job_id)
        if not c:
            return False
        c.pause()
        db.execute("UPDATE jobs SET status='paused' WHERE id=? AND status='running'", (job_id,))
        return True

    def resume(self, job_id: str) -> bool:
        c = self._ctl(job_id)
        if not c:
            return False
        c.resume()
        db.execute("UPDATE jobs SET status='running' WHERE id=? AND status='paused'", (job_id,))
        return True

    def job_public(self, row: dict) -> dict:
        jid = row["id"]
        prog = self.progress.get(jid) or db.jload(row.get("progress"), {}) or {}
        done = row["status"] == "completed" and row.get("output_path") and Path(row["output_path"]).exists()
        metrics = db.jload(row.get("metrics"), None)
        return {
            "id": jid, "kind": row["kind"], "status": row["status"], "created_at": row["created_at"],
            "started_at": row["started_at"], "finished_at": row["finished_at"], "video_id": row["video_id"],
            "reference_ids": db.jload(row["reference_ids"], []), "target_track_ids": db.jload(row["target_track_ids"], []),
            "settings": db.jload(row["settings"], {}), "progress": prog, "error": row["error"], "metrics": metrics,
            "output_ready": bool(done), "output_name": row.get("output_name"),
            "has_comparison": bool(metrics and metrics.get("comparison_path") and Path(metrics["comparison_path"]).exists()),
            "has_samples": (get_settings().outputs_dir / jid / "samples").exists(),
        }

    def delete_job(self, job_id: str) -> None:
        shutil.rmtree(get_settings().outputs_dir / job_id, ignore_errors=True)
        shutil.rmtree(get_settings().temp_dir / job_id, ignore_errors=True)
        (get_settings().logs_dir / f"{job_id}.log").unlink(missing_ok=True)
        db.execute("DELETE FROM job_logs WHERE job_id=?", (job_id,))
        db.execute("DELETE FROM jobs WHERE id=?", (job_id,))


manager = JobManager()
