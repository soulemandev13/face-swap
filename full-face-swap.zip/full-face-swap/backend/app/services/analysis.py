"""Video analysis: detect all faces, track them, store per-track landmark data,
build selectable contact-sheet thumbnails and flag overlaps / low-confidence spans."""
from __future__ import annotations

import json
import logging
import shutil
from pathlib import Path

import cv2
import numpy as np

from ..core.config import get_settings
from ..media.ffmpeg import FrameReader, VideoInfo, scaled_size
from ..vision import landmarks as L
from ..vision.analyzer import MediaPipeAnalyzer
from ..vision.tracker import FaceTracker
from ..workers.control import JobControl

log = logging.getLogger("analysis")

SCAN_INTERVAL = 8          # frames between full discovery scans (new people entering etc.)


def analysis_dir(video_id: str) -> Path:
    return get_settings().analysis_dir / video_id


def skin_fraction(frame: np.ndarray, lm: np.ndarray) -> float:
    """Share of the face-oval pixels with a skin-like chroma (broad YCrCb range; None-safe for tiny faces)."""
    from ..vision.masks import fill_poly, scale_poly
    x1, y1, x2, y2 = [int(v) for v in L.bbox_of(lm)]
    x1, y1 = max(0, x1), max(0, y1)
    crop = frame[y1:y2, x1:x2]
    if crop.size == 0:
        return 1.0
    m = fill_poly(crop.shape[:2], scale_poly(lm[L.FACE_OVAL, :2] - np.array([x1, y1], np.float32), 0.8)) > 0.5
    if m.sum() < 30:
        return 1.0
    ycc = cv2.cvtColor(crop, cv2.COLOR_BGR2YCrCb)
    cr, cb = ycc[..., 1], ycc[..., 2]
    ok = (cr >= 133) & (cr <= 185) & (cb >= 70) & (cb <= 135)
    return float(ok[m].mean())


def run_analysis(video_id: str, video_path: Path, info: VideoInfo, ctl: JobControl) -> dict:
    s = get_settings()
    out = analysis_dir(video_id)
    out.mkdir(parents=True, exist_ok=True)
    for old in list(out.glob("thumb_*.jpg")) + [out / "tracks.npz", out / "summary.json"]:
        old.unlink(missing_ok=True)      # keep proxy.mp4 (written concurrently by the proxy worker)

    analyzer = MediaPipeAnalyzer(max_faces=s.max_faces, max_side=s.analysis_max_side)
    tracker = FaceTracker(max_gap=max(8, int(info.fps * 0.6)), reid_gap=int(info.fps * 6))
    reader = FrameReader(video_path, info)
    total = max(info.n_frames, 1)
    best_thumb: dict[int, tuple[float, np.ndarray]] = {}
    skin: dict[int, list[float]] = {}
    sat_sum = sat_n = 0.0
    n_seen = 0
    need_scan = True
    ctl.info(f"Analysing {info.width}x{info.height} @ {info.fps}fps, ~{info.n_frames} frames")
    try:
        for idx, frame in reader:
            ctl.checkpoint()
            n_seen = idx + 1
            active = [t for t in tracker.tracks if idx - t.last_frame <= tracker.max_gap and t.last_frame < idx]
            dets = []
            used = set()
            for t in active:                                   # per-track ROI refinement
                d = analyzer.detect_near(frame, t.predict(idx))
                if d is None:
                    continue
                if any(L.iou(d.bbox, e.bbox) > 0.6 for e in dets):  # two tracks grabbed one face
                    continue
                dets.append(d)
            if need_scan or idx % SCAN_INTERVAL == 0 or not active:
                for d in analyzer.detect(frame, thorough=(idx % (SCAN_INTERVAL * 4) == 0 or not active)):
                    c = (d.bbox[:2] + d.bbox[2:]) / 2
                    if not any(L.iou(d.bbox, e.bbox) > 0.3 or (e.bbox[0] < c[0] < e.bbox[2] and e.bbox[1] < c[1] < e.bbox[3]) for e in dets):
                        dets.append(d)
                need_scan = False
            if active and len(dets) < len(active):
                need_scan = True                               # someone lost -> rescan next frame
            tracker.update(idx, dets, frame)
            if idx % 10 == 0:
                sat_sum += float(cv2.cvtColor(frame[::8, ::8], cv2.COLOR_BGR2HSV)[..., 1].mean()); sat_n += 1
                for d in dets:
                    if d.track_id >= 0:
                        skin.setdefault(d.track_id, []).append(skin_fraction(frame, d.lm))
            for d in dets:                                      # thumbnails: best frontal, large, confident frame
                if d.track_id < 0:
                    continue
                fw = L.face_width(d.lm)
                score = d.conf * min(1.0, fw / 160.0) * (1.0 - min(abs(d.pose[0]), 80) / 100.0)
                if score > best_thumb.get(d.track_id, (-1, None))[0]:
                    x1, y1, x2, y2 = d.bbox
                    cx, cy, sz = (x1 + x2) / 2, (y1 + y2) / 2, max(x2 - x1, y2 - y1) * 0.85
                    xa, ya, xb, yb = int(max(0, cx - sz)), int(max(0, cy - sz)), int(min(frame.shape[1], cx + sz)), int(min(frame.shape[0], cy + sz))
                    crop = frame[ya:yb, xa:xb]
                    if crop.size:
                        k = 192.0 / max(crop.shape[:2])
                        best_thumb[d.track_id] = (score, cv2.resize(crop, None, fx=k, fy=k, interpolation=cv2.INTER_AREA))
            ctl.progress("analysis", idx + 1, total)
        err = reader.error_text().strip()
        if err and n_seen == 0:
            raise RuntimeError("FFmpeg could not decode the video: " + err)
    finally:
        reader.close()
        analyzer.close()
    ctl.progress("analysis", total, total, force=True)

    tracks = tracker.finalize()
    grayscale = sat_n > 0 and (sat_sum / sat_n) < 12
    dropped = []
    if not grayscale:
        kept = []
        for t in tracks:
            sk = float(np.mean(skin.get(t.id, [1.0])))
            if sk < 0.25 and len(t.dets) < 0.5 * max(n_seen, 1):
                dropped.append((t.id, sk))
                ctl.info(f"Dropped track {t.id}: short and not skin-coloured (likely a false positive)")
            else:
                kept.append(t)
        tracks = kept
    skin_mean = {t.id: float(np.mean(skin.get(t.id, [1.0]))) for t in tracks}
    arrays: dict[str, np.ndarray] = {"meta": np.array([info.width, info.height, info.fps, n_seen], np.float64)}
    summary_tracks, per_frame = [], {}
    for t in tracks:
        fr = np.array(sorted(t.dets), np.int32)
        dd = [t.dets[int(i)] for i in fr]
        arrays[f"t{t.id}_frames"] = fr
        arrays[f"t{t.id}_lm"] = np.stack([d.lm for d in dd]).astype(np.float32)
        arrays[f"t{t.id}_bbox"] = np.stack([d.bbox for d in dd]).astype(np.float32)
        arrays[f"t{t.id}_conf"] = np.array([d.conf for d in dd], np.float32)
        arrays[f"t{t.id}_pose"] = np.array([d.pose for d in dd], np.float32)
        arrays[f"t{t.id}_ear"] = np.array([d.ear for d in dd], np.float32)
        arrays[f"t{t.id}_mar"] = np.array([d.mar for d in dd], np.float32)
        for i, d in zip(fr, dd):
            per_frame.setdefault(int(i), []).append((t.id, d.bbox))
        thumb = best_thumb.get(t.id)
        if thumb is not None:
            cv2.imwrite(str(out / f"thumb_{t.id}.jpg"), thumb[1], [cv2.IMWRITE_JPEG_QUALITY, 88])
        cx = float(np.mean((arrays[f"t{t.id}_bbox"][:, 0] + arrays[f"t{t.id}_bbox"][:, 2]) / 2) / info.width)
        span = int(fr[-1] - fr[0] + 1)
        summary_tracks.append({
            "id": t.id, "frame_start": int(fr[0]), "frame_end": int(fr[-1]), "n_frames": int(len(fr)),
            "time_start": round(float(fr[0] / info.fps), 2), "time_end": round(float(fr[-1] / info.fps), 2),
            "coverage": round(len(fr) / span, 3), "mean_conf": round(float(arrays[f"t{t.id}_conf"].mean()), 3),
            "min_conf": round(float(arrays[f"t{t.id}_conf"].min()), 3),
            "mean_face_px": round(float(np.mean([L.face_width(d.lm) for d in dd])), 1),
            "x_center": round(cx, 3), "has_thumb": thumb is not None,
            "low_conf_frames": int((arrays[f"t{t.id}_conf"] < 0.5).sum()),
        })
    np.savez(out / "tracks.npz", **arrays)

    # overlaps between different tracks (risky for replacement -> reduced confidence / manual review)
    overlaps: dict[tuple[int, int], list[int]] = {}
    for f, lst in per_frame.items():
        for i in range(len(lst)):
            for j in range(i + 1, len(lst)):
                if L.iou(lst[i][1], lst[j][1]) > 0.12:
                    overlaps.setdefault((min(lst[i][0], lst[j][0]), max(lst[i][0], lst[j][0])), []).append(f)
    ov_list = [{"tracks": list(k), "n_frames": len(v), "frame_start": min(v), "frame_end": max(v)} for k, v in overlaps.items()]

    warnings = []
    if not tracks:
        warnings.append("No faces were detected. Try a clip where the face is larger, better lit and mostly front-facing.")
    for st in summary_tracks:
        if st["coverage"] < 0.85:
            warnings.append(f"Track {st['id']} has gaps ({st['coverage']*100:.0f}% coverage); frames without detection are left untouched unless short enough to interpolate.")
        if skin_mean.get(st["id"], 1.0) < 0.25 and not grayscale:
            warnings.append(f"Track {st['id']} does not look skin-coloured; it may not be a real face — check the thumbnail.")
        if st["mean_face_px"] < 60:
            warnings.append(f"Track {st['id']} faces are small (~{st['mean_face_px']:.0f}px wide); quality will be limited.")
    if ov_list:
        warnings.append("Some people overlap each other; affected frames are skipped or need manual review (see settings → overlap policy).")
    summary = {"video_id": video_id, "width": info.width, "height": info.height, "fps": info.fps, "n_frames": n_seen,
               "tracks": summary_tracks, "overlaps": ov_list, "warnings": warnings}
    (out / "summary.json").write_text(json.dumps(summary))
    ctl.info(f"Analysis finished: {len(tracks)} track(s), {n_seen} frames")
    return summary


def load_summary(video_id: str) -> dict | None:
    p = analysis_dir(video_id) / "summary.json"
    return json.loads(p.read_text()) if p.exists() else None


def load_tracks(video_id: str) -> dict[int, dict[str, np.ndarray]]:
    p = analysis_dir(video_id) / "tracks.npz"
    if not p.exists():
        return {}
    z = np.load(p)
    ids = sorted({int(k[1:].split("_")[0]) for k in z.files if k.startswith("t")})
    return {i: {k: z[f"t{i}_{k}"] for k in ("frames", "lm", "bbox", "conf", "pose", "ear", "mar")} for i in ids}


def boxes_payload(video_id: str) -> dict:
    """Compact per-frame boxes for the UI overlay."""
    tr = load_tracks(video_id)
    s = load_summary(video_id) or {}
    return {"fps": s.get("fps"), "width": s.get("width"), "height": s.get("height"),
            "tracks": [{"id": i, "frames": d["frames"].tolist(),
                        "boxes": np.round(d["bbox"]).astype(int).tolist(),
                        "conf": np.round(d["conf"], 2).tolist()} for i, d in tr.items()]}
