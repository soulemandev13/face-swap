"""FastAPI application entry-point:  uvicorn app.main:app  (or scripts/run.py)."""
from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from . import db
from .api.routes import router
from .core.config import get_settings
from .core.logging import setup_logging
from .services.jobs import manager


@asynccontextmanager
async def lifespan(app: FastAPI):
    s = get_settings()
    setup_logging(s.log_level)
    s.check_network_policy()
    db.conn()
    manager.recover()
    yield


def create_app() -> FastAPI:
    s = get_settings()
    app = FastAPI(title="Full Face-Swap Studio", version="1.0.0", lifespan=lifespan,
                  docs_url="/api/docs", openapi_url="/api/openapi.json", redoc_url=None)
    # DNS-rebinding protection: only answer for localhost names unless LAN access was enabled explicitly
    hosts = ["*"] if s.allow_lan else ["localhost", "127.0.0.1", "[::1]", "testserver"]
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=hosts)

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        resp = await call_next(request)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("Referrer-Policy", "no-referrer")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        if not request.url.path.startswith("/api/docs"):
            resp.headers.setdefault("Content-Security-Policy",
                                    "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; "
                                    "style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'")
        return resp

    app.include_router(router)
    fe = Path(s.frontend_dir)
    if fe.exists():
        app.mount("/static", StaticFiles(directory=fe), name="static")

        @app.get("/", include_in_schema=False)
        def index():
            return FileResponse(fe / "index.html", headers={"Cache-Control": "no-store"})

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception):
        import logging
        logging.getLogger("api").exception("unhandled error on %s", request.url.path)
        return JSONResponse({"detail": "Internal error. Check the server log."}, status_code=500)

    return app


app = create_app()
