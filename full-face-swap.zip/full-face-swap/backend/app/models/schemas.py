"""Pydantic schemas shared by the API, job manager and render pipeline."""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator


class ProcessingSettings(BaseModel):
    engine: Literal["auto", "mesh_warp", "insightface"] = "auto"
    replacement_mode: Literal["face_only", "face_head", "full_head_hair"] = "face_head"
    quality: Literal["draft", "balanced", "high"] = "balanced"

    mask_strength: float = Field(0.5, ge=0, le=1, description="edge feather amount")
    mask_expand: float = Field(0.0, ge=-1, le=1, description="grow/shrink the replacement mask")
    temporal_smoothing: float = Field(0.5, ge=0, le=1)
    color_match: float = Field(0.85, ge=0, le=1)
    hair_transfer: float = Field(1.0, ge=0, le=1, description="full_head_hair: 0 keep target hair, 1 replace within silhouette")
    preserve_inner_mouth: bool = True
    preserve_closed_eyes: bool = True

    min_confidence: float = Field(0.35, ge=0, le=1)
    overlap_policy: Literal["skip", "proceed"] = "skip"
    overlap_iou: float = Field(0.18, ge=0.02, le=0.9)

    output_resolution: Literal["source", "1080p", "720p", "480p"] = "source"
    output_fps: Optional[float] = Field(None, ge=5, le=120)
    keep_audio: bool = True
    label_ai_visible: bool = True
    comparison: bool = False
    save_samples: bool = True

    replace_start_s: Optional[float] = Field(None, ge=0)
    replace_end_s: Optional[float] = Field(None, ge=0)
    preview_start_s: float = Field(0.0, ge=0)
    preview_duration_s: float = Field(3.0, gt=0, le=30)
    preview_max_side: int = Field(640, ge=256, le=1280)
    output_name: Optional[str] = Field(None, max_length=100)

    @field_validator("output_name")
    @classmethod
    def _clean_name(cls, v):
        if v is None:
            return v
        import re
        v = re.sub(r"[^A-Za-z0-9._\- ]+", "_", v).strip(" ._")
        return v[:80] or None


class JobRequest(BaseModel):
    video_id: str
    reference_ids: list[str] = Field(min_length=1, max_length=8)
    target_track_ids: list[int] = Field(min_length=1, max_length=8)
    settings: ProcessingSettings = Field(default_factory=ProcessingSettings)
    consent_ack: bool = False


class AnalyzeRequest(BaseModel):
    video_id: str


RES_MAX_SIDE = {"1080p": 1920, "720p": 1280, "480p": 854}
