"""HTTP API (see docs/ARCHITECTURE.md). All ids are validated; user filenames never touch disk paths."""
from __future__ import annotations

import os
import shutil
import subprocess
import time
from pathlib import Path

import cv2
import numpy as np
from fastapi import APIRouter, File, Form, HTTPException, Request, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse

from .. import db
from ..core.config import get_settings
from ..core.security import (ALLOWED_IMAGE_EXT, ALLOWED_VIDEO_EXT, check_id, display_name, new_id,
                             resolve_within, safe_ext)
from ..media import ffmpeg as ff
from ..models.schemas import AnalyzeRequest, JobRequest
from ..services import analysis as an
from ..services.jobs import CONSENT_TEXT, manager
from ..vision.analyzer import get_analyzer
from ..vision.engines import engine_report
from ..vision.reference import ReferenceError, assess, read_image

router = APIRouter(prefix="/api")


# ---------------------------------------------------------------- helpers ------------------------
async def _save_upload(file: UploadFile, dest: Path, max_bytes: int) -> int:
    size = 0
    try:
        with open(dest, "wb") as f:
            while True:
                chunk = await file.read(1 << 20)
                if not chunk:
                    break
                size += len(chunk)
                if size > max_bytes:
                    raise HTTPException(413, f"File is larger than the {max_bytes // (1024 * 1024)} MB limit.")
                f.write(chunk)
    except OSError as e:
        dest.unlink(missing_ok=True)
        raise HTTPException(507, f"Could not store the upload ({e.strerror}). Is the disk full?")
    except HTTPException:
        dest.unlink(missing_ok=True)
        raise
    return size


def ranged_file(request: Request, path: Path, media_type: str, filename: str | None = None, download: bool = False):
    """File response with HTTP Range support (needed for seeking in <video>)."""
    if not path.exists():
        raise HTTPException(404, "File not found")
    size = path.stat().st_size
    headers = {"Accept-Ranges": "bytes", "Cache-Control": "no-store"}
    if download:
        headers["Content-Disposition"] = f'attachment; filename="{display_name(filename or path.name)}"'
    rng = request.headers.get("range")
    start, end = 0, size - 1
    status = 200
    if rng and rng.startswith("bytes="):
        try:
            a, _, b = rng[6:].partition("-")
            if a == "":
                start = max(0, size - int(b))
            else:
                start = int(a)
                end = int(b) if b else size - 1
            end = min(end, size - 1)
            if start > end or start >= size:
                return Response(status_code=416, headers={"Content-Range": f"bytes */{size}"})
            status = 206
            headers["Content-Range"] = f"bytes {start}-{end}/{size}"
        except ValueError:
            start, end, status = 0, size - 1, 200
    length = end - start + 1
    headers["Content-Length"] = str(length)

    def it():
        with open(path, "rb") as f:
            f.seek(start)
            left = length
            while left > 0:
                chunk = f.read(min(1 << 20, left))
                if not chunk:
                    break
                left -= len(chunk)
                yield chunk
    return StreamingResponse(it(), status_code=status, media_type=media_type, headers=headers)


def _video_row(video_id: str) -> dict:
    check_id(video_id, "vid")
    v = db.one("SELECT * FROM videos WHERE id=?", (video_id,))
    if not v:
        raise HTTPException(404, "Video not found")
    return v


def _video_public(v: dict) -> dict:
    a = db.one("SELECT status, progress FROM analyses WHERE video_id=?", (v["id"],))
    return {"id": v["id"], "name": v["name"], "created_at": v["created_at"], "info": db.jload(v["info"], {}),
            "warnings": db.jload(v["info"], {}).get("_warnings", []), "proxy_status": v["proxy_status"],
            "analysis_status": a["status"] if a else None}


def _ref_public(r: dict) -> dict:
    info = db.jload(r["info"], {})
    return {"id": r["id"], "name": r["name"], "created_at": r["created_at"], "quality": info, "consent_ack": bool(r["consent_ack"])}


# ---------------------------------------------------------------- system -------------------------
@router.get("/health")
def health():
    return {"status": "ok", "time": time.time()}


@router.get("/system")
def system():
    s = get_settings()
    gpu = None
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"], capture_output=True, text=True, timeout=5)
        gpu = r.stdout.strip() or None if r.returncode == 0 else None
    except Exception:
        gpu = None
    free = shutil.disk_usage(s.data_dir).free
    from ..vision.segmentation import get_parser
    return {
        "ffmpeg": ff.ffmpeg_available(), "engines": engine_report(), "gpu": gpu, "disk_free_mb": free // (1024 * 1024),
        "face_parsing_model": get_parser() is not None, "consent_text": CONSENT_TEXT,
        "limits": {"max_duration_s": s.max_duration_s, "max_resolution": f"{s.max_width}x{s.max_height}",
                   "max_upload_mb": s.max_upload_mb, "max_faces": s.max_faces},
        "paths": {"uploads": str(s.uploads_dir), "outputs": str(s.outputs_dir), "references": str(s.references_dir)},
        "retain_temp": s.retain_temp, "default_label_ai": s.default_label_ai,
    }


# ---------------------------------------------------------------- videos ------------------------
@router.post("/videos/upload")
async def upload_video(file: UploadFile = File(...)):
    s = get_settings()
    ext = safe_ext(file.filename, ALLOWED_VIDEO_EXT)
    vid = new_id("vid")
    dest = resolve_within(s.uploads_dir, f"{vid}{ext}")
    await _save_upload(file, dest, s.max_upload_mb * 1024 * 1024)
    try:
        info = await run_in_threadpool(ff.probe, dest)
        warnings = ff.validate(info)
    except ff.MediaError as e:
        dest.unlink(missing_ok=True)
        raise HTTPException(422, str(e))
    meta = info.to_dict()
    meta["_warnings"] = warnings
    db.execute("INSERT INTO videos(id,name,path,created_at,info,proxy_status) VALUES(?,?,?,?,?,?)",
               (vid, display_name(file.filename), str(dest), db.now(), db.jdump(meta), "queued"))
    manager.submit_proxy(vid)
    return _video_public(db.one("SELECT * FROM videos WHERE id=?", (vid,)))


@router.get("/videos")
def list_videos():
    return [_video_public(v) for v in db.many("SELECT * FROM videos ORDER BY created_at DESC")]


@router.get("/videos/{video_id}")
def get_video(video_id: str):
    return _video_public(_video_row(video_id))


@router.get("/videos/{video_id}/media")
def video_media(video_id: str, request: Request, original: bool = False):
    v = _video_row(video_id)
    p = Path(v["proxy_path"]) if (v["proxy_path"] and not original and Path(v["proxy_path"]).exists()) else Path(v["path"])
    mt = "video/mp4" if p.suffix == ".mp4" else "video/quicktime" if p.suffix == ".mov" else "video/webm" if p.suffix == ".webm" else "application/octet-stream"
    return ranged_file(request, p, mt)


@router.get("/videos/{video_id}/frame")
def video_frame(video_id: str, t: float = 0.0, max_side: int = 960):
    v = _video_row(video_id)
    info = ff.VideoInfo.from_dict(db.jload(v["info"]))
    try:
        fr = ff.read_frame_at(Path(v["path"]), info, min(max(t, 0), max(info.duration - 0.05, 0)), max_side=min(max_side, 1920))
    except ff.MediaError as e:
        raise HTTPException(422, str(e))
    ok, buf = cv2.imencode(".jpg", fr, [cv2.IMWRITE_JPEG_QUALITY, 88])
    return Response(buf.tobytes(), media_type="image/jpeg", headers={"Cache-Control": "no-store"})


@router.delete("/videos/{video_id}")
def delete_video(video_id: str):
    v = _video_row(video_id)
    running = db.many("SELECT id FROM jobs WHERE video_id=? AND status IN ('queued','running','paused')", (video_id,))
    if running or ("an_" + video_id) in manager.controls:
        raise HTTPException(409, "A job or analysis for this video is still running. Cancel it first.")
    for j in db.many("SELECT id FROM jobs WHERE video_id=?", (video_id,)):
        manager.delete_job(j["id"])
    Path(v["path"]).unlink(missing_ok=True)
    shutil.rmtree(an.analysis_dir(video_id), ignore_errors=True)
    db.execute("DELETE FROM analyses WHERE video_id=?", (video_id,))
    db.execute("DELETE FROM videos WHERE id=?", (video_id,))
    return {"deleted": video_id}


# ---------------------------------------------------------------- references ------------------------
@router.post("/reference/upload")
async def upload_reference(file: UploadFile = File(...), consent_ack: bool = Form(False), name: str | None = Form(None)):
    if not consent_ack:
        raise HTTPException(400, "You must confirm that you have permission and consent to use this reference image.")
    s = get_settings()
    ext = safe_ext(file.filename, ALLOWED_IMAGE_EXT)
    rid = new_id("ref")
    dest = resolve_within(s.references_dir, f"{rid}{ext}")
    await _save_upload(file, dest, s.max_reference_mb * 1024 * 1024)

    def check():
        img = read_image(dest)
        _, q, _ = assess(img, get_analyzer(4))
        return q
    try:
        q = await run_in_threadpool(check)
    except ReferenceError as e:
        dest.unlink(missing_ok=True)
        raise HTTPException(422, str(e))
    db.execute("INSERT INTO refs(id,name,path,created_at,info,consent_ack) VALUES(?,?,?,?,?,?)",
               (rid, display_name(name or file.filename), str(dest), db.now(), db.jdump(q), 1))
    return _ref_public(db.one("SELECT * FROM refs WHERE id=?", (rid,)))


@router.get("/reference")
def list_references():
    return [_ref_public(r) for r in db.many("SELECT * FROM refs ORDER BY created_at DESC")]


@router.get("/reference/{ref_id}/image")
def reference_image(ref_id: str):
    check_id(ref_id, "ref")
    r = db.one("SELECT * FROM refs WHERE id=?", (ref_id,))
    if not r:
        raise HTTPException(404, "Reference not found")
    img = read_image(Path(r["path"]), 512)
    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 88])
    return Response(buf.tobytes(), media_type="image/jpeg")


@router.delete("/reference/{ref_id}")
def delete_reference(ref_id: str):
    check_id(ref_id, "ref")
    r = db.one("SELECT * FROM refs WHERE id=?", (ref_id,))
    if not r:
        raise HTTPException(404, "Reference not found")
    Path(r["path"]).unlink(missing_ok=True)
    db.execute("DELETE FROM refs WHERE id=?", (ref_id,))
    return {"deleted": ref_id}


# ---------------------------------------------------------------- analysis ------------------------
@router.post("/analyze")
def analyze(req: AnalyzeRequest):
    v = _video_row(req.video_id)
    cur = db.one("SELECT status FROM analyses WHERE video_id=?", (req.video_id,))
    if cur and cur["status"] in ("queued", "running"):
        return {"video_id": req.video_id, "status": cur["status"]}
    manager.submit_analysis(v["id"])
    return {"video_id": req.video_id, "status": "queued"}


@router.get("/analysis/{video_id}")
def analysis_status(video_id: str):
    _video_row(video_id)
    a = db.one("SELECT * FROM analyses WHERE video_id=?", (video_id,))
    if not a:
        return {"video_id": video_id, "status": "none"}
    prog = manager.analysis_progress.get(video_id, {})
    summary = db.jload(a["summary"], None) if a["status"] == "completed" else None
    logs = db.many("SELECT ts, level, message FROM job_logs WHERE job_id=? ORDER BY id DESC LIMIT 20", ("an_" + video_id,))[::-1]
    return {"video_id": video_id, "status": a["status"], "progress": prog, "summary": summary, "error": a["error"], "logs": logs}


@router.get("/analysis/{video_id}/boxes")
def analysis_boxes(video_id: str):
    _video_row(video_id)
    if not an.load_summary(video_id):
        raise HTTPException(404, "No analysis yet")
    return JSONResponse(an.boxes_payload(video_id), headers={"Cache-Control": "no-store"})


@router.get("/analysis/{video_id}/thumb/{track_id}")
def analysis_thumb(video_id: str, track_id: int):
    _video_row(video_id)
    p = an.analysis_dir(video_id) / f"thumb_{int(track_id)}.jpg"
    if not p.exists():
        raise HTTPException(404, "No thumbnail")
    return FileResponse(p, media_type="image/jpeg")


@router.post("/analysis/{video_id}/control")
def analysis_control(video_id: str, action: str):
    _video_row(video_id)
    c = manager.controls.get("an_" + video_id)
    if not c:
        raise HTTPException(409, "No running analysis for this video")
    {"cancel": c.cancel, "pause": c.pause, "resume": c.resume}.get(action, lambda: (_ for _ in ()).throw(HTTPException(400, "action must be cancel|pause|resume")))()
    return {"ok": True}


# ---------------------------------------------------------------- jobs ------------------------
def _validate_job(req: JobRequest) -> None:
    if not req.consent_ack:
        raise HTTPException(400, "Consent acknowledgement is required before processing.")
    _video_row(req.video_id)
    a = db.one("SELECT status FROM analyses WHERE video_id=?", (req.video_id,))
    if not a or a["status"] != "completed":
        raise HTTPException(409, "Analyse the video first (Analyze people), then select the person to replace.")
    summ = an.load_summary(req.video_id) or {}
    ids = {t["id"] for t in summ.get("tracks", [])}
    bad = [t for t in req.target_track_ids if t not in ids]
    if bad:
        raise HTTPException(422, f"Unknown track id(s): {bad}")
    for rid in req.reference_ids:
        check_id(rid, "ref")
        r = db.one("SELECT consent_ack FROM refs WHERE id=?", (rid,))
        if not r:
            raise HTTPException(404, f"Reference {rid} not found")
        if not r["consent_ack"]:
            raise HTTPException(400, f"Reference {rid} has no consent acknowledgement.")


@router.post("/jobs/preview")
def start_preview(req: JobRequest):
    _validate_job(req)
    return manager.job_public(db.one("SELECT * FROM jobs WHERE id=?", (manager.submit_job("preview", req),)))


@router.post("/jobs/render")
def start_render(req: JobRequest):
    _validate_job(req)
    return manager.job_public(db.one("SELECT * FROM jobs WHERE id=?", (manager.submit_job("render", req),)))


def _job_row(job_id: str) -> dict:
    check_id(job_id, "job")
    j = db.one("SELECT * FROM jobs WHERE id=?", (job_id,))
    if not j:
        raise HTTPException(404, "Job not found")
    return j


@router.get("/jobs")
def list_jobs(limit: int = 50):
    return [manager.job_public(j) for j in db.many("SELECT * FROM jobs ORDER BY created_at DESC LIMIT ?", (min(limit, 200),))]


@router.get("/jobs/{job_id}")
def get_job(job_id: str):
    return manager.job_public(_job_row(job_id))


@router.get("/jobs/{job_id}/logs")
def job_logs(job_id: str, after: int = 0):
    _job_row(job_id)
    rows = db.many("SELECT id, ts, level, message FROM job_logs WHERE job_id=? AND id>? ORDER BY id LIMIT 500", (job_id, after))
    return rows


@router.post("/jobs/{job_id}/cancel")
def cancel_job(job_id: str):
    j = _job_row(job_id)
    if j["status"] in ("completed", "failed", "cancelled"):
        return {"status": j["status"], "note": "Job already finished."}
    if not manager.cancel(job_id):
        raise HTTPException(409, "This job is not running in this process.")
    return {"status": "cancelling"}


@router.post("/jobs/{job_id}/pause")
def pause_job(job_id: str):
    _job_row(job_id)
    if not manager.pause(job_id):
        raise HTTPException(409, "Job is not running.")
    return {"status": "paused"}


@router.post("/jobs/{job_id}/resume")
def resume_job(job_id: str):
    _job_row(job_id)
    if not manager.resume(job_id):
        raise HTTPException(409, "Job is not running.")
    return {"status": "running"}


def _serve_output(job_id: str, request: Request, kind: str | None, download: bool, variant: str = "main"):
    j = _job_row(job_id)
    if j["status"] != "completed" or not j["output_path"]:
        raise HTTPException(409, f"Job is {j['status']}; no output available yet." + (f" Error: {j['error']}" if j["error"] else ""))
    if kind and j["kind"] != kind:
        raise HTTPException(404, f"This job is a {j['kind']} job.")
    p = Path(j["output_path"])
    if variant == "compare":
        m = db.jload(j["metrics"], {})
        p = Path(m.get("comparison_path") or "")
    if not p.exists():
        raise HTTPException(404, "Output file is gone (deleted?).")
    name = (j["output_name"] or ("preview" if j["kind"] == "preview" else "output")) + ("_compare" if variant == "compare" else "") + ".mp4"
    return ranged_file(request, p, "video/mp4", filename=name, download=download)


@router.get("/jobs/{job_id}/preview")
def job_preview(job_id: str, request: Request, download: bool = False, variant: str = "main"):
    """Playable output of a *preview* job (Range-capable)."""
    return _serve_output(job_id, request, "preview", download, variant)


@router.get("/jobs/{job_id}/result")
def job_result(job_id: str, request: Request, download: bool = False, variant: str = "main"):
    """Completed output of a *render* job (Range-capable; ?download=1 for attachment)."""
    return _serve_output(job_id, request, "render", download, variant)


@router.get("/jobs/{job_id}/samples")
def job_samples(job_id: str):
    _job_row(job_id)
    d = get_settings().outputs_dir / job_id / "samples"
    return sorted(p.name for p in d.glob("*.jpg")) if d.exists() else []


@router.get("/jobs/{job_id}/samples/{name}")
def job_sample(job_id: str, name: str):
    _job_row(job_id)
    p = resolve_within(get_settings().outputs_dir / job_id / "samples", display_name(name))
    if not p.exists():
        raise HTTPException(404, "Sample not found")
    return FileResponse(p, media_type="image/jpeg")


@router.get("/jobs/{job_id}/report")
def job_report(job_id: str):
    j = _job_row(job_id)
    return db.jload(j["metrics"], {})


@router.delete("/jobs/{job_id}")
def delete_job(job_id: str):
    j = _job_row(job_id)
    if j["status"] in ("queued", "running", "paused"):
        raise HTTPException(409, "Cancel the job before deleting it.")
    manager.delete_job(job_id)
    return {"deleted": job_id}


@router.post("/maintenance/cleanup")
def cleanup():
    """Remove temp files and orphaned outputs (outputs of jobs that no longer exist)."""
    s = get_settings()
    freed = 0
    for d in list(s.temp_dir.iterdir()):
        if d.name == ".gitkeep":
            continue
        freed += sum(f.stat().st_size for f in d.rglob("*") if f.is_file()) if d.is_dir() else d.stat().st_size
        shutil.rmtree(d, ignore_errors=True) if d.is_dir() else d.unlink(missing_ok=True)
    known = {j["id"] for j in db.many("SELECT id FROM jobs")}
    for d in list(s.outputs_dir.iterdir()):
        if d.is_dir() and d.name not in known:
            freed += sum(f.stat().st_size for f in d.rglob("*") if f.is_file())
            shutil.rmtree(d, ignore_errors=True)
    return {"freed_mb": round(freed / 1048576, 1)}
