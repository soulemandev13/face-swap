"""FFmpeg / FFprobe integration: probing, validation, streamed frame IO, muxing.

Frames are *streamed* through pipes (never all held in RAM). Reader and writer both
normalise to constant frame-rate so that frame indices from analysis line up with render.
"""
from __future__ import annotations

import json
import logging
import subprocess
import tempfile
from dataclasses import asdict, dataclass
from fractions import Fraction
from pathlib import Path
from typing import Iterator

import numpy as np

from ..core.config import get_settings

log = logging.getLogger("media")

AI_LABEL_TEXT = "AI-edited / synthetic media"


class MediaError(Exception):
    """Human-readable media problem (shown to the operator as-is)."""


@dataclass
class VideoInfo:
    container: str
    codec: str
    width: int            # display size (after rotation metadata is applied)
    height: int
    fps: float
    duration: float
    n_frames: int         # estimated for the CFR stream
    has_audio: bool
    audio_codec: str | None
    rotation: int
    pix_fmt: str
    size_bytes: int

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "VideoInfo":
        names = cls.__dataclass_fields__.keys()
        return cls(**{k: v for k, v in d.items() if k in names})


def _run(cmd: list[str], timeout: float | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def ffmpeg_available() -> dict:
    s = get_settings()
    out = {}
    for name, binary in (("ffmpeg", s.ffmpeg_bin), ("ffprobe", s.ffprobe_bin)):
        try:
            r = _run([binary, "-version"], timeout=10)
            out[name] = r.stdout.splitlines()[0] if r.returncode == 0 and r.stdout else None
        except (FileNotFoundError, subprocess.TimeoutExpired):
            out[name] = None
    return out


def probe(path: Path) -> VideoInfo:
    s = get_settings()
    try:
        r = _run([s.ffprobe_bin, "-v", "error", "-print_format", "json", "-show_streams", "-show_format", str(path)], timeout=60)
    except FileNotFoundError:
        raise MediaError("FFprobe was not found. Install FFmpeg and make sure `ffprobe` is on PATH (or set FFS_FFPROBE_BIN).")
    except subprocess.TimeoutExpired:
        raise MediaError("FFprobe timed out while reading the file; it may be corrupted.")
    if r.returncode != 0:
        raise MediaError("The file could not be read as a video (it may be corrupted or not a video).")
    try:
        data = json.loads(r.stdout)
    except json.JSONDecodeError:
        raise MediaError("The file could not be analysed (invalid ffprobe output).")
    vs = next((x for x in data.get("streams", []) if x.get("codec_type") == "video" and x.get("disposition", {}).get("attached_pic", 0) != 1), None)
    if vs is None:
        raise MediaError("No video stream was found in this file.")
    aus = next((x for x in data.get("streams", []) if x.get("codec_type") == "audio"), None)
    fmt = data.get("format", {})

    w, h = int(vs.get("width", 0)), int(vs.get("height", 0))
    rotation = 0
    if "rotate" in vs.get("tags", {}):
        try:
            rotation = int(float(vs["tags"]["rotate"])) % 360
        except ValueError:
            pass
    for sd in vs.get("side_data_list", []) or []:
        if "rotation" in sd:
            rotation = int(round(float(sd["rotation"]))) % 360
    if rotation in (90, 270):
        w, h = h, w

    def _frac(v: str | None) -> float:
        try:
            f = Fraction(v) if v and v != "0/0" else Fraction(0)
            return float(f)
        except (ValueError, ZeroDivisionError):
            return 0.0

    fps = _frac(vs.get("avg_frame_rate")) or _frac(vs.get("r_frame_rate"))
    duration = float(vs.get("duration") or fmt.get("duration") or 0.0)
    if fps <= 0 or fps > 240:
        raise MediaError(f"Could not determine a sensible frame rate (got {fps}).")
    if duration <= 0:
        # fall back to nb_frames
        nbf = int(vs.get("nb_frames") or 0)
        duration = nbf / fps if nbf else 0.0
    n_frames = int(round(duration * fps)) if duration else int(vs.get("nb_frames") or 0)
    return VideoInfo(
        container=(fmt.get("format_name") or "").split(",")[0],
        codec=vs.get("codec_name", "unknown"),
        width=w, height=h, fps=round(fps, 4), duration=round(duration, 3), n_frames=n_frames,
        has_audio=aus is not None, audio_codec=aus.get("codec_name") if aus else None,
        rotation=rotation, pix_fmt=vs.get("pix_fmt", ""), size_bytes=int(fmt.get("size") or 0),
    )


def validate(info: VideoInfo) -> list[str]:
    """Raise MediaError for hard failures; return a list of soft warnings."""
    s = get_settings()
    warnings: list[str] = []
    if info.width < 64 or info.height < 64:
        raise MediaError(f"Video resolution {info.width}x{info.height} is too small to contain usable faces.")
    if info.width > s.max_width or info.height > s.max_height:
        raise MediaError(
            f"Resolution {info.width}x{info.height} exceeds the configured limit {s.max_width}x{s.max_height}. "
            "Downscale the clip (e.g. `ffmpeg -i in.mp4 -vf scale=-2:1080 out.mp4`) or raise FFS_MAX_WIDTH/HEIGHT."
        )
    if info.duration <= 0:
        raise MediaError("The video has no readable duration.")
    if info.duration > s.max_duration_s:
        raise MediaError(
            f"Duration {info.duration:.0f}s exceeds the configured limit of {s.max_duration_s:.0f}s. "
            "Trim the clip or raise FFS_MAX_DURATION_S."
        )
    if info.codec in ("hevc", "av1", "vp9") :
        warnings.append(f"Codec '{info.codec}' is supported for processing but may not play in every browser; a preview proxy will be generated.")
    if not info.has_audio:
        warnings.append("This video has no audio stream; the output will be silent.")
    if info.fps < 10:
        warnings.append("Very low frame rate; temporal smoothing will be less effective.")
    return warnings


def even(n: int) -> int:
    return n if n % 2 == 0 else n - 1


def scaled_size(w: int, h: int, max_side: int | None) -> tuple[int, int]:
    if not max_side or max(w, h) <= max_side:
        return even(w), even(h)
    k = max_side / max(w, h)
    return even(int(round(w * k))), even(int(round(h * k)))


class FrameReader:
    """Iterate BGR uint8 frames from [start_s, start_s+duration_s) as a CFR stream."""

    def __init__(self, path: Path, info: VideoInfo, start_s: float = 0.0, duration_s: float | None = None,
                 out_size: tuple[int, int] | None = None, fps: float | None = None):
        self.path, self.info = path, info
        self.fps = fps or info.fps
        self.start_s = max(0.0, start_s)
        self.duration_s = duration_s
        self.w, self.h = out_size or (even(info.width), even(info.height))
        self.start_frame = int(round(self.start_s * self.fps))
        self.proc: subprocess.Popen | None = None
        self._err = tempfile.TemporaryFile()

    def __iter__(self) -> Iterator[tuple[int, np.ndarray]]:
        s = get_settings()
        cmd = [s.ffmpeg_bin, "-v", "error", "-nostdin"]
        if self.start_s > 0:
            cmd += ["-ss", f"{self.start_s:.6f}"]
        cmd += ["-i", str(self.path)]
        if self.duration_s:
            cmd += ["-t", f"{self.duration_s:.6f}"]
        vf = [f"fps=fps={self.fps}"]
        if (self.w, self.h) != (self.info.width, self.info.height):
            vf.append(f"scale={self.w}:{self.h}:flags=lanczos")
        cmd += ["-map", "0:v:0", "-vf", ",".join(vf), "-an", "-sn", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=self._err, bufsize=self.w * self.h * 3 * 2)
        nbytes = self.w * self.h * 3
        idx = self.start_frame
        try:
            while True:
                buf = self.proc.stdout.read(nbytes)
                if len(buf) < nbytes:
                    break
                yield idx, np.frombuffer(buf, np.uint8).reshape(self.h, self.w, 3).copy()
                idx += 1
        finally:
            self.close()

    def close(self) -> None:
        if self.proc and self.proc.poll() is None:
            self.proc.kill()
        if self.proc:
            try:
                self.proc.stdout.close()
            except Exception:
                pass
            self.proc.wait()

    def error_text(self) -> str:
        try:
            self._err.seek(0)
            return self._err.read().decode("utf-8", "replace")[-2000:]
        except Exception:
            return ""


def read_frame_at(path: Path, info: VideoInfo, t: float, max_side: int | None = None) -> np.ndarray:
    size = scaled_size(info.width, info.height, max_side)
    reader = FrameReader(path, info, start_s=max(0.0, t), duration_s=2.0 / max(info.fps, 1), out_size=size)
    for _, fr in reader:
        reader.close()
        return fr
    raise MediaError("Could not decode a frame at that position.")


class FrameWriter:
    """Pipe BGR frames into libx264, muxing source audio and AI-edited metadata."""

    PRESETS = {"draft": ("ultrafast", 28), "balanced": ("veryfast", 21), "high": ("slow", 17)}

    def __init__(self, out_path: Path, size: tuple[int, int], fps: float, *, audio_src: Path | None = None,
                 start_s: float = 0.0, duration_s: float | None = None, quality: str = "balanced",
                 metadata: dict[str, str] | None = None):
        self.out_path = out_path
        self.size = size
        self.proc: subprocess.Popen | None = None
        self._err = tempfile.TemporaryFile()
        s = get_settings()
        preset, crf = self.PRESETS.get(quality, self.PRESETS["balanced"])
        cmd = [s.ffmpeg_bin, "-v", "error", "-nostdin", "-y",
               "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{size[0]}x{size[1]}", "-r", f"{fps}", "-i", "-"]
        if audio_src is not None:
            if start_s > 0:
                cmd += ["-ss", f"{start_s:.6f}"]
            if duration_s:
                cmd += ["-t", f"{duration_s:.6f}"]
            cmd += ["-i", str(audio_src)]
        cmd += ["-map", "0:v:0"]
        if audio_src is not None:
            cmd += ["-map", "1:a:0?", "-c:a", "aac", "-b:a", "192k"]
        cmd += ["-c:v", "libx264", "-preset", preset, "-crf", str(crf), "-pix_fmt", "yuv420p",
                "-r", f"{fps}", "-movflags", "+faststart"]
        if audio_src is not None:
            cmd += ["-shortest"]
        for k, v in (metadata or {}).items():
            cmd += ["-metadata", f"{k}={v}"]
        cmd += [str(out_path)]
        self.cmd = cmd
        self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=self._err, stdout=subprocess.DEVNULL)
        self.frames = 0

    def write(self, frame: np.ndarray) -> None:
        if frame.shape[1] != self.size[0] or frame.shape[0] != self.size[1]:
            raise MediaError("Internal error: frame size changed mid-render.")
        try:
            self.proc.stdin.write(np.ascontiguousarray(frame).tobytes())
        except (BrokenPipeError, OSError):
            raise MediaError("FFmpeg stopped while encoding: " + self.error_text())
        self.frames += 1

    def error_text(self) -> str:
        try:
            self._err.seek(0)
            return self._err.read().decode("utf-8", "replace")[-2000:]
        except Exception:
            return ""

    def close(self, abort: bool = False) -> None:
        if self.proc is None:
            return
        try:
            if abort:
                self.proc.kill()
            else:
                try:
                    self.proc.stdin.close()
                except Exception:
                    pass
                rc = self.proc.wait()
                if rc != 0:
                    raise MediaError(f"Encoding failed (ffmpeg exit {rc}): {self.error_text()}")
        finally:
            if self.proc.poll() is None:
                self.proc.kill()
            self.proc.wait()
            self.proc = None


def ai_metadata(extra: str = "") -> dict[str, str]:
    return {
        "comment": f"{AI_LABEL_TEXT}. Generated locally with Full Face-Swap Studio.{(' ' + extra) if extra else ''}",
        "title": "AI-edited video",
        "synthetic_media": "true",
    }


def make_proxy(src: Path, dst: Path, info: VideoInfo) -> None:
    """Browser-friendly H.264/AAC proxy (<=960px wide) so any input plays in the preview player."""
    s = get_settings()
    w, h = scaled_size(info.width, info.height, 960)
    cmd = [s.ffmpeg_bin, "-v", "error", "-nostdin", "-y", "-i", str(src), "-map", "0:v:0", "-map", "0:a:0?",
           "-vf", f"fps=fps={info.fps},scale={w}:{h}", "-c:v", "libx264", "-preset", "veryfast", "-crf", "26",
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(dst)]
    r = _run(cmd)
    if r.returncode != 0:
        raise MediaError("Could not build a preview proxy: " + r.stderr[-500:])


def hstack_compare(a: Path, b: Path, out: Path, start_s: float = 0.0, dur_s: float | None = None,
                   fps: float | None = None, height: int = 540) -> None:
    """Side-by-side before (a, trimmed to the same window) / after (b); audio from b."""
    s = get_settings()
    h = even(height)
    cmd = [s.ffmpeg_bin, "-v", "error", "-nostdin", "-y"]
    if start_s > 0:
        cmd += ["-ss", f"{start_s:.6f}"]
    if dur_s:
        cmd += ["-t", f"{dur_s:.6f}"]
    cmd += ["-i", str(a), "-i", str(b)]
    fps_f = f"fps=fps={fps}," if fps else ""
    cmd += ["-filter_complex", f"[0:v]{fps_f}scale=-2:{h}[l];[1:v]scale=-2:{h}[r];[l][r]hstack=inputs=2[v]",
            "-map", "[v]", "-map", "1:a:0?", "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-shortest", "-movflags", "+faststart", str(out)]
    r = _run(cmd)
    if r.returncode != 0:
        raise MediaError("Could not build the comparison video: " + r.stderr[-500:])


def verify_output(path: Path, expect_duration: float, expect_frames: int, expect_audio: bool) -> dict:
    """Post-encode checks: readable, duration/frame-count sane, audio present."""
    res: dict = {"readable": False}
    try:
        info = probe(path)
    except MediaError as e:
        res["error"] = str(e)
        return res
    res.update(readable=True, duration=info.duration, fps=info.fps, width=info.width, height=info.height,
               has_audio=info.has_audio, codec=info.codec)
    res["duration_ok"] = abs(info.duration - expect_duration) <= max(0.25, 2.5 / max(info.fps, 1))
    res["audio_ok"] = (info.has_audio == expect_audio) or not expect_audio
    res["expected_frames"] = expect_frames
    return res
