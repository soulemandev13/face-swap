"""Tiny SQLite layer (job history + metadata). One shared connection guarded by a lock."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from typing import Any, Iterable

from .core.config import get_settings

_lock = threading.RLock()
_conn: sqlite3.Connection | None = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS videos(
  id TEXT PRIMARY KEY, name TEXT, path TEXT, created_at REAL, info TEXT, proxy_path TEXT, proxy_status TEXT);
CREATE TABLE IF NOT EXISTS refs(
  id TEXT PRIMARY KEY, name TEXT, path TEXT, created_at REAL, info TEXT, consent_ack INTEGER);
CREATE TABLE IF NOT EXISTS analyses(
  video_id TEXT PRIMARY KEY, status TEXT, progress REAL, created_at REAL, finished_at REAL,
  summary TEXT, error TEXT);
CREATE TABLE IF NOT EXISTS jobs(
  id TEXT PRIMARY KEY, kind TEXT, status TEXT, created_at REAL, started_at REAL, finished_at REAL,
  video_id TEXT, reference_ids TEXT, target_track_ids TEXT, settings TEXT, progress TEXT,
  output_path TEXT, output_name TEXT, metrics TEXT, error TEXT);
CREATE TABLE IF NOT EXISTS job_logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, job_id TEXT, ts REAL, level TEXT, message TEXT);
CREATE INDEX IF NOT EXISTS idx_logs_job ON job_logs(job_id, id);
"""


def conn() -> sqlite3.Connection:
    global _conn
    with _lock:
        if _conn is None:
            _conn = sqlite3.connect(str(get_settings().db_path), check_same_thread=False, isolation_level=None)
            _conn.row_factory = sqlite3.Row
            _conn.execute("PRAGMA journal_mode=WAL")
            _conn.executescript(SCHEMA)
        return _conn


def reset_for_tests() -> None:
    global _conn
    with _lock:
        if _conn is not None:
            _conn.close()
        _conn = None


def execute(sql: str, params: Iterable[Any] = ()) -> None:
    with _lock:
        conn().execute(sql, tuple(params))


def one(sql: str, params: Iterable[Any] = ()) -> dict | None:
    with _lock:
        row = conn().execute(sql, tuple(params)).fetchone()
        return dict(row) if row else None


def many(sql: str, params: Iterable[Any] = ()) -> list[dict]:
    with _lock:
        return [dict(r) for r in conn().execute(sql, tuple(params)).fetchall()]


def jdump(v: Any) -> str:
    return json.dumps(v, default=str)


def jload(v: str | None, default: Any = None) -> Any:
    if v is None or v == "":
        return default
    try:
        return json.loads(v)
    except json.JSONDecodeError:
        return default


def now() -> float:
    return time.time()
