"""Temporal stabilisation: gap interpolation, outlier rejection and per-feature-group
Gaussian smoothing of landmark trajectories (non-causal -> no lag), plus fade gain."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.ndimage import gaussian_filter1d

from . import landmarks as L


@dataclass
class TargetFace:
    frame: int
    track_id: int
    lm: np.ndarray          # (478,3) px in SOURCE resolution
    conf: float
    pose: tuple[float, float, float]
    ear: tuple[float, float]
    mar: float
    interpolated: bool = False
    gain: float = 1.0
    skip_reason: str | None = None


def _segments(frames: np.ndarray) -> list[tuple[int, int]]:
    """Contiguous runs [a,b) over a sorted frame array."""
    if len(frames) == 0:
        return []
    br = np.where(np.diff(frames) > 1)[0] + 1
    starts = np.concatenate([[0], br])
    ends = np.concatenate([br, [len(frames)]])
    return list(zip(starts.tolist(), ends.tolist()))


def build_target_series(data: dict[str, np.ndarray], track_id: int, smoothing: float, max_interp: int = 6) -> dict[int, TargetFace]:
    """data = one track's arrays from analysis (frames, lm, conf ...). Returns frame->TargetFace."""
    fr = data["frames"].astype(np.int64)
    lm = data["lm"].astype(np.float32)
    conf = data["conf"].astype(np.float32)
    if len(fr) == 0:
        return {}

    # 1) outlier rejection: a frame whose face centre jumps far from its neighbours is dropped
    ctr = lm[:, L.FACE_OVAL, :2].mean(1)
    fw = np.linalg.norm(lm[:, 454, :2] - lm[:, 234, :2], axis=1) + 1e-6
    keep = np.ones(len(fr), bool)
    for i in range(1, len(fr) - 1):
        if fr[i + 1] - fr[i - 1] == 2:
            exp = (ctr[i - 1] + ctr[i + 1]) / 2
            if np.linalg.norm(ctr[i] - exp) > 0.45 * fw[i]:
                keep[i] = False
    fr, lm, conf = fr[keep], lm[keep], conf[keep]

    # 2) dense timeline with short-gap interpolation
    dense_f, dense_lm, dense_conf, interp = [], [], [], []
    for i in range(len(fr)):
        dense_f.append(int(fr[i])); dense_lm.append(lm[i]); dense_conf.append(float(conf[i])); interp.append(False)
        if i + 1 < len(fr):
            gap = int(fr[i + 1] - fr[i] - 1)
            if 0 < gap <= max_interp:
                for g in range(1, gap + 1):
                    a = g / (gap + 1)
                    dense_f.append(int(fr[i] + g))
                    dense_lm.append((1 - a) * lm[i] + a * lm[i + 1])
                    dense_conf.append(float(min(conf[i], conf[i + 1]) * 0.85))
                    interp.append(True)
    F = np.array(dense_f, np.int64)
    LM = np.stack(dense_lm).astype(np.float32)
    C = np.array(dense_conf, np.float32)
    I = np.array(interp, bool)

    # 3) smoothing per contiguous segment, separate sigma for rigid vs expressive landmarks
    ts = float(np.clip(smoothing, 0.0, 1.0))
    sig_rigid = 0.4 + 2.2 * ts
    sig_expr = 0.0 + 0.9 * ts            # keep blinks / speech fast
    rigid = np.array(L.RIGID_IDX)
    expr = np.array(L.EXPRESSIVE_IDX)
    other = np.setdiff1d(np.arange(L.N_LANDMARKS), np.concatenate([rigid, expr]))
    out = LM.copy()
    for a, b in _segments(F):
        seg = LM[a:b]
        if b - a < 3:
            continue
        for idx, sg in ((rigid, sig_rigid), (other, sig_rigid), (expr, sig_expr)):
            if sg > 0.05:
                out[a:b, idx] = gaussian_filter1d(seg[:, idx], sg, axis=0, mode="nearest")
        C[a:b] = gaussian_filter1d(C[a:b], 1.0, mode="nearest") if b - a > 3 else C[a:b]

    res: dict[int, TargetFace] = {}
    for k in range(len(F)):
        p = out[k]
        res[int(F[k])] = TargetFace(frame=int(F[k]), track_id=track_id, lm=p, conf=float(C[k]),
                                    pose=L.head_pose(p), ear=L.eye_aspect_ratio(p), mar=L.mouth_aspect_ratio(p),
                                    interpolated=bool(I[k]))
    return res


def apply_fade_gains(faces: dict[int, TargetFace], active: dict[int, bool], n_frames: int, ramp: int = 4) -> None:
    """Ramp replacement strength in/out next to skipped or lost frames so it never pops.
    Video start/end are not treated as boundaries (no needless fade-in on frame 0)."""
    if not faces:
        return
    f0, f1 = min(faces), max(faces)
    lo, hi = max(0, f0 - ramp), min(n_frames - 1, f1 + ramp)
    n = hi - lo + 1
    act = np.array([bool(active.get(f, False)) for f in range(lo, hi + 1)])
    big = 10 ** 6
    prev_in = np.full(n, big)
    nxt_in = np.full(n, big)
    last = -big
    for i in range(n):
        if not act[i]:
            last = i
        prev_in[i] = i - last if last > -big else (i + 1 + ramp if lo > 0 else big)
    last = big
    for i in range(n - 1, -1, -1):
        if not act[i]:
            last = i
        nxt_in[i] = last - i if last < big else ((n - i + ramp) if hi < n_frames - 1 else big)
    d = np.minimum(prev_in, nxt_in)
    for f, tf in faces.items():
        i = f - lo
        tf.gain = float(np.clip(d[i] / ramp, 0.0, 1.0)) if 0 <= i < n and act[i] else 0.0
