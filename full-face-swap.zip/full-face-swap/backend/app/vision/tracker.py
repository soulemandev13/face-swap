"""Multi-face tracker: Hungarian association on predicted-box IoU + centre distance,
gap tolerance for short misses, appearance-histogram re-identification after longer
occlusions."""
from __future__ import annotations

from dataclasses import dataclass, field

import cv2
import numpy as np
from scipy.optimize import linear_sum_assignment

from . import landmarks as L
from .analyzer import FaceDet


def _hist(frame: np.ndarray, bbox: np.ndarray) -> np.ndarray:
    h, w = frame.shape[:2]
    x1, y1, x2, y2 = [int(v) for v in bbox]
    cx, cy, bw, bh = (x1 + x2) // 2, (y1 + y2) // 2, (x2 - x1), (y2 - y1)
    x1, x2 = max(0, cx - bw // 3), min(w, cx + bw // 3)
    y1, y2 = max(0, cy - bh // 3), min(h, cy + bh // 3)
    crop = frame[y1:y2, x1:x2]
    if crop.size == 0:
        return np.zeros(16 * 8, np.float32)
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    hist = cv2.calcHist([hsv], [0, 1], None, [16, 8], [0, 180, 0, 256])
    cv2.normalize(hist, hist, 1, 0, cv2.NORM_L1)
    return hist.flatten().astype(np.float32)


@dataclass
class Track:
    id: int
    dets: dict[int, FaceDet] = field(default_factory=dict)
    last_frame: int = -1
    last_bbox: np.ndarray | None = None
    vel: np.ndarray = field(default_factory=lambda: np.zeros(2, np.float32))
    hist: np.ndarray | None = None

    def predict(self, frame_idx: int) -> np.ndarray:
        gap = frame_idx - self.last_frame
        shift = np.clip(self.vel * min(gap, 5), -0.5 * (self.last_bbox[2] - self.last_bbox[0]), 0.5 * (self.last_bbox[2] - self.last_bbox[0]))
        b = self.last_bbox.copy()
        b[[0, 2]] += shift[0]
        b[[1, 3]] += shift[1]
        return b

    def add(self, frame_idx: int, det: FaceDet, hist: np.ndarray) -> None:
        if self.last_bbox is not None:
            c_old = (self.last_bbox[:2] + self.last_bbox[2:]) / 2
            c_new = (det.bbox[:2] + det.bbox[2:]) / 2
            gap = max(1, frame_idx - self.last_frame)
            self.vel = 0.6 * self.vel + 0.4 * (c_new - c_old) / gap
        self.dets[frame_idx] = det
        det.track_id = self.id
        self.last_frame, self.last_bbox = frame_idx, det.bbox.copy()
        self.hist = hist if self.hist is None else 0.9 * self.hist + 0.1 * hist


class FaceTracker:
    def __init__(self, max_gap: int = 15, reid_gap: int = 150, min_len: int = 3, reid_thr: float = 0.55):
        self.tracks: list[Track] = []
        self.max_gap, self.reid_gap, self.min_len, self.reid_thr = max_gap, reid_gap, min_len, reid_thr
        self._next = 1

    def _new(self) -> Track:
        t = Track(self._next)
        self._next += 1
        self.tracks.append(t)
        return t

    def update(self, idx: int, dets: list[FaceDet], frame: np.ndarray) -> None:
        active = [t for t in self.tracks if idx - t.last_frame <= self.max_gap and t.last_frame < idx]
        hists = [_hist(frame, d.bbox) for d in dets]
        matched_d: set[int] = set()
        matched_t: set[int] = set()
        if active and dets:
            cost = np.ones((len(active), len(dets)), np.float32) * 9
            for i, t in enumerate(active):
                pb = t.predict(idx)
                diag = max(pb[2] - pb[0], pb[3] - pb[1])
                for j, d in enumerate(dets):
                    ov = L.iou(pb, d.bbox)
                    cd = np.linalg.norm((pb[:2] + pb[2:]) / 2 - (d.bbox[:2] + d.bbox[2:]) / 2) / (diag + 1e-6)
                    if ov > 0.12 or cd < 0.6:
                        cost[i, j] = (1 - ov) * 0.7 + min(cd, 1.5) * 0.3
            r, c = linear_sum_assignment(cost)
            for i, j in zip(r, c):
                if cost[i, j] < 5:
                    active[i].add(idx, dets[j], hists[j])
                    matched_d.add(j)
                    matched_t.add(active[i].id)
        # re-identification of unmatched detections against recently lost tracks
        lost = [t for t in self.tracks if t.id not in matched_t and self.max_gap < idx - t.last_frame <= self.reid_gap and t.hist is not None]
        for j, d in enumerate(dets):
            if j in matched_d:
                continue
            best, best_s = None, self.reid_thr
            for t in lost:
                if t.id in matched_t:
                    continue
                s = cv2.compareHist(t.hist.reshape(16, 8), hists[j].reshape(16, 8), cv2.HISTCMP_CORREL)
                size_ratio = (d.bbox[2] - d.bbox[0]) / max(1.0, t.last_bbox[2] - t.last_bbox[0])
                if 0.5 < size_ratio < 2.0 and s > best_s:
                    best, best_s = t, s
            if best is not None:
                best.add(idx, d, hists[j])
                matched_t.add(best.id)
            else:
                self._new().add(idx, d, hists[j])

    def finalize(self) -> list[Track]:
        keep = [t for t in self.tracks if len(t.dets) >= self.min_len]
        return sorted(keep, key=lambda t: t.id)
