"""Person-silhouette segmentation (MediaPipe SelfieSegmentation, bundled weights) and an
OPTIONAL BiSeNet-style face-parsing ONNX model for hair / glasses / hat occlusion handling."""
from __future__ import annotations

import logging
import threading
from pathlib import Path

import cv2
import numpy as np

from ..core.config import get_settings

log = logging.getLogger("segmentation")
_tls = threading.local()


class PersonSegmenter:
    def __init__(self):
        import mediapipe as mp
        self._seg = mp.solutions.selfie_segmentation.SelfieSegmentation(model_selection=0)

    def mask(self, bgr: np.ndarray) -> np.ndarray:
        """Soft person mask in [0,1], same size as input."""
        res = self._seg.process(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
        m = res.segmentation_mask.astype(np.float32)
        return np.clip(m, 0, 1)


def get_segmenter() -> PersonSegmenter:
    s = getattr(_tls, "seg", None)
    if s is None:
        s = _tls.seg = PersonSegmenter()
    return s


# CelebAMask-HQ / BiSeNet label ids
PARSE = dict(bg=0, skin=1, l_brow=2, r_brow=3, l_eye=4, r_eye=5, eye_g=6, l_ear=7, r_ear=8, ear_r=9, nose=10,
             mouth=11, u_lip=12, l_lip=13, neck=14, neck_l=15, cloth=16, hair=17, hat=18)


class FaceParser:
    """Optional. Drop a face-parsing ONNX (19 classes, 512x512 input, ImageNet normalisation)
    at models/face_parsing.onnx. Without it the compositor falls back to a colour heuristic."""

    def __init__(self, path: Path):
        import onnxruntime as ort
        providers = ["CPUExecutionProvider"]
        if get_settings().use_gpu:
            avail = ort.get_available_providers()
            providers = [p for p in ("CUDAExecutionProvider", "DmlExecutionProvider", "CoreMLExecutionProvider") if p in avail] + providers
        self.sess = ort.InferenceSession(str(path), providers=providers)
        self.inp = self.sess.get_inputs()[0].name

    def labels(self, bgr: np.ndarray) -> np.ndarray:
        h, w = bgr.shape[:2]
        x = cv2.resize(bgr, (512, 512), interpolation=cv2.INTER_LINEAR)[:, :, ::-1].astype(np.float32) / 255.0
        x = (x - np.array([0.485, 0.456, 0.406], np.float32)) / np.array([0.229, 0.224, 0.225], np.float32)
        out = self.sess.run(None, {self.inp: x.transpose(2, 0, 1)[None]})[0]
        lab = out.argmax(1)[0].astype(np.uint8)
        return cv2.resize(lab, (w, h), interpolation=cv2.INTER_NEAREST)

    def occluders(self, bgr: np.ndarray) -> np.ndarray:
        lab = self.labels(bgr)
        m = np.isin(lab, [PARSE["hair"], PARSE["hat"], PARSE["eye_g"], PARSE["ear_r"], PARSE["cloth"]]).astype(np.float32)
        return m


_parser: FaceParser | None = None
_parser_tried = False
_parser_lock = threading.Lock()


def get_parser() -> FaceParser | None:
    global _parser, _parser_tried
    with _parser_lock:
        if _parser_tried:
            return _parser
        _parser_tried = True
        p = get_settings().models_dir / "face_parsing.onnx"
        if p.exists():
            try:
                _parser = FaceParser(p)
                log.info("Face-parsing model loaded: %s", p)
            except Exception as e:           # pragma: no cover - depends on user model
                log.warning("Could not load face-parsing model (%s); using heuristic occlusion masks", e)
        return _parser
