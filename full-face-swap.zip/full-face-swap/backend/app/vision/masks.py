"""Geometry-driven masks (all in ROI pixel coordinates)."""
from __future__ import annotations

import cv2
import numpy as np

from . import landmarks as L

_SH = 4  # fixed-point shift for sub-pixel anti-aliased polygon fills


def fill_poly(shape: tuple[int, int], pts: np.ndarray, value: float = 1.0) -> np.ndarray:
    m = np.zeros(shape, np.float32)
    if len(pts) >= 3:
        cv2.fillPoly(m, [np.round(pts[:, :2] * (1 << _SH)).astype(np.int32)], value, lineType=cv2.LINE_AA, shift=_SH)
    return m


def scale_poly(pts: np.ndarray, k: float, center: np.ndarray | None = None) -> np.ndarray:
    c = pts[:, :2].mean(0) if center is None else center
    return (pts[:, :2] - c) * k + c


def hull(pts: np.ndarray) -> np.ndarray:
    return cv2.convexHull(pts[:, :2].astype(np.float32)).reshape(-1, 2)


def feather(m: np.ndarray, sigma: float) -> np.ndarray:
    if sigma < 0.3:
        return m
    return cv2.GaussianBlur(m, (0, 0), sigma)


def face_zone(shape, lm: np.ndarray, mode: str, expand: float) -> np.ndarray:
    """Hard mask of the region whose identity is replaced."""
    oval = lm[L.FACE_OVAL, :2]
    if mode == "face_only":
        k = 0.93 + 0.06 * expand
        return fill_poly(shape, scale_poly(oval, k))
    # face_head / full_head_hair: whole face incl. jaw, ears, temples
    k = 1.04 + 0.08 * expand
    p = scale_poly(oval, k)
    w = L.face_width(lm)
    ears = np.array([lm[234, :2] + (lm[234, :2] - lm[454, :2]) / (w + 1e-6) * 0.07 * w,
                     lm[454, :2] + (lm[454, :2] - lm[234, :2]) / (w + 1e-6) * 0.07 * w], np.float32)
    return fill_poly(shape, hull(np.concatenate([p, ears], 0)))


def head_zone(shape, lm: np.ndarray, expand: float) -> np.ndarray:
    ext = L.extended_head_points(lm)
    pts = np.concatenate([lm[L.FACE_OVAL, :2], ext], 0)
    return fill_poly(shape, scale_poly(hull(pts), 1.0 + 0.06 * expand))


def inner_mouth(shape, lm: np.ndarray, shrink: float = 0.82) -> np.ndarray:
    pts = lm[L.LIPS_INNER, :2]
    area = abs(cv2.contourArea(pts.astype(np.float32)))
    if area < 4:
        return np.zeros(shape, np.float32)
    return fill_poly(shape, scale_poly(pts, shrink))


def eye_zones(shape, lm: np.ndarray, grow: float = 1.35) -> tuple[np.ndarray, np.ndarray]:
    return (fill_poly(shape, scale_poly(lm[L.EYE_A, :2], grow)), fill_poly(shape, scale_poly(lm[L.EYE_B, :2], grow)))


def skin_core(shape, lm: np.ndarray) -> np.ndarray:
    """Cheeks/forehead/nose bridge area used for colour statistics (no eyes, brows, lips)."""
    m = fill_poly(shape, scale_poly(lm[L.FACE_OVAL, :2], 0.82))
    for loop, g in ((L.EYE_A, 1.8), (L.EYE_B, 1.8), (L.LIPS_OUTER, 1.5), (L.BROW_A, 1.25), (L.BROW_B, 1.25)):
        m = np.clip(m - fill_poly(shape, scale_poly(lm[loop, :2], g)), 0, 1)
    return m


def skin_distance(img_bgr: np.ndarray, lm: np.ndarray) -> np.ndarray | None:
    """Per-pixel colour distance (in 'sigmas') from the skin colour sampled on this face's cheeks/nose."""
    shape = img_bgr.shape[:2]
    lab = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)
    samp = np.zeros(shape, np.float32)
    r = max(2, int(0.035 * L.face_width(lm)))
    for i in L.CHEEK_A[:2] + L.CHEEK_B[:2] + [4]:
        cv2.circle(samp, (int(lm[i, 0]), int(lm[i, 1])), r, 1.0, -1)
    px = lab[samp > 0.5]
    if len(px) < 10:
        return None
    mu = px.mean(0)
    sd = px.std(0) + np.array([6.0, 4.0, 4.0], np.float32)     # tolerance for shading
    return np.sqrt((((lab - mu) / sd) ** 2).sum(2))


def skin_likeness(img_bgr: np.ndarray, lm: np.ndarray) -> np.ndarray:
    z = skin_distance(img_bgr, lm)
    if z is None:
        return np.ones(img_bgr.shape[:2], np.float32)
    return cv2.GaussianBlur(1.0 - np.clip((z - 3.4) / 2.2, 0, 1), (0, 0), 1.2).astype(np.float32)


def hair_side_map(shape, lm: np.ndarray) -> np.ndarray:
    """0 on face/neck skin, 1 in the hair crown (measured along the head's up axis, above the brows)."""
    h, w = shape
    up = lm[10, :2] - lm[152, :2]
    up = up / (np.linalg.norm(up) + 1e-6)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    bm = lm[[105, 334], :2].mean(0)
    along = ((xx - bm[0]) * up[0] + (yy - bm[1]) * up[1]) / (L.face_height(lm) + 1e-6)
    return np.clip((along - 0.05) / 0.3, 0, 1).astype(np.float32)


def forehead_occluder(roi_bgr: np.ndarray, lm: np.ndarray) -> np.ndarray:
    """Heuristic occlusion mask for hair/fringe/hats over the forehead: pixels whose colour is far
    from the sampled skin colour. Returns a soft [0,1] mask (forehead zone only)."""
    shape = roi_bgr.shape[:2]
    zone = fill_poly(shape, lm[L.FOREHEAD_ZONE, :2])
    if zone.sum() < 20:
        return np.zeros(shape, np.float32)
    z = skin_distance(roi_bgr, lm)
    if z is None:
        return np.zeros(shape, np.float32)
    occ = cv2.GaussianBlur(np.clip((z - 3.2) / 2.0, 0, 1), (0, 0), 1.2)
    return (occ * zone).astype(np.float32)
