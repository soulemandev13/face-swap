"""Swap engines. An engine turns (target ROI, target landmarks, reference) into a *source layer*
that the compositor then masks, colour-matches and blends.

* MeshWarpEngine  - dependency-free. Piecewise-affine warp of the reference's face+head mesh onto the
                    target's landmark mesh. Follows speech/blinks/gaze because the geometry is the target's
                    per-frame landmarks (incl. iris points). Identity fidelity is texture-level only.
* InsightFaceEngine - optional neural engine (InsightFace buffalo_l + inswapper_128 ONNX). Much better
                    identity transfer; needs model files (see models/README.md). Plugged in as the *face layer*
                    on top of the mesh layer.
"""
from __future__ import annotations

import logging
from pathlib import Path

import cv2
import numpy as np

from ..core.config import get_settings
from . import landmarks as L
from .reference import RefBundle

log = logging.getLogger("engines")


def warp_mesh(src4: np.ndarray, src_pts: np.ndarray, dst_pts: np.ndarray, tris: np.ndarray, out_hw: tuple[int, int]) -> tuple[np.ndarray, np.ndarray]:
    """Piecewise-affine warp of an N-channel uint8 image. Returns (warped, coverage)."""
    H, W = out_hw
    sh, sw = src4.shape[:2]
    out = np.zeros((H, W, src4.shape[2]), np.uint8)
    cov = np.zeros((H, W), np.uint8)
    for t in tris:
        s = src_pts[t].astype(np.float32)
        d = dst_pts[t].astype(np.float32)
        area = 0.5 * abs((d[1, 0] - d[0, 0]) * (d[2, 1] - d[0, 1]) - (d[2, 0] - d[0, 0]) * (d[1, 1] - d[0, 1]))
        if area < 0.6:
            continue
        rx, ry, rw, rh = cv2.boundingRect(d)
        x0, y0, x1, y1 = max(rx, 0), max(ry, 0), min(rx + rw + 1, W), min(ry + rh + 1, H)
        if x1 <= x0 or y1 <= y0:
            continue
        qx, qy, qw, qh = cv2.boundingRect(s)
        qx0, qy0, qx1, qy1 = max(qx - 1, 0), max(qy - 1, 0), min(qx + qw + 2, sw), min(qy + qh + 2, sh)
        if qx1 - qx0 < 2 or qy1 - qy0 < 2:
            continue
        M = cv2.getAffineTransform(s - np.array([qx0, qy0], np.float32), d - np.array([x0, y0], np.float32))
        patch = cv2.warpAffine(src4[qy0:qy1, qx0:qx1], M, (x1 - x0, y1 - y0), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT_101)
        m = np.zeros((y1 - y0, x1 - x0), np.uint8)
        cv2.fillConvexPoly(m, np.round((d - np.array([x0, y0], np.float32)) * 16).astype(np.int32), 1, cv2.LINE_8, 4)
        sel = m > 0
        out[y0:y1, x0:x1][sel] = patch[sel]
        cov[y0:y1, x0:x1][sel] = 1
    return out, cov.astype(np.float32)


class MeshWarpEngine:
    name = "mesh_warp"

    @staticmethod
    def available() -> tuple[bool, str]:
        return True, "built in (no model files needed)"

    def prepare(self, ref: RefBundle) -> None:
        if ref.packed is None:
            ref.packed = np.dstack([ref.img, np.clip(ref.fg * 255, 0, 255).astype(np.uint8)])

    def render(self, ref: RefBundle, lm_roi: np.ndarray, shape: tuple[int, int]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        self.prepare(ref)
        dst = L.mesh_control_points(lm_roi)
        out, cov = warp_mesh(ref.packed, ref.ctrl, dst, ref.tris, shape)
        return out[:, :, :3], cov, out[:, :, 3].astype(np.float32) / 255.0


class InsightFaceEngine:
    name = "insightface"

    @staticmethod
    def available() -> tuple[bool, str]:
        m = get_settings().models_dir / "inswapper_128.onnx"
        if not m.exists():
            return False, f"model file missing: {m} (see models/README.md)"
        try:
            import insightface  # noqa: F401
            import onnxruntime  # noqa: F401
        except Exception as e:
            return False, f"python packages missing ({e}); pip install -r backend/requirements-neural.txt"
        return True, "inswapper_128 + buffalo_l"

    def __init__(self):
        import insightface
        import onnxruntime as ort
        from insightface.app import FaceAnalysis
        s = get_settings()
        providers = ["CPUExecutionProvider"]
        ctx = -1
        if s.use_gpu:
            av = ort.get_available_providers()
            gpu = [p for p in ("CUDAExecutionProvider", "DmlExecutionProvider", "CoreMLExecutionProvider") if p in av]
            if gpu:
                providers, ctx = gpu + providers, 0
        self.app = FaceAnalysis(name="buffalo_l", root=str(s.models_dir / "insightface"), providers=providers,
                                allowed_modules=["detection", "recognition"])
        self.app.prepare(ctx_id=ctx, det_size=(320, 320))
        self.swapper = insightface.model_zoo.get_model(str(s.models_dir / "inswapper_128.onnx"), providers=providers)
        self.providers = providers

    def prepare(self, ref: RefBundle) -> None:
        faces = self.app.get(ref.img)
        if not faces:
            raise RuntimeError("InsightFace could not find a face in the reference image.")
        faces.sort(key=lambda f: -(f.bbox[2] - f.bbox[0]) * (f.bbox[3] - f.bbox[1]))
        ref.neural = faces[0]

    def face_layer(self, roi: np.ndarray, lm_roi: np.ndarray, ref: RefBundle) -> tuple[np.ndarray, np.ndarray] | None:
        if ref.neural is None:
            return None
        faces = self.app.get(roi)
        if not faces:
            return None
        bb = L.bbox_of(lm_roi)
        best, best_o = None, 0.0
        for f in faces:
            o = L.iou(np.asarray(f.bbox, np.float32), bb)
            if o > best_o:
                best, best_o = f, o
        if best is None or best_o < 0.3:
            return None
        fake, M = self.swapper.get(roi, best, ref.neural, paste_back=False)
        h, w = roi.shape[:2]
        IM = cv2.invertAffineTransform(M)
        layer = cv2.warpAffine(fake, IM, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
        ones = np.zeros(fake.shape[:2], np.float32)
        k = int(fake.shape[0] * 0.07)
        ones[k:-k, k:-k] = 1.0
        valid = cv2.warpAffine(ones, IM, (w, h), flags=cv2.INTER_LINEAR)
        return layer, cv2.GaussianBlur(valid, (0, 0), 3)


_neural_singleton: InsightFaceEngine | None = None


def get_engine(name: str) -> tuple[str, InsightFaceEngine | None, str]:
    """Resolve the requested engine -> (effective_name, neural_engine_or_None, note)."""
    global _neural_singleton
    if name in ("auto", "insightface"):
        ok, why = InsightFaceEngine.available()
        if ok:
            try:
                if _neural_singleton is None:
                    _neural_singleton = InsightFaceEngine()
                return "insightface", _neural_singleton, "neural identity engine active"
            except Exception as e:                                  # pragma: no cover
                log.exception("InsightFace init failed")
                why = f"initialisation failed: {e}"
        if name == "insightface":
            return "mesh_warp", None, f"InsightFace unavailable ({why}); fell back to mesh_warp"
        return "mesh_warp", None, f"using built-in mesh_warp engine (InsightFace: {why})"
    return "mesh_warp", None, "mesh_warp engine"


def engine_report() -> dict:
    ok, why = InsightFaceEngine.available()
    return {"mesh_warp": {"available": True, "detail": MeshWarpEngine.available()[1]},
            "insightface": {"available": ok, "detail": why}}
