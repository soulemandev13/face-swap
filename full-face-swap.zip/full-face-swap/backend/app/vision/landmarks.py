"""MediaPipe FaceMesh (478-point) topology constants and geometry helpers."""
from __future__ import annotations

import numpy as np

# ordered closed loops (indices into the 478-point mesh)
FACE_OVAL = [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377,
             152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109]
LIPS_OUTER = [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 409, 270, 269, 267, 0, 37, 39, 40, 185]
LIPS_INNER = [78, 95, 88, 178, 87, 14, 317, 402, 318, 324, 308, 415, 310, 311, 312, 13, 82, 81, 80, 191]
EYE_A = [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246]      # image-left eye
EYE_B = [362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398]   # image-right eye
BROW_A = [70, 63, 105, 66, 107, 55, 65, 52, 53, 46]
BROW_B = [336, 296, 334, 293, 300, 285, 295, 282, 283, 276]
NOSE = [1, 2, 4, 5, 6, 19, 94, 98, 168, 195, 197, 129, 358, 49, 279, 209, 429]
IRIS_A = [468, 469, 470, 471, 472]
IRIS_B = [473, 474, 475, 476, 477]
CHEEK_A = [205, 207, 187, 123, 50]
CHEEK_B = [425, 427, 411, 352, 280]
FOREHEAD_ZONE = [10, 338, 297, 332, 284, 251, 301, 298, 333, 334, 296, 336, 9, 107, 66, 105, 63, 70, 71, 68, 104, 69, 108, 151, 109, 67, 103, 54, 21, 162]

N_LANDMARKS = 478

# feature groups for per-group temporal smoothing
RIGID_IDX = sorted(set(FACE_OVAL + NOSE + CHEEK_A + CHEEK_B + BROW_A + BROW_B))
EXPRESSIVE_IDX = sorted(set(LIPS_OUTER + LIPS_INNER + EYE_A + EYE_B + IRIS_A + IRIS_B))


def bbox_of(pts: np.ndarray) -> np.ndarray:
    return np.array([pts[:, 0].min(), pts[:, 1].min(), pts[:, 0].max(), pts[:, 1].max()], np.float32)


def iou(a: np.ndarray, b: np.ndarray) -> float:
    x1, y1 = max(a[0], b[0]), max(a[1], b[1])
    x2, y2 = min(a[2], b[2]), min(a[3], b[3])
    inter = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return float(inter / ua) if ua > 0 else 0.0


def dist(p: np.ndarray, i: int, j: int) -> float:
    return float(np.linalg.norm(p[i, :2] - p[j, :2]))


def eye_aspect_ratio(p: np.ndarray) -> tuple[float, float]:
    """Eye aspect ratio (≈0.30 open, <0.15 closed) for the image-left and image-right eye."""
    a = (dist(p, 160, 144) + dist(p, 158, 153)) / (2 * dist(p, 33, 133) + 1e-6)
    b = (dist(p, 385, 380) + dist(p, 387, 373)) / (2 * dist(p, 362, 263) + 1e-6)
    return float(a), float(b)


def mouth_aspect_ratio(p: np.ndarray) -> float:
    """Inner-lip opening relative to mouth width (≈0 closed, >0.3 wide open)."""
    return float(dist(p, 13, 14) / (dist(p, 78, 308) + 1e-6))


def head_pose(p: np.ndarray) -> tuple[float, float, float]:
    """(yaw, pitch, roll) in degrees from mesh geometry (z-aware). Sign convention is
    consistent between reference and target which is all that selection logic needs."""
    roll = np.degrees(np.arctan2(p[263, 1] - p[33, 1], p[263, 0] - p[33, 0]))
    dx = p[454, 0] - p[234, 0]
    yaw = np.degrees(np.arctan2(p[454, 2] - p[234, 2], max(abs(dx), 1e-6)))
    dy = p[152, 1] - p[10, 1]
    pitch = np.degrees(np.arctan2(p[152, 2] - p[10, 2], max(abs(dy), 1e-6)))
    return float(yaw), float(pitch), float(roll)


def face_width(p: np.ndarray) -> float:
    return dist(p, 234, 454)


def face_height(p: np.ndarray) -> float:
    return dist(p, 10, 152)


def extended_head_points(p: np.ndarray) -> np.ndarray:
    """Deterministic extra control points (hair crown, ears, neck) derived from the mesh.
    Same formula on reference and target gives point-to-point correspondence."""
    q = p[:, :2].astype(np.float32)
    c = q[FACE_OVAL].mean(0)
    up = q[10] - q[152]
    h = float(np.linalg.norm(up)) + 1e-6
    up = up / h
    right = np.array([-up[1], up[0]], np.float32)
    # make `right` point from image-left ear (234) to image-right ear (454)
    if np.dot(right, q[454] - q[234]) < 0:
        right = -right
    w = float(np.linalg.norm(q[454] - q[234])) + 1e-6
    pts = []
    # crown arc: top-of-oval points pushed up/out
    for idx, side in [(21, -1), (54, -1), (103, -1), (67, -.6), (109, -.3), (10, 0), (338, .3), (297, .6), (332, 1), (284, 1), (251, 1)]:
        base = q[idx]
        pts.append(base + up * 0.38 * h + right * side * 0.10 * w)
        pts.append(base + up * 0.78 * h + right * side * 0.16 * w)
    # ears / temples
    for idx, s in [(234, -1), (454, 1), (127, -1), (356, 1), (93, -1), (323, 1)]:
        pts.append(q[idx] + right * s * 0.16 * w)
    # neck
    for idx, s in [(152, 0), (148, -.4), (377, .4), (176, -.6), (400, .6)]:
        pts.append(q[idx] - up * 0.34 * h + right * s * 0.10 * w)
    pts.append(c - up * 0.62 * h - right * 0.55 * w)
    pts.append(c - up * 0.62 * h + right * 0.55 * w)
    return np.asarray(pts, np.float32)


def mesh_control_points(p: np.ndarray) -> np.ndarray:
    """Sparse set of mesh points (face detail) + extended head points used for warping."""
    keep = sorted(set(FACE_OVAL + LIPS_OUTER + LIPS_INNER + EYE_A + EYE_B + BROW_A + BROW_B + NOSE + CHEEK_A + CHEEK_B
                      + IRIS_A + IRIS_B + [9, 8, 168, 151, 200, 199, 175, 18, 17, 0, 164, 2, 97, 326, 205, 425, 50, 280, 101, 330, 36, 266,
                         116, 345, 123, 352, 147, 376, 213, 433, 138, 367]))
    return np.concatenate([p[keep, :2].astype(np.float32), extended_head_points(p)], 0)
