"""Boundary-aware compositing: region masks, occlusion/expression handling, colour + sharpness
matching, feathered or Laplacian-pyramid blending. Works on a head-sized ROI for speed."""
from __future__ import annotations

import cv2
import numpy as np

from ..models.schemas import ProcessingSettings
from . import landmarks as L
from . import masks as M
from .engines import MeshWarpEngine
from .reference import RefBundle, choose_ref
from .segmentation import get_parser, get_segmenter
from .temporal import TargetFace


def _wstats(lab: np.ndarray, w: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    ws = float(w.sum()) + 1e-6
    mu = (lab * w[..., None]).sum((0, 1)) / ws
    var = (((lab - mu) ** 2) * w[..., None]).sum((0, 1)) / ws
    return mu.astype(np.float32), np.sqrt(var).astype(np.float32) + 1e-3


def lap_blend(a: np.ndarray, b: np.ndarray, m: np.ndarray, levels: int = 4) -> np.ndarray:
    """Laplacian-pyramid blend of float32 images a (bg) and b (fg) with mask m (HxW)."""
    h, w = m.shape
    levels = int(max(1, min(levels, np.log2(max(min(h, w), 2)) - 2)))
    ga, gb, gm = [a], [b], [m]
    for _ in range(levels):
        ga.append(cv2.pyrDown(ga[-1])); gb.append(cv2.pyrDown(gb[-1])); gm.append(cv2.pyrDown(gm[-1]))
    out = None
    for i in range(levels, -1, -1):
        if i == levels:
            la, lb = ga[i], gb[i]
        else:
            sz = (ga[i].shape[1], ga[i].shape[0])
            la = ga[i] - cv2.pyrUp(ga[i + 1], dstsize=sz)
            lb = gb[i] - cv2.pyrUp(gb[i + 1], dstsize=sz)
        mm = gm[i][..., None]
        lvl = la * (1 - mm) + lb * mm
        out = lvl if out is None else cv2.pyrUp(out, dstsize=(lvl.shape[1], lvl.shape[0])) + lvl
    return out


class Compositor:
    def __init__(self, settings: ProcessingSettings, neural=None):
        self.S = settings
        self.mesh = MeshWarpEngine()
        self.neural = neural
        self._seg = None
        self._seg_failed = False

    # ------------------------------------------------------------------------------
    def prepare_refs(self, refs: list[RefBundle]) -> None:
        for r in refs:
            self.mesh.prepare(r)
            if self.neural is not None:
                self.neural.prepare(r)

    def _person_mask(self, roi: np.ndarray) -> np.ndarray:
        if self._seg_failed:
            return np.ones(roi.shape[:2], np.float32)
        try:
            if self._seg is None:
                self._seg = get_segmenter()
            m = self._seg.mask(roi)
            return cv2.GaussianBlur(m, (0, 0), 1.2)
        except Exception:
            self._seg_failed = True
            return np.ones(roi.shape[:2], np.float32)

    @staticmethod
    def _ema(st: dict, key: str, val: np.ndarray, a: float) -> np.ndarray:
        prev = st.get(key)
        cur = val if prev is None else a * val + (1 - a) * prev
        st[key] = cur
        return cur

    def _transfer(self, lab_s: np.ndarray, mu_s, sd_s, mu_t, sd_t, strength: float, light_only: bool) -> np.ndarray:
        g = np.clip(sd_t / sd_s, 0.6, 1.6)
        adj = (lab_s - mu_s) * g + mu_t
        if light_only:
            adj[..., 1:] = lab_s[..., 1:]
        return lab_s * (1 - strength) + adj * strength

    # ------------------------------------------------------------------------------
    def process(self, frame: np.ndarray, tf: TargetFace, refs: list[RefBundle], others: list[np.ndarray], st: dict) -> tuple[np.ndarray, dict]:
        S = self.S
        H, W = frame.shape[:2]
        lm = tf.lm
        fw = L.face_width(lm)
        ext = L.extended_head_points(lm)
        allp = np.concatenate([lm[L.FACE_OVAL, :2], ext], 0)
        pad = 0.15 * fw
        x0, y0 = int(max(0, allp[:, 0].min() - pad)), int(max(0, allp[:, 1].min() - pad))
        x1, y1 = int(min(W, allp[:, 0].max() + pad)), int(min(H, allp[:, 1].max() + pad))
        if x1 - x0 < 24 or y1 - y0 < 24 or fw < 18:
            return frame, {"skipped": "too small"}
        roi = frame[y0:y1, x0:x1].copy()
        h, w = roi.shape[:2]
        shape = (h, w)
        lm_r = lm - np.array([x0, y0, 0], np.float32)
        ref = choose_ref(refs, tf.pose)
        mode = S.replacement_mode
        hi_q = S.quality != "draft"

        # ---- source layer -----------------------------------------------------------------
        mesh_img, cov, fgw = self.mesh.render(ref, lm_r, shape)
        neural_used = False
        nlayer = None
        if self.neural is not None:
            try:
                nlayer = self.neural.face_layer(roi, lm_r, ref)
            except Exception:
                nlayer = None

        # ---- zones -------------------------------------------------------------------------
        fz = M.face_zone(shape, lm_r, mode, S.mask_expand)
        sigma = max(0.8, (0.010 + 0.028 * S.mask_strength) * fw)
        core = M.skin_core(shape, lm_r)
        if mode == "full_head_hair" and S.hair_transfer > 0:
            hz = M.head_zone(shape, lm_r, S.mask_expand)
            person = self._person_mask(roi)
            hs = M.hair_side_map(shape, lm_r)
            gate = hs * np.clip((person - 0.35) / 0.4, 0, 1) + (1 - hs) * M.skin_likeness(roi, lm_r)
            hair_zone = np.clip(hz - fz, 0, 1) * gate * fgw * S.hair_transfer
        else:
            hair_zone = np.zeros(shape, np.float32)
        alpha = np.clip(fz + hair_zone * (1 - fz), 0, 1) * cov

        # ---- colour / lighting match ----------------------------------------------------------
        a_ema = 1.0 - 0.8 * S.temporal_smoothing
        roi_f = roi.astype(np.float32) / 255.0
        lab_t = cv2.cvtColor(roi_f, cv2.COLOR_BGR2LAB)
        hair_side = M.hair_side_map(shape, lm_r)                   # 0 on skin (face/neck), 1 in hair crown

        def match(layer_bgr: np.ndarray, valid: np.ndarray, strength: float, key: str) -> np.ndarray:
            lab_s = cv2.cvtColor(layer_bgr.astype(np.float32) / 255.0, cv2.COLOR_BGR2LAB)
            ws = core * valid
            if ws.sum() < 30 or core.sum() < 30:
                return layer_bgr.astype(np.float32) / 255.0
            mu_s, sd_s = _wstats(lab_s, ws)
            mu_t, sd_t = _wstats(lab_t, core)
            mu_s = self._ema(st, key + "mu_s", mu_s, a_ema); sd_s = self._ema(st, key + "sd_s", sd_s, a_ema)
            mu_t = self._ema(st, key + "mu_t", mu_t, a_ema); sd_t = self._ema(st, key + "sd_t", sd_t, a_ema)
            full = self._transfer(lab_s, mu_s, sd_s, mu_t, sd_t, strength, False)
            light = self._transfer(lab_s, mu_s, sd_s, mu_t, sd_t, strength, True)
            hs = hair_side[..., None] if mode == "full_head_hair" else 0.0
            lab_o = full * (1 - hs) + light * hs
            return np.clip(cv2.cvtColor(lab_o.astype(np.float32), cv2.COLOR_LAB2BGR), 0, 1)

        src = match(mesh_img, cov, S.color_match, "m_")
        if nlayer is not None:
            nimg, nval = nlayer
            nsrc = match(nimg, nval, S.color_match * 0.7, "n_")
            nv = (nval * fz)[..., None]
            src = src * (1 - nv) + nsrc * nv
            neural_used = True

        # sharpness / texture match (balanced+)
        if hi_q and core.sum() > 60:
            sel = core > 0.5
            gt = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            gs = cv2.cvtColor((src * 255).astype(np.uint8), cv2.COLOR_BGR2GRAY)
            vt = float(cv2.Laplacian(gt, cv2.CV_32F)[sel].var()) + 1e-3
            vs = float(cv2.Laplacian(gs, cv2.CV_32F)[sel].var()) + 1e-3
            if vs > 1.35 * vt:
                for sg in (0.6, 0.9, 1.3, 1.8, 2.4):
                    b = cv2.GaussianBlur(src, (0, 0), sg)
                    gb = cv2.cvtColor((b * 255).astype(np.uint8), cv2.COLOR_BGR2GRAY)
                    if float(cv2.Laplacian(gb, cv2.CV_32F)[sel].var()) <= 1.2 * vt:
                        break
                src = b
            elif vs < 0.6 * vt:
                src = np.clip(src + 0.5 * (src - cv2.GaussianBlur(src, (0, 0), 1.2)), 0, 1)

        # fill invalid source area with the original so feathering can never leak black
        src = src * cov[..., None] + roi_f * (1 - cov[..., None])

        # ---- expression handling: keep target's inner mouth / closed eyelids ----------------------
        keep = np.zeros(shape, np.float32)
        if S.preserve_inner_mouth:
            keep = np.maximum(keep, M.feather(M.inner_mouth(shape, lm_r), 1.0))
        eye_keep = np.zeros(shape, np.float32)
        if S.preserve_closed_eyes:
            ea, eb = M.eye_zones(shape, lm_r)
            ca = float(np.clip((0.21 - tf.ear[0]) / 0.08, 0, 1))
            cb = float(np.clip((0.21 - tf.ear[1]) / 0.08, 0, 1))
            eye_keep = np.maximum(ea * ca, eb * cb)
            eye_keep = M.feather(eye_keep, 1.5)
        # ---- occlusion (hair over forehead, glasses, hats) -----------------------------------------
        occ = np.zeros(shape, np.float32)
        if hi_q:
            parser = get_parser() if S.quality == "high" else None
            try:
                occ = parser.occluders(roi) * fz if parser is not None else M.forehead_occluder(roi, lm_r)
            except Exception:
                occ = M.forehead_occluder(roi, lm_r)
            if mode == "full_head_hair":
                occ = occ * (1 - S.hair_transfer)
        # ---- protect neighbours --------------------------------------------------------------------
        protect = np.zeros(shape, np.float32)
        for o in others:
            op = o[L.FACE_OVAL, :2] - np.array([x0, y0], np.float32)
            protect = np.maximum(protect, M.fill_poly(shape, M.scale_poly(op, 1.2)))
        protect = M.feather(protect, max(1.0, 0.02 * fw))

        alpha = M.feather(alpha, sigma) * cov
        alpha = alpha * (1 - np.maximum(keep, occ)) * (1 - protect) * tf.gain

        # closed eyelids: keep the target's eyelid but tone-shift it towards the swapped skin so no patch shows
        base = roi_f
        if eye_keep.max() > 0.02:
            ws = core * cov
            if ws.sum() > 30:
                mu_out, _ = _wstats(cv2.cvtColor(np.clip(src, 0, 1).astype(np.float32), cv2.COLOR_BGR2LAB), ws)
                mu_in, _ = _wstats(lab_t, ws)
                lab_sh = lab_t + (mu_out - mu_in) * 0.8
                base = np.clip(cv2.cvtColor(lab_sh.astype(np.float32), cv2.COLOR_LAB2BGR), 0, 1)
                base = base * eye_keep[..., None] + roi_f * (1 - eye_keep[..., None])
            alpha = alpha * (1 - eye_keep)

        # ---- blend -----------------------------------------------------------------------------------
        if S.quality == "high" and alpha.max() > 0.01:
            out = lap_blend(base, src, alpha, 4)
            out = np.clip(out, 0, 1)
        else:
            out = base * (1 - alpha[..., None]) + src * alpha[..., None]
        frame[y0:y1, x0:x1] = np.clip(out * 255 + 0.5, 0, 255).astype(np.uint8)
        return frame, {"neural": neural_used, "alpha_mean": float(alpha[alpha > 0.01].mean()) if (alpha > 0.01).any() else 0.0,
                       "roi": (x0, y0, x1, y1)}
