"""Reference-identity preparation: decode, detect, quality-check, build warp topology."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np
from scipy.spatial import Delaunay

from . import landmarks as L
from .analyzer import MediaPipeAnalyzer
from .segmentation import get_segmenter


class ReferenceError(Exception):
    """Human-readable reference problem."""


@dataclass
class RefBundle:
    id: str
    img: np.ndarray
    lm: np.ndarray
    ctrl: np.ndarray
    tris: np.ndarray
    fg: np.ndarray                       # float32 person mask (reference background excluded)
    pose: tuple[float, float, float]
    quality: dict = field(default_factory=dict)
    path: Path | None = None
    neural: object | None = None         # engine-specific cache (e.g. insightface Face)
    packed: np.ndarray | None = None     # BGR + foreground packed for a single warp pass


def read_image(path: Path, max_side: int = 1600) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        raise ReferenceError("The reference image could not be decoded. Use a JPG/PNG/WebP photo.")
    h, w = img.shape[:2]
    if max(h, w) > max_side:
        k = max_side / max(h, w)
        img = cv2.resize(img, (int(w * k), int(h * k)), interpolation=cv2.INTER_AREA)
    return img


def assess(img: np.ndarray, analyzer: MediaPipeAnalyzer) -> tuple[list, dict, list[str]]:
    """Returns (detections, quality dict, warnings). Raises ReferenceError if unusable."""
    dets = analyzer.detect(img, thorough=True)
    if not dets:
        raise ReferenceError("No face was found in the reference image. Use a clear, well-lit, mostly front-facing photo of one person.")
    dets.sort(key=lambda d: -(d.bbox[2] - d.bbox[0]) * (d.bbox[3] - d.bbox[1]))
    d = dets[0]
    warnings: list[str] = []
    fw = L.face_width(d.lm)
    x1, y1, x2, y2 = [int(v) for v in d.bbox]
    crop = cv2.cvtColor(img[max(0, y1):y2, max(0, x1):x2], cv2.COLOR_BGR2GRAY)
    sharp = float(cv2.Laplacian(crop, cv2.CV_64F).var()) if crop.size else 0.0
    q = {"face_px": round(fw, 1), "sharpness": round(sharp, 1), "yaw": round(d.pose[0], 1), "pitch": round(d.pose[1], 1),
         "faces_found": len(dets), "ear": [round(x, 2) for x in d.ear], "mar": round(d.mar, 3), "confidence": round(d.conf, 2)}
    if len(dets) > 1:
        warnings.append(f"{len(dets)} faces found in the reference; the largest one is used. Crop to a single person for best results.")
    if fw < 160:
        warnings.append(f"The face is only ~{fw:.0f}px wide; 256px+ is recommended for sharp results.")
    if sharp < 40:
        warnings.append("The reference looks blurry; the result will look soft.")
    if abs(d.pose[0]) > 25 or abs(d.pose[1]) > 25:
        warnings.append("The head is turned noticeably; a frontal reference gives the most consistent identity.")
    if min(d.ear) < 0.17:
        warnings.append("Eyes appear closed in the reference; use a photo with open eyes.")
    if d.mar > 0.25:
        warnings.append("Mouth is wide open in the reference; a relaxed/closed mouth warps more naturally.")
    q["warnings"] = warnings
    return dets, q, warnings


def prepare_reference(path: Path, ref_id: str, analyzer: MediaPipeAnalyzer) -> RefBundle:
    img = read_image(path)
    dets, q, _ = assess(img, analyzer)
    d = dets[0]
    ctrl = L.mesh_control_points(d.lm)
    tris = Delaunay(ctrl).simplices.astype(np.int32)
    try:
        fg = get_segmenter().mask(img)
        fg = cv2.GaussianBlur(fg, (0, 0), 1.5)
    except Exception:
        fg = np.ones(img.shape[:2], np.float32)
    # validity gate for the head layer: hair crown -> person silhouette, neck -> skin only (never clothing)
    from . import masks as M
    hs = M.hair_side_map(img.shape[:2], d.lm)
    skin = M.skin_likeness(img, d.lm)
    fg = (hs * fg + (1 - hs) * np.minimum(fg, skin)).astype(np.float32)
    return RefBundle(id=ref_id, img=img, lm=d.lm, ctrl=ctrl, tris=tris, fg=fg.astype(np.float32), pose=d.pose, quality=q, path=path)


def choose_ref(refs: list[RefBundle], pose: tuple[float, float, float]) -> RefBundle:
    """Reference whose head pose is closest to the target's (helps three-quarter views)."""
    if len(refs) == 1:
        return refs[0]
    return min(refs, key=lambda r: abs(r.pose[0] - pose[0]) + 0.7 * abs(r.pose[1] - pose[1]))
