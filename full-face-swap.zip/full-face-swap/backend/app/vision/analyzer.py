"""Face detection + 478-point landmarks using MediaPipe FaceMesh (weights ship inside the
mediapipe wheel -> works offline with no model downloads)."""
from __future__ import annotations

import threading
from dataclasses import dataclass, field

import cv2
import numpy as np

from . import landmarks as L


@dataclass
class FaceDet:
    bbox: np.ndarray                 # x1,y1,x2,y2 (px)
    lm: np.ndarray                   # (478,3) px (z in px-scale)
    conf: float
    pose: tuple[float, float, float]  # yaw, pitch, roll (deg)
    ear: tuple[float, float]
    mar: float
    track_id: int = -1
    extra: dict = field(default_factory=dict)


def _confidence(lm: np.ndarray, w: int, h: int) -> float:
    """Heuristic detection quality in [0,1] (FaceMesh does not expose a score):
    on-screen landmark fraction x size factor x frontality factor."""
    inside = float(np.mean((lm[:, 0] >= -2) & (lm[:, 0] <= w + 2) & (lm[:, 1] >= -2) & (lm[:, 1] <= h + 2)))
    fw = L.face_width(lm)
    size = min(1.0, fw / 48.0)
    yaw, pitch, _ = L.head_pose(lm)
    pose = 1.0 - min(1.0, max(abs(yaw), abs(pitch) * 0.8) / 110.0)
    return float(np.clip(0.97 * inside * (0.4 + 0.6 * size) * (0.55 + 0.45 * pose), 0, 1))


def describe(lm: np.ndarray, w: int, h: int) -> FaceDet:
    ear = L.eye_aspect_ratio(lm)
    return FaceDet(bbox=L.bbox_of(lm), lm=lm.astype(np.float32), conf=_confidence(lm, w, h),
                   pose=L.head_pose(lm), ear=ear, mar=L.mouth_aspect_ratio(lm))


class MediaPipeAnalyzer:
    """Not thread-safe: create one instance per thread.

    MediaPipe's detector is tuned for large faces, so wide / multi-person frames are scanned
    with overlapping square tiles (and half-size tiles in `thorough` mode) and merged with NMS.
    Between scans the pipeline refines each *known* track inside a small ROI (`detect_near`),
    which is both faster and far more reliable than full-frame detection."""

    def __init__(self, max_faces: int = 8, max_side: int = 1280, min_conf: float = 0.5):
        import mediapipe as mp
        self._mp = mp
        self._max_faces = max_faces
        self._min_conf = min_conf
        self._mesh = mp.solutions.face_mesh.FaceMesh(
            static_image_mode=True, max_num_faces=max_faces, refine_landmarks=True, min_detection_confidence=min_conf)
        self._mesh_roi = mp.solutions.face_mesh.FaceMesh(
            static_image_mode=True, max_num_faces=2, refine_landmarks=True, min_detection_confidence=0.4)
        self.max_side = max_side

    # -- low level ---------------------------------------------------------------------
    def _run(self, mesh, img: np.ndarray) -> list[np.ndarray]:
        h, w = img.shape[:2]
        k = 1.0
        if max(h, w) > self.max_side:
            k = self.max_side / max(h, w)
            img = cv2.resize(img, (max(2, int(w * k)), max(2, int(h * k))), interpolation=cv2.INTER_AREA)
        res = mesh.process(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        out = []
        for fl in (res.multi_face_landmarks or []):
            a = np.array([(p.x, p.y, p.z) for p in fl.landmark], np.float32)
            lm = np.empty_like(a)
            lm[:, 0], lm[:, 1], lm[:, 2] = a[:, 0] * w, a[:, 1] * h, a[:, 2] * w
            out.append(lm)
        return out

    def _region(self, mesh, frame: np.ndarray, x0: int, y0: int, x1: int, y1: int) -> list[tuple[np.ndarray, float]]:
        H, W = frame.shape[:2]
        x0, y0, x1, y1 = max(0, x0), max(0, y0), min(W, x1), min(H, y1)
        if x1 - x0 < 32 or y1 - y0 < 32:
            return []
        crop = frame[y0:y1, x0:x1]
        res = []
        for lm in self._run(mesh, crop):
            lm = lm.copy()
            lm[:, 0] += x0
            lm[:, 1] += y0
            bb = L.bbox_of(lm)
            bs = max(bb[2] - bb[0], bb[3] - bb[1], 1.0)
            # how comfortably inside the crop (and not clipped by the crop edge) the face is
            m = min(bb[0] - x0, bb[1] - y0, x1 - bb[2], y1 - bb[3]) if (x0, y0, x1, y1) != (0, 0, W, H) else min(bb[0], bb[1], W - bb[2], H - bb[3]) + bs
            res.append((lm, float(np.clip(m / (0.35 * bs), 0.25, 1.0))))
        return res

    # -- public ------------------------------------------------------------------------
    def detect(self, frame: np.ndarray, thorough: bool = True) -> list[FaceDet]:
        """Discovery scan: full frame + tiles, merged by NMS."""
        H, W = frame.shape[:2]
        cands: list[tuple[np.ndarray, float]] = self._region(self._mesh, frame, 0, 0, W, H)
        S = min(H, W)
        scales = []
        if max(H, W) / max(S, 1) > 1.25:
            scales.append(S)
        if thorough and S >= 360:
            scales.append(S // 2)
        for ts in scales:
            step = max(ts // 2, 1)
            xs = list(range(0, max(W - ts, 0) + 1, step)) or [0]
            ys = list(range(0, max(H - ts, 0) + 1, step)) or [0]
            if xs[-1] + ts < W:
                xs.append(W - ts)
            if ys[-1] + ts < H:
                ys.append(H - ts)
            for y in ys:
                for x in xs:
                    cands += self._region(self._mesh, frame, x, y, x + ts, y + ts)
        dets = [(describe(lm, W, H), m) for lm, m in cands]
        dets.sort(key=lambda t: -(t[0].conf * t[1]))
        kept: list[FaceDet] = []
        for d, m in dets:
            c = (d.bbox[:2] + d.bbox[2:]) / 2
            dup = False
            for k in kept:
                if L.iou(k.bbox, d.bbox) > 0.35 or (k.bbox[0] < c[0] < k.bbox[2] and k.bbox[1] < c[1] < k.bbox[3]):
                    dup = True
                    break
            if not dup:
                d.extra["margin"] = m
                kept.append(d)
        kept = kept[: self._max_faces]
        kept.sort(key=lambda d: d.bbox[0])
        return kept

    def detect_near(self, frame: np.ndarray, bbox: np.ndarray, expand: float = 1.9) -> FaceDet | None:
        """Refine one face inside an ROI around a predicted box."""
        H, W = frame.shape[:2]
        cx, cy = (bbox[0] + bbox[2]) / 2, (bbox[1] + bbox[3]) / 2
        s = max(bbox[2] - bbox[0], bbox[3] - bbox[1]) * expand / 2
        x0, y0, x1, y1 = int(cx - s), int(cy - s), int(cx + s), int(cy + s)
        best, best_s = None, 0.0
        for lm, m in self._region(self._mesh_roi, frame, x0, y0, x1, y1):
            d = describe(lm, W, H)
            ov = L.iou(d.bbox, bbox)
            c = (d.bbox[:2] + d.bbox[2:]) / 2
            inside = bbox[0] < c[0] < bbox[2] and bbox[1] < c[1] < bbox[3]
            sc = ov + (0.3 if inside else 0.0)
            if sc > best_s and (ov > 0.15 or inside):
                best, best_s = d, sc
        return best

    def close(self) -> None:
        for m in (getattr(self, "_mesh", None), getattr(self, "_mesh_roi", None)):
            try:
                m.close()
            except Exception:
                pass


_tls = threading.local()


def get_analyzer(max_faces: int = 8, max_side: int = 1280) -> MediaPipeAnalyzer:
    """Per-thread cached analyzer (for one-off uses such as reference preparation)."""
    key = (max_faces, max_side)
    a = getattr(_tls, "analyzer", None)
    if a is None or getattr(_tls, "key", None) != key:
        a = MediaPipeAnalyzer(max_faces, max_side)
        _tls.analyzer, _tls.key = a, key
    return a
