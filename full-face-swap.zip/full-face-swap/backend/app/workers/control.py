"""Cooperative job control: cancel / pause / resume + logging + progress hooks."""
from __future__ import annotations

import threading
import time
from typing import Callable


class Cancelled(Exception):
    pass


class JobControl:
    def __init__(self, on_log: Callable[[str, str], None] | None = None,
                 on_progress: Callable[[dict], None] | None = None):
        self._cancel = threading.Event()
        self._run = threading.Event()
        self._run.set()
        self._on_log = on_log
        self._on_progress = on_progress
        self._t0 = time.time()
        self._last_emit = 0.0

    # control ---------------------------------------------------------------------------
    def cancel(self) -> None:
        self._cancel.set()
        self._run.set()           # wake a paused job so it can exit

    def pause(self) -> None:
        self._run.clear()

    def resume(self) -> None:
        self._run.set()

    @property
    def cancelled(self) -> bool:
        return self._cancel.is_set()

    @property
    def paused(self) -> bool:
        return not self._run.is_set()

    def checkpoint(self) -> None:
        """Call once per frame: raises Cancelled, blocks while paused."""
        if self._cancel.is_set():
            raise Cancelled()
        while not self._run.is_set():
            self._run.wait(0.2)
            if self._cancel.is_set():
                raise Cancelled()

    # reporting -------------------------------------------------------------------------
    def log(self, level: str, msg: str) -> None:
        if self._on_log:
            self._on_log(level.upper(), msg)

    def info(self, msg: str) -> None:
        self.log("INFO", msg)

    def warn(self, msg: str) -> None:
        self.log("WARNING", msg)

    def error(self, msg: str) -> None:
        self.log("ERROR", msg)

    def progress(self, stage: str, done: int, total: int, force: bool = False, **extra) -> None:
        now = time.time()
        if not force and now - self._last_emit < 0.4 and done < total:
            return
        self._last_emit = now
        el = max(now - self._t0, 1e-6)
        fps = done / el if done else 0.0
        eta = (total - done) / fps if fps > 0 else None
        if self._on_progress:
            self._on_progress({"stage": stage, "frame": done, "total_frames": total,
                               "percent": round(100.0 * done / total, 1) if total else 0.0,
                               "fps": round(fps, 2), "eta_s": round(eta, 1) if eta is not None else None,
                               "elapsed_s": round(el, 1), **extra})
