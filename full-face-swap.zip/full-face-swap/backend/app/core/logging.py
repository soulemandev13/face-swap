import logging
import sys


def setup_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        stream=sys.stdout,
    )
    # Never log raw media or request bodies; keep third-party chatter down.
    for noisy in ("multipart", "asyncio", "PIL", "absl"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
