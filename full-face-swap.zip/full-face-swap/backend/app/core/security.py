"""Input hygiene: ids, filenames, paths. User-supplied names are never used on disk."""
from __future__ import annotations

import os
import re
import uuid
from pathlib import Path

from fastapi import HTTPException

ALLOWED_VIDEO_EXT = {".mp4", ".mov", ".webm", ".mkv", ".m4v"}
ALLOWED_IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
_ID_RE = re.compile(r"^[a-z]{2,6}_[0-9a-f]{12}$")
_NAME_CLEAN = re.compile(r"[^A-Za-z0-9._\- ]+")


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


def check_id(value: str, prefix: str | None = None) -> str:
    if not isinstance(value, str) or not _ID_RE.match(value) or (prefix and not value.startswith(prefix + "_")):
        raise HTTPException(status_code=400, detail=f"Invalid identifier: {value!r}")
    return value


def display_name(raw: str | None, fallback: str = "file") -> str:
    """Sanitised name for display / download headers only."""
    base = os.path.basename((raw or "").replace("\\", "/")) or fallback
    base = _NAME_CLEAN.sub("_", base).strip(" ._") or fallback
    return base[:120]


def safe_ext(raw_name: str | None, allowed: set[str]) -> str:
    ext = Path(display_name(raw_name)).suffix.lower()
    if ext not in allowed:
        raise HTTPException(status_code=415, detail=f"Unsupported file type {ext or '(none)'}. Allowed: {', '.join(sorted(allowed))}")
    return ext


def resolve_within(base: Path, *parts: str) -> Path:
    """Join and verify the result stays inside *base* (prevents path traversal)."""
    base_r = base.resolve()
    target = base_r.joinpath(*parts).resolve()
    if base_r != target and base_r not in target.parents:
        raise HTTPException(status_code=400, detail="Path escapes the storage directory")
    return target
