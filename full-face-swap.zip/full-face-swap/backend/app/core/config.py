"""Runtime configuration. Every setting can be overridden with an FFS_* environment
variable or a line in the project-root .env file (see .env.example)."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[3]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=str(ROOT / ".env"), env_prefix="FFS_", extra="ignore")

    # --- network: localhost only unless the operator explicitly opts in -------------
    host: str = "127.0.0.1"
    port: int = 8000
    allow_lan: bool = False

    # --- storage (source files and generated files live in separate directories) ----
    data_dir: Path = ROOT / "data"
    models_dir: Path = ROOT / "models"
    frontend_dir: Path = ROOT / "frontend"

    # --- resource protection ---------------------------------------------------------
    max_duration_s: float = 300.0
    max_width: int = 3840
    max_height: int = 2160
    max_upload_mb: int = 2048
    max_reference_mb: int = 25
    max_faces: int = 8
    analysis_max_side: int = 1280

    # --- behaviour -------------------------------------------------------------------
    default_engine: str = "auto"          # auto | mesh_warp | insightface
    use_gpu: bool = True                   # used by ONNX-based engines when available
    retain_temp: bool = False              # keep temp artefacts after a job finishes
    default_label_ai: bool = True          # burn a visible "AI-edited" badge by default
    log_level: str = "INFO"
    ffmpeg_bin: str = "ffmpeg"
    ffprobe_bin: str = "ffprobe"

    # ---- derived paths --------------------------------------------------------------
    @property
    def uploads_dir(self) -> Path:
        return self.data_dir / "uploads"

    @property
    def references_dir(self) -> Path:
        return self.data_dir / "references"

    @property
    def temp_dir(self) -> Path:
        return self.data_dir / "temp"

    @property
    def outputs_dir(self) -> Path:
        return self.data_dir / "outputs"

    @property
    def logs_dir(self) -> Path:
        return self.data_dir / "logs"

    @property
    def analysis_dir(self) -> Path:
        return self.data_dir / "analysis"

    @property
    def db_path(self) -> Path:
        return self.data_dir / "app.sqlite3"

    def ensure_dirs(self) -> None:
        for p in (self.uploads_dir, self.references_dir, self.temp_dir, self.outputs_dir,
                  self.logs_dir, self.analysis_dir, self.models_dir):
            p.mkdir(parents=True, exist_ok=True)

    def check_network_policy(self) -> None:
        if self.host not in ("127.0.0.1", "localhost", "::1") and not self.allow_lan:
            raise RuntimeError(
                f"Refusing to bind to {self.host!r}. The app is localhost-only by default; "
                "set FFS_ALLOW_LAN=true in .env if you really want LAN exposure."
            )


@lru_cache
def get_settings() -> Settings:
    s = Settings()
    s.ensure_dirs()
    return s
